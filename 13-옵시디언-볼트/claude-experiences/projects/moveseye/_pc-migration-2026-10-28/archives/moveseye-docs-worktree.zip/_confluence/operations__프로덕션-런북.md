# MovesEye Production 배포·백업·복구 Runbook

| 항목 | 내용 |
|---|---|
| 대상 독자 | 운영 책임자, 배포 담당자, 당직자 |
| 문서 상태 | draft |
| 관리 주체 | TBD |
| 기준일 | 2026-08-05 skeleton |
| 최종 검토 | 2026-08-05 |
| 검토 주기 | monthly |
| 정본 위치 | 배포 자동화·인프라 구성 확정 필요 |
| 적용 범위 | production |

# MovesEye Production 배포·백업·복구 Runbook

> 실행 금지: 이 문서는 production 절차의 필수 항목을 빠뜨리지 않기 위한 draft다. owner, 환경, 자동화 경로, backup restore test, rollback 명령, escalation이 확정되기 전에는 실행 가능한 Runbook이 아니다.

## 1. 승인 전 결정 필드

| 항목 | 확정 값 | owner/evidence |
|---|---|---|
| Production URL·region·network boundary | TBD | TBD |
| BE deploy pipeline/job | TBD | TBD |
| FE deploy pipeline/job | TBD | TBD |
| PostgreSQL service·backup 방식 | TBD | TBD |
| Redis persistence·복구 정책 | TBD | TBD |
| Zabbix endpoint owner | TBD | TBD |
| Secret store·주입 경로 | TBD | **Credential 정책** |
| Release approver | TBD | TBD |
| Primary/secondary on-call | TBD | TBD |
| Incident channel·escalation | TBD | TBD |

하나라도 `TBD`면 문서를 `current`로 승격하지 않는다.

## 2. 배포 입력

- BE immutable artifact 또는 commit:
- FE immutable artifact 또는 commit:
- latest Flyway:
- release note:
- contract/integration QA evidence:
- functional QA evidence:
- security review:
- 승인 ticket/change window:

## 3. 배포 전 점검

- [ ] 현재 배포 version·commit·Flyway를 기록했다.
- [ ] PostgreSQL backup을 생성하고 별도 환경에서 restore test했다.
- [ ] Redis 손실 시 영향과 재생성 가능 상태를 확인했다.
- [ ] Zabbix·AWS·SMTP·secret 의존성의 변경 여부를 확인했다.
- [ ] 새 environment variable과 secret을 배포 전에 주입했다.
- [ ] Flyway가 backward compatible인지, 장시간 lock을 유발하는지 검토했다.
- [ ] rollback과 DB forward-fix 중 어떤 전략을 쓸지 결정했다.
- [ ] 변경 시간과 사용자 영향·우회책을 공지했다.

## 4. 배포 절차

실제 pipeline과 명령을 검증한 뒤 다음 형식으로 채운다.

| 순서 | 작업·명령 | 기대 결과 | 중단 조건 | 담당 |
|---:|---|---|---|---|
| 1 | TBD | 이전 version·backup ID 기록 | backup 검증 실패 | TBD |
| 2 | TBD | Flyway latest 적용 | checksum·lock·schema 오류 | TBD |
| 3 | TBD | BE 새 version health 확인 | startup·dependency 오류 | TBD |
| 4 | TBD | FE 새 artifact 제공 | asset load·API origin 오류 | TBD |
| 5 | smoke | 로그인→홈→Host→Problem | 인증·권한·원천 조회 실패 | TBD |

## 5. 배포 후 검증

- 로그인·refresh·logout
- 권한이 다른 계정의 Host Group 범위
- 실제 Zabbix Host·metric·Problem
- 자산/비용/맵 중 release 영향 기능
- scheduler 실행·run log
- error rate, latency, DB connection, Redis session
- secret·개인정보 log 노출 없음

결과와 timestamp, 실행자, evidence 경로를 release 문서에 연결한다.

## 6. Rollback / Forward-fix 결정

| 조건 | 기본 판단 |
|---|---|
| code-only, schema backward compatible | 이전 artifact rollback 검토 |
| destructive/irreversible migration | code rollback 금지, forward-fix와 restore 시점 결정 |
| credential·권한 사고 | key 폐기·회전 우선, 접근 차단 후 복구 |
| Zabbix write 영향 | 변경 감사 로그와 원천 현재값 비교 후 수동 복원 승인 |

실제 명령, 허용 RTO/RPO, restore 지점은 owner 승인 뒤 추가한다.

## 7. Incident·Escalation

| 심각도 | 조건 | 최초 대응 | escalation 시간·대상 |
|---|---|---|---|
| SEV-1 | 전체 로그인/모니터링 불가, 데이터 손상·credential 노출 | 배포 중단·변경 동결 | TBD |
| SEV-2 | 주요 기능 또는 다수 고객 영향 | 영향 기능 격리·우회 | TBD |
| SEV-3 | 제한된 기능·사용자 영향 | ticket·다음 배포 수정 | TBD |

## 8. Current 승격 조건

- [ ] 모든 TBD가 실제 값과 owner로 채워짐
- [ ] backup restore drill 성공
- [ ] rollback 또는 forward-fix rehearsal 성공
- [ ] secret 주입·회전 drill 성공
- [ ] release 1회 이상에서 절차대로 실행·evidence 보존
- [ ] 독립 운영자가 문서만으로 dry-run 성공

## 변경 이력

| 날짜 | 변경 |
|---|---|
| 2026-08-05 | 필수 결정·검증 항목 skeleton 작성. 실행 불가 draft |
