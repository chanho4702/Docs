// RFC-220 검토용: 외부 I/O만 대체하고 실제 서비스·집계 코드를 연결한다.
const mockPost = jest.fn();
const mockSearch = jest.fn();
const mockBulk = jest.fn();
jest.mock('../../src/api/jira/util/RequestJiaJson', () => ({
    requestJiraJson: async () => ({ accountId: 'viewer' }),
    postJiraJson: (...a) => mockPost(...a),
}));
jest.mock('@forge/api', () => ({ route: (s, ...v) => s.reduce((t,p,i) => t+p+(v[i]??''), '') }));
jest.mock('@forge/kvs', () => ({ kvs: { get: async () => null, set: async () => {} }, MetadataField: {} }));
jest.mock('../../src/resolver/backoffice/setting/SettingService', () => ({ getSettingDataService: async () => ({ approvalLinkMode: 'ON', hourRate: 8 }) }));
jest.mock('../../src/permission/PrincipalResolver', () => ({ resolvePrincipal: async () => ({ accountId: 'viewer', leadingScopeAccountIds: [] }) }));
jest.mock('../../src/resolver/approvalLink/InstallCloudId', () => ({ resolveInstallCloudId: () => ({ cloudId: 'cloud' }) }));
jest.mock('../../src/resolver/approvalLink/LinkSigner', () => ({ __esModule: true, default: { ready: () => true } }));
jest.mock('../../src/resolver/approvalChannel/ChannelEpoch', () => ({ __esModule: true, default: { read: async () => 0 } }));
jest.mock('../../src/resolver/approvalLink/ApprovalControlLookup', () => ({ createApprovalControlLookup: () => ({ usable: true, isApprovalHidden: async () => true, prefetch: async () => {} }) }));
jest.mock('../../src/resolver/approvalChannel/ChannelClient', () => ({ callApproval: async (op, data) => ({ ok: true, data: { docs: data.pairs.map(([accountId, periodKey]) => ({
    accountId, periodKey, complete: true,
    body: periodKey === '2026-10' ? {
        ps: Date.parse('2026-10-01T00:00:00+09:00'), pe: Date.parse('2026-11-01T00:00:00+09:00'),
        w: [['501', 3600]], cs: 3600, sc: 0, cn: 1, mn: 0, dn: 0, sn: 0, wn: 1,
        approval: { entries: [['501','APPROVED',null,null,null,'APP','unused',3600,Date.parse('2026-10-02T09:00:00+09:00')]], closeAt: null },
    } : null,
})) } }) }));
jest.mock('../../src/api/jira/issue/IssueApi', () => ({
    getProjectIssuesByUser: (...a) => mockSearch(...a), getIssuesByWorklogAuthor: (...a) => mockSearch(...a),
    getBulkIssuesByProject: (...a) => mockBulk(...a),
}));
jest.mock('../../src/api/jira/worklog/WorklogApi', () => ({ getWorkLogByIssueKey: async () => ({ worklogs: [] }) }));
jest.mock('../../src/resolver/myWork/MyWorkRepository', () => ({}));
jest.mock('../../src/resolver/backoffice/role/RoleService', () => ({}));
jest.mock('../../src/resolver/backoffice/level/LevelService', () => ({}));
jest.mock('../../src/resolver/backoffice/projectStatus/ProjectStatusService', () => ({}));
jest.mock('../../src/resolver/backoffice/publicHoliday/PublicHolidayService', () => ({ getPublicHolidayListService: async () => ({ data: [] }) }));
jest.mock('../../src/resolver/projectDashboard/ProjectDashboardService', () => ({ getSummaryDataService: async () => ({ start_date: '2026-10-01', end_date: '2026-10-31', total_member_count: 1 }) }));
jest.mock('../../src/api/jira/issue/ProjectIssuesFetcher', () => ({ fetchAllProjectIssues: async () => [{ id: '100', key: 'A-1', fields: { timetracking: { originalEstimateSeconds: 28800, timeSpentSeconds: 3600 }, status: { statusCategory: { key: 'new' } } } }] }));

import { applyWorklogApproval, resetApprovalCertCache } from '../../src/resolver/approvalLink/ApprovalCertReader';
import { getMyCalendarWorklogService, getProjectWorklogService } from '../../src/resolver/myWork/MyWorkService';
import { getProjectProgressSummaryService } from '../../src/resolver/projectProgress/ProjectProgressService';
import { getProjectWorklogsAsApp } from '../../src/api/jira/worklog/CollabWorklogFetcher';

const viewer = { accountId: 'viewer', cloudId: 'cloud' };
const range = { startDate: '2026-10-01', endDate: '2026-10-31' };
const log = { id: '501', issueId: '100', author: { accountId: 'viewer' }, started: '2026-10-02T09:00:00+09:00', timeSpentSeconds: 3600, visibility: { type: 'role', value: 'locked' } };
const issue = { id: '100', key: 'A-1', fields: { project: { id: '10' }, worklog: { total: 0, maxResults: 20, worklogs: [] } } };
// 2026-10-28 수정 설계(04_fix_design) 반영: 앱 자격(as:'app') 검색은 승인 앱이 숨긴 기록도 본다(Jira visibility 는 앱 자격을 막지 않는다).
//   원래 케이스는 asApp 을 postJiraJson(worklog/list)으로만 모델링했다 — 검색 경계에도 같은 사실을 반영한다. 기대값(단언)은 그대로다.
const issueAsApp = { ...issue, fields: { ...issue.fields, worklog: { total: 1, maxResults: 20, worklogs: [log] } } };
beforeEach(() => {
    jest.clearAllMocks(); resetApprovalCertCache();
    mockSearch.mockImplementation(async (args) => ({ issues: [args?.as === 'app' ? issueAsApp : issue] }));
    mockBulk.mockImplementation(async (args) => [args?.as === 'app' ? issueAsApp : issue]);
    mockPost.mockImplementation(async ({ url, as }) => {
        if (url.includes('permissions/check')) return { projectPermissions: [{ permission: 'BROWSE_PROJECTS', issues: [100] }] };
        if (url.includes('issue/bulkfetch')) return { issues: [issue] };
        return as === 'app' ? [log] : [];
    });
});

test('대조군: 원래 이슈 ID를 넘기면 실제 승인 집계가 숨긴 본인 1시간을 복원한다', async () => {
    const out = await applyWorklogApproval([], viewer, { ...range, includeHidden: true, selfOnly: true, issueIds: ['100'] });
    expect(out).toHaveLength(1);
    expect(out[0].timeSpentSeconds).toBe(3600);
});
test.each([['캘린더', getMyCalendarWorklogService], ['프로젝트 기록', getProjectWorklogService]])('%s는 숨긴 본인 기록만 있는 이슈도 보존해야 한다', async (_, service) => {
    const out = await service({ ...range, accountId: 'viewer', selectedProjectIds: ['P'] }, viewer);
    expect(out.data.flatMap(i => i.fields.worklog.worklogs)).toHaveLength(1);
});
test('진척도는 승인 앱이 숨긴 1시간을 실적 0.1MD로 보존해야 한다', async () => {
    // 2026-10-28 보강(Codex P1-2): 앱 자격 읽기는 워크포스 등록 사용자만 — 컨트롤러가 넘기는 가드 principal 을 케이스도 넘긴다.
    const out = await getProjectProgressSummaryService({ projectId: 'P' }, { accountId: 'viewer', cloudId: 'cloud', isUser: true, workforceRegistered: true });
    expect(out.effort.actualTotalMd).toBe(0.1);
});
test('협업 집계는 Jira Browse 권한이 없는 협업 참여자의 공개 행을 유지해야 한다', async () => {
    const publicLog = { ...log, visibility: undefined };
    mockPost.mockImplementation(async ({ url }) => {
        if (url.includes('search/jql')) return { issues: [{ ...issue, fields: { ...issue.fields, worklog: { total: 1, maxResults: 20, worklogs: [publicLog] } } }] };
        if (url.includes('permissions/check')) return { projectPermissions: [] };
        return [];
    });
    const out = await getProjectWorklogsAsApp({ projectId: '11111111-1111-4111-8111-111111111111', ...range, cloudId: 'cloud' });
    expect(out.worklogs).toHaveLength(1);
});
