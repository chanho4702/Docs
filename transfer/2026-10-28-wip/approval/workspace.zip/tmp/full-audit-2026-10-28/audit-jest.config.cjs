const path = require('path');
const rootDir = path.resolve(__dirname, '../..');
module.exports = {
  ...require(path.join(rootDir, 'jest.config.js')),
  rootDir,
  testPathIgnorePatterns: ['/node_modules/', '/static/ui/'],
  testMatch: ['<rootDir>/tmp/full-audit-2026-10-28/*.repro.test.js'],
};
