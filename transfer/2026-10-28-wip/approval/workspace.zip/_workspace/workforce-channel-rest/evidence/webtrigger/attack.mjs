// URL 유출 공격자 시뮬레이션 — 서명 키 없이 보낼 수 있는 요청 전부. 실제 두 앱(dev)에 보낸다.
import crypto from 'node:crypto';
const CLOUD = '119d766c-47d4-4c52-9b89-72646f2bbc53';
const T = {
  approval: { url: 'https://1bd06760-bb28-4180-a231-23e9029c7ea7.hello.atlassian-dev.net/x1/P2vtmyLnAw9p-6iKp5WwoHoiwQw', from: 'workforce', kid: 'wf-dev-1' },
  workforce: { url: 'https://f8962f17-9f12-43d0-91f5-7f3a626c1bbf.hello.atlassian-dev.net/x1/ssnl9Gcq8M6yJ78CseX6jOeE0Mo', from: 'approval', kid: 'ap-dev-1' },
};
const tok = () => crypto.randomBytes(16).toString('base64url');
const b64u = (b) => Buffer.from(b).toString('base64url');
const env = (t, o = {}) => ({ v: 1, linkId: tok(), op: 'sys.ping', from: t.from, to: t.from === 'workforce' ? 'approval' : 'workforce',
  cloudId: CLOUD, kid: t.kid, iat: Date.now(), nonce: tok(), actor: { type: 'SYSTEM', reason: 'pair-verify' }, ...o });
const body = (e) => JSON.stringify({ env: e, data: {} });
const atk = crypto.generateKeyPairSync('ed25519');
const atkSig = (raw) => b64u(crypto.sign(null, Buffer.concat([Buffer.from('moves-link-rpc/1\n'), Buffer.from(raw)]), atk.privateKey));
const zeroSig = b64u(Buffer.alloc(64));
const cases = (t) => [
  ['A1 GET 메서드', { method: 'GET' }],
  ['A2 JSON 아님', { body: 'hello' }],
  ['A3 300KB 대용량', { body: 'x'.repeat(300_000), sig: zeroSig }],
  ['A4 방향 뒤집기(자기 자신이 보낸 척)', { body: body(env(t, { from: t.from === 'workforce' ? 'approval' : 'workforce', to: t.from === 'workforce' ? 'approval' : 'workforce' })), sig: zeroSig }],
  ['A5 만료 iat(10분 전)', { body: body(env(t, { iat: Date.now() - 600_000 })), sig: zeroSig }],
  ['A6 미래 iat(10분 뒤)', { body: body(env(t, { iat: Date.now() + 600_000 })), sig: zeroSig }],
  ['A7 모르는 kid', { body: body(env(t, { kid: 'attacker-1' })), sig: zeroSig }],
  ['A8 서명 헤더 없음', { body: body(env(t)) }],
  ['A9 0 바이트 서명(86자)', { body: body(env(t)), sig: zeroSig }],
  ['A10 공격자 키로 서명 + 정상 kid 사칭', (() => { const b = body(env(t)); return { body: b, sig: atkSig(b) }; })()],
  ['A11 사람 actor 사칭(서명 위조)', (() => { const b = body(env(t, { op: t.from === 'workforce' ? 'cert.query' : 'link.resolve', actor: { type: 'USER', accountId: '557058:00000000-0000-0000-0000-000000000000' } })); return { body: b, sig: atkSig(b) }; })()],
  ['A12 다른 사이트 cloudId(서명 위조)', (() => { const b = body(env(t, { cloudId: '00000000-0000-0000-0000-000000000000' })); return { body: b, sig: atkSig(b) }; })()],
];
const send = async (t, c) => {
  const s = Date.now();
  const r = await fetch(t.url, { method: c.method ?? 'POST', headers: { 'content-type': 'application/json', ...(c.sig ? { 'x-moves-link-sig': c.sig } : {}) }, body: c.method === 'GET' ? undefined : c.body ?? '' });
  const txt = await r.text();
  return { status: r.status, ms: Date.now() - s, body: txt.slice(0, 120), sigHdr: r.headers.get('x-moves-link-sig') ? 'O' : '-' };
};
const out = [];
for (const [name, t] of Object.entries(T)) {
  for (const [label, c] of cases(t)) { const r = await send(t, c); out.push({ target: name, case: label, ...r }); console.log(name, '|', label, '|', r.status, '|', r.ms + 'ms', '|', r.sigHdr, '|', r.body); }
  // A13 폭주 40건(위조) — 전부 1~8단계에서 끊기는지, 지연
  const s = Date.now(); const rs = await Promise.all(Array.from({ length: 40 }, () => { const b = body(env(t)); return send(t, { body: b, sig: atkSig(b) }); }));
  const tally = rs.reduce((m, r) => (m[r.status] = (m[r.status] ?? 0) + 1, m), {});
  console.log(name, '| A13 위조 40건 동시 |', JSON.stringify(tally), '|', (Date.now() - s) + 'ms 전체', '| 본문 종류', [...new Set(rs.map((r) => r.body))].join(' / '));
}
