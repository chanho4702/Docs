// 증거 파일의 Atlassian accountId(712020:uuid, 24자 hex)를 앞 6·뒤 4 만 남기고 가린다
const fs = require('fs');
const re = /\b(\d{6}:[0-9a-f-]{36}|[0-9a-f]{24})\b/g;
const m = (s) => `${s.slice(0, 6)}…${s.slice(-4)}`;
if (require.main === module) for (const f of process.argv.slice(2)) fs.writeFileSync(f, fs.readFileSync(f, 'utf8').replace(re, m));
module.exports = (s) => s.replace(re, m);
