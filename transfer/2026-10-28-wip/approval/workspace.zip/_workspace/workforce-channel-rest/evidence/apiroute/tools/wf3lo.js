// 워크포스 apiRoute(GET /v1/organization/users) 3LO 실측 도우미 — 2026-10-20
// .client 파일: 1줄 Client ID, 2줄 Client Secret (사용자가 직접 저장, 이 스크립트는 값을 출력하지 않는다)
// node wf3lo.js consent [nosns]            동의 URL 출력 → localhost:8765 콜백 → .token.json(.token-nosns.json)
// node wf3lo.js call <label> <auth> <base> <method> <path>   auth=token|none|bogus|nosns, base=site|svc
// node wf3lo.js refresh                    refresh 회전 + 옛 refresh 재사용 결과
const http = require('http');
const fs = require('fs');
const path = require('path');

const APP = 'f8962f17-9f12-43d0-91f5-7f3a626c1bbf';
const ENV = '6a429133-1034-43cc-8201-71fd054b1497';
const CLOUD = '119d766c-47d4-4c52-9b89-72646f2bbc53';
const BASES = {
  site: `https://tom-chkim-dev.atlassian.net/gateway/api/svc/jira/apps/${APP}_${ENV}`,
  svc: `https://api.atlassian.com/svc/jira/${CLOUD}/apps/${APP}_${ENV}`,
};
const REDIRECT = 'http://localhost:8765/callback';
const file = (name) => path.join(__dirname, name);
const client = () => {
  // 라벨 줄(Client ID·Secret)이 섞여 있어도 값만 고른다: 32자 영숫자 = Client ID, 나머지 가장 긴 줄 = Secret
  const lines = fs.readFileSync(file('.client'), 'utf8').split(/\r?\n/).map((s) => s.trim())
    .filter((s) => s && !/^(client\s*id|client\s*secret|secret)$/i.test(s));
  const id = lines.find((s) => /^[A-Za-z0-9]{32}$/.test(s));
  const secret = lines.filter((s) => s !== id).sort((a, b) => b.length - a.length)[0];
  if (!id || !secret) throw new Error('.client 파일에 1줄 Client ID, 2줄 Client Secret 이 필요합니다');
  return { id, secret };
};
const tokenFile = (variant) => file(variant === 'nosns' ? '.token-nosns.json' : '.token.json');
const mask = (s) => (typeof s === 'string' && s.length > 12 ? `${s.slice(0, 6)}…${s.slice(-4)}` : s);
const maskBody = require('./mask'); // accountId 형식이면 키와 무관하게 가린다(경로·leaderAccountId 포함)

async function consent(variant) {
  const { id, secret } = client();
  const scope = ['read:organization:custom', 'read:forge-app:jira', 'offline_access'].join(' ');
  const state = Math.random().toString(36).slice(2);
  const params = new URLSearchParams({ audience: 'api.atlassian.com', client_id: id, scope, redirect_uri: REDIRECT, state, response_type: 'code', prompt: 'consent' });
  if (variant !== 'nosns') params.set('sns', `${APP}.${ENV}`);
  fs.writeFileSync(file('.consent-url.txt'), `https://auth.atlassian.com/authorize?${params}`);
  console.log(`동의 URL 을 .consent-url.txt 에 썼습니다 (sns=${variant === 'nosns' ? '없음' : `${APP}.${ENV}`}, scope=${scope})`);
  http.createServer(async (req, res) => {
    const u = new URL(req.url, 'http://localhost:8765');
    if (u.pathname !== '/callback') return res.end();
    if (u.searchParams.get('state') !== state) return res.end('state mismatch');
    if (u.searchParams.get('error')) { console.log('동의 거부/오류:', u.searchParams.get('error')); res.end('error'); process.exit(1); }
    const r = await fetch('https://auth.atlassian.com/oauth/token', { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ grant_type: 'authorization_code', client_id: id, client_secret: secret, code: u.searchParams.get('code'), redirect_uri: REDIRECT }) });
    const j = await r.json();
    if (j.access_token) fs.writeFileSync(tokenFile(variant), JSON.stringify({ ...j, obtainedAt: Date.now() }));
    console.log('토큰 응답:', r.status, 'scope=', j.scope, 'expires_in=', j.expires_in, 'refresh_token=', Boolean(j.refresh_token), j.error ?? '');
    if (j.access_token) {
      const r2 = await fetch('https://api.atlassian.com/oauth/token/accessible-resources', { headers: { Authorization: `Bearer ${j.access_token}` } });
      const list = await r2.json().catch(() => []);
      console.log('accessible-resources:', r2.status, JSON.stringify(Array.isArray(list) ? list.map((x) => ({ id: x.id, url: x.url, scopes: x.scopes })) : list));
    }
    res.end('done. you can close this tab.');
    process.exit(0);
  }).listen(8765, () => console.log('localhost:8765 콜백 대기 중'));
}

async function call(label, auth, base, method, p) {
  const headers = { Accept: 'application/json' };
  if (auth === 'token' || auth === 'nosns') headers.Authorization = `Bearer ${JSON.parse(fs.readFileSync(tokenFile(auth), 'utf8')).access_token}`;
  if (auth === 'bogus') headers.Authorization = 'Bearer not-a-real-token';
  const t0 = Date.now();
  const r = await fetch(`${BASES[base]}${p}`, { method, headers });
  const ms = Date.now() - t0;
  const body = await r.text();
  const keep = ['content-type', 'www-authenticate', 'x-ratelimit-limit', 'x-ratelimit-remaining', 'atl-traceid'];
  const h = Object.fromEntries(keep.filter((k) => r.headers.get(k)).map((k) => [k, r.headers.get(k)]));
  console.log(JSON.stringify({ label, at: new Date().toISOString(), request: { method, base, path: maskBody(p), auth }, status: r.status, ms, headers: h, body: maskBody(body).slice(0, 4000) }, null, 2));
}

async function refresh() {
  const { id, secret } = client();
  const old = JSON.parse(fs.readFileSync(tokenFile('token'), 'utf8'));
  const go = async (rt) => fetch('https://auth.atlassian.com/oauth/token', { method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ grant_type: 'refresh_token', client_id: id, client_secret: secret, refresh_token: rt }) });
  const r1 = await go(old.refresh_token); const j1 = await r1.json();
  console.log('1차 refresh:', r1.status, 'access 바뀜=', j1.access_token && j1.access_token !== old.access_token, 'refresh 바뀜=', j1.refresh_token && j1.refresh_token !== old.refresh_token, j1.error ?? '');
  if (j1.access_token) fs.writeFileSync(tokenFile('token'), JSON.stringify({ ...j1, obtainedAt: Date.now() }));
  const r2 = await go(old.refresh_token); const j2 = await r2.json().catch(() => ({}));
  console.log('옛 refresh 재사용:', r2.status, j2.error ?? (j2.access_token ? '새 토큰 발급됨' : ''));
}

const [mode, ...rest] = process.argv.slice(2);
({ consent: () => consent(rest[0]), call: () => call(...rest), refresh })[mode]().catch((e) => { console.error(e.message); process.exit(1); });
