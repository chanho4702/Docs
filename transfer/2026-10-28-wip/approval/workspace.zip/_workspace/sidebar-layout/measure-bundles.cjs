const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const root = path.resolve(__dirname, '../../static/ui/build');
const result = {};
for (const entry of ['inbox', 'settings', 'issue', 'worklog']) {
  const html = fs.readFileSync(path.join(root, `${entry}.html`), 'utf8');
  const files = [...html.matchAll(/<script[^>]+src="([^"]+)"/g)].map((match) => match[1]);
  const scripts = files.map((file) => {
    const data = fs.readFileSync(path.join(root, file));
    return { file, bytes: data.length, gzip: zlib.gzipSync(data).length };
  });
  result[entry] = {
    scripts,
    bytes: scripts.reduce((sum, item) => sum + item.bytes, 0),
    gzip: scripts.reduce((sum, item) => sum + item.gzip, 0),
  };
}
const destination = path.resolve(__dirname, process.argv[2] || 'bundle-after.json');
fs.writeFileSync(destination, `${JSON.stringify(result, null, 2)}\n`);
for (const [entry, value] of Object.entries(result)) {
  console.log(`${entry}: ${value.bytes} bytes, gzip ${value.gzip} bytes`);
}
