const fs = require('fs');
const path = require('path');
const { createRequire } = require('module');
const uiRequire = createRequire(path.resolve(__dirname, '../../static/ui/package.json'));
const React = uiRequire('react');
const { renderToStaticMarkup } = uiRequire('react-dom/server');
const babel = uiRequire('@babel/core');
const shellPath = path.resolve(__dirname, '../../static/ui/src/app/AppShell.jsx');
const source = fs.readFileSync(shellPath, 'utf8')
  .replace("import { t } from '../utils/i18n';", "const t = (key) => ({'inbox.nav.expand':'메뉴 펼치기','inbox.nav.collapse':'메뉴 접기','inbox.nav.navigation':'앱 메뉴'}[key] ?? key);")
  .replace("import './appShell.css';", '');
const compiled = babel.transformSync(source, {
  configFile: false, babelrc: false,
  presets: [uiRequire.resolve('@babel/preset-react')],
  plugins: [uiRequire.resolve('@babel/plugin-transform-modules-commonjs')],
}).code;
const component = { exports: {} };
new Function('require', 'module', 'exports', compiled)(uiRequire, component, component.exports);
const AppShell = component.exports.default;
const settings = ['정책', '적용 프로젝트', '타임시트', '워크포스 연동', '결재선', '승인 그룹', '승인자', '설정 관리자', '설정 이력', '워크로그 변경 이력', '데이터 관리'];
const icon = React.createElement('svg', { width: 20, height: 20, viewBox: '0 0 20 20' }, React.createElement('rect', { x: 4, y: 4, width: 12, height: 12, rx: 3, fill: 'none', stroke: 'currentColor', strokeWidth: 1.5 }));
const groups = [
  { key: 'work', label: '승인 업무', items: ['내 차례', '진행 중', '내 요청', '처리한 건', '참조', '내 타임시트', '팀 타임시트', '알림'].map((label, index) => ({ key: `work-${index}`, label, icon, badge: index === 0 ? 3 : undefined })) },
  { key: 'personal', label: '내 설정', items: ['내 서명', '내 위임'].map((label, index) => ({ key: `personal-${index}`, label, icon })) },
  { key: 'admin', label: '관리', items: [{ key: 'settings', label: '설정', icon, children: settings.map((label, index) => ({ key: `setting-${index}`, label, icon })) }] },
];
const content = React.createElement('div', { style: { padding: 24, border: '1px solid var(--ds-border)', borderRadius: 8 } },
  React.createElement('h2', { style: { fontSize: 18, marginTop: 0 } }, '워크포스 연동 사용'),
  React.createElement('p', null, '양쪽 앱의 호환 버전과 서명 키가 준비되어야 연동할 수 있습니다.'),
  React.createElement('div', { style: { display: 'flex', flexWrap: 'wrap', gap: 16 } },
    ...['서명 기능', '게시 상태', '워크포스 정보 검증'].map((label) => React.createElement('div', { key: label, style: { flex: '1 1 150px', padding: 16, border: '1px solid var(--ds-border)', borderRadius: 6 } }, label))));
const shell = renderToStaticMarkup(React.createElement(AppShell, {
  title: '승인 업무함', fullPage: true, groups, selected: 'settings', selectedChild: 'setting-3', onSelect() {}, onSelectChild() {},
}, content));
const css = fs.readFileSync(path.resolve(__dirname, '../../static/ui/src/app/appShell.css'), 'utf8');
const globalCss = ':root{--ds-surface:#fff;--ds-text:#172b4d;--ds-border:#dfe1e6}body{font-family:Segoe UI,Malgun Gothic,sans-serif;background:var(--ds-surface,#fff);color:var(--ds-text,#172b4d)}';
const dark = ':root{--ds-surface:#1d2125;--ds-text:#b6c2cf;--ds-text-subtle:#9fadbc;--ds-text-subtlest:#8c9bab;--ds-border:#38414a;--ds-background-selected:#1c2b41;--ds-text-selected:#579dff;--ds-background-neutral-subtle-hovered:#282e33;--ds-surface-overlay:#282e33}';
for (const mode of ['wide', 'narrow', 'collapsed', 'dark']) {
  const html = `<!doctype html><html lang="ko"><meta charset="utf-8"><title>AppShell visual check</title><style>${globalCss}${css}${mode === 'dark' ? dark : ''}</style><div id="root">${['collapsed', 'narrow'].includes(mode) ? shell.replace('class="app-page', 'class="app-page app-page--collapsed') : shell}</div></html>`;
  fs.writeFileSync(path.join(__dirname, `shell-${mode}.html`), html);
}
console.log('실제 AppShell JSX와 CSS를 사용한 정적 시각 검증 화면 4개 생성');
