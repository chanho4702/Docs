const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '../../docs/guide');
const problems = [];
let checked = 0;
function walk(folder) {
  for (const item of fs.readdirSync(folder, { withFileTypes: true })) {
    const file = path.join(folder, item.name);
    if (item.isDirectory()) { walk(file); continue; }
    if (!item.name.endsWith('.md')) continue;
    const text = fs.readFileSync(file, 'utf8');
    checked += 1;
    if (text.includes('\uFFFD')) problems.push(`${file}: UTF-8 replacement character`);
    if (/[^\S\r\n]+$/m.test(text)) problems.push(`${file}: trailing whitespace`);
    for (const match of text.matchAll(/\]\(([^)]+)\)/g)) {
      const href = match[1];
      if (/^(https?:|#)/.test(href)) continue;
      if (!fs.existsSync(path.resolve(path.dirname(file), href.split('#')[0]))) problems.push(`${file}: broken link ${href}`);
    }
  }
}
walk(root);
const korean = fs.readdirSync(path.join(root, 'ko')).filter((file) => file.endsWith('.md')).sort();
const english = fs.readdirSync(path.join(root, 'en')).filter((file) => file.endsWith('.md')).sort();
if (JSON.stringify(korean) !== JSON.stringify(english)) problems.push('Korean and English file pairs differ');
console.log(`${checked} documents, ${korean.length} language pairs: ${problems.length ? 'FAIL' : 'PASS'}`);
if (problems.length) { console.log(problems.join('\n')); process.exitCode = 1; }
