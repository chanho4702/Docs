const fs = require('fs'); const path = require('path');
const dict = { ko: JSON.parse(fs.readFileSync('locales/ko-KR.json','utf8')), en: JSON.parse(fs.readFileSync('locales/en-US.json','utf8')) };
const get = (d, k) => k.split('.').reduce((c, s) => (c && typeof c === 'object' ? c[s] : undefined), d);
const walk = (dir) => fs.readdirSync(dir,{withFileTypes:true}).flatMap(e => e.isDirectory() ? walk(path.join(dir,e.name)) : (/\.jsx?$/.test(e.name) && !/test/.test(e.name) ? [path.join(dir,e.name)] : []));
const missing = new Set();
for (const f of walk('static/ui/src')) {
  const s = fs.readFileSync(f,'utf8');
  const re = /(?:\bt\(|tFormat\(t,\s*|labelKey:\s*|t\(\s*)'([a-zA-Z][\w]*\.[\w.]+)'/g;
  let m; while ((m = re.exec(s))) { const k = m[1]; for (const l of ['ko','en']) if (typeof get(dict[l], k) !== 'string') missing.add(`${l}:${k} (${path.relative('static/ui/src', f)})`); }
}
console.log('missing literal keys:', [...missing]);
const codes = [...fs.readFileSync('src/utils/errors/ErrorCodes.js','utf8').matchAll(/([A-Z_]+):\s*'([A-Z_]+)'/g)].map(m=>m[2]);
for (const l of ['kr','en']) { const e = JSON.parse(fs.readFileSync(`locales/${l}/error.json`,'utf8')); const ks = Object.keys(e);
  console.log(l, 'codes not in error.json:', codes.filter(c=>!ks.includes(c)), 'extra:', ks.filter(k=>!codes.includes(k))); }
// template families used dynamically
const fam = ['worklog.lock.reason.PERIOD_CLOSED','worklog.lock.reason.PERIOD_SUBMITTED','worklog.lock.reason.PERIOD_APPROVED','worklog.invalid.started','worklog.invalid.timeSpentSeconds','worklog.invalid.comment','policy.audit.area.periodClose','policy.audit.area.timesheetTeam','policy.audit.action.close','policy.audit.action.reopen','policy.audit.action.autoClose','timesheet.periodClose.state.OPEN','timesheet.periodClose.state.CLOSED','timesheet.periodClose.state.REOPENED','state.expiry.CONTENT_CHANGED','timesheet.status.NOT_SUBMITTED','timesheet.status.SUBMITTED','timesheet.status.APPROVED','timesheet.status.REJECTED','timesheet.status.CHANGED_AFTER_APPROVAL','timesheet.violation.title.WARN','timesheet.violation.title.EXTRA_STEP','timesheet.violation.title.BLOCK','timesheet.settings.unit.MONTH','timesheet.settings.unit.WEEK','timesheet.settings.action.WARN','timesheet.settings.action.EXTRA_STEP','timesheet.settings.action.BLOCK','timesheet.detail.driftKind.CREATED','timesheet.detail.driftKind.UPDATED','timesheet.detail.driftKind.DELETED','inbox.type.timesheet','cert.target.timesheet','detail.event.changed_after_approval','notification.template.timesheetChanged','notification.template.timesheetChangedWhilePending'];
console.log('family missing:', fam.filter(k => ['ko','en'].some(l => typeof get(dict[l],k)!=='string')));
