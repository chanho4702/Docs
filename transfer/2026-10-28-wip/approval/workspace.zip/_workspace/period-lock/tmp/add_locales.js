// period-lock 프론트 회차 — locales/{kr,en} 에 키를 같은 구조로 넣는다(재실행해도 같은 결과).
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..', '..', '..', 'locales');

const W = {
  manifest: { logWork: ['작업 시간 기록', 'Log work'], tab: ['작업 로그', 'Work log'] },
  tab: {
    title: ['작업 로그', 'Work log'],
    logWork: ['작업 시간 기록', 'Log work'],
    empty: ['아직 기록된 작업 시간이 없습니다.', 'No work has been logged yet.'],
    loadMore: ['더 보기', 'Load more'],
    truncated: ['작업 로그가 1,000건을 넘어 일부만 표시합니다.', 'This issue has more than 1,000 work logs; only some are shown.'],
    refresh: ['새로고침', 'Refresh'],
    edit: ['수정', 'Edit'],
    delete: ['삭제', 'Delete'],
    restricted: ['공개 범위 제한', 'Restricted visibility'],
  },
  column: {
    author: ['작성자', 'Author'], started: ['시작', 'Started'], timeSpent: ['소요 시간', 'Time spent'], comment: ['설명', 'Description'],
  },
  dialog: {
    createTitle: ['작업 시간 기록', 'Log work'],
    editTitle: ['작업 로그 수정', 'Edit work log'],
    timeSpent: ['소요 시간', 'Time spent'],
    timeSpentHint: ['예: 3h 30m (1d = 8h, 1w = 5d, 단위 없으면 분)', 'e.g. 3h 30m (1d = 8h, 1w = 5d, minutes if no unit)'],
    started: ['시작 일시', 'Date started'],
    comment: ['설명', 'Description'],
    period: ['기간 {period}', 'Period {period}'],
    save: ['저장', 'Save'],
    cancel: ['취소', 'Cancel'],
    saved: ['저장했습니다.', 'Saved.'],
    commentKeepHint: ['설명을 비우고 저장하면 기존 설명이 그대로 남습니다.', 'If you leave the description empty, the existing description is kept.'],
    restrictedKept: ['이 작업 로그의 공개 범위 제한은 그대로 유지됩니다.', 'The visibility restriction on this work log is kept.'],
  },
  delete: {
    title: ['작업 로그를 삭제할까요?', 'Delete this work log?'],
    body: ['삭제하면 되돌릴 수 없습니다.', 'This cannot be undone.'],
    confirm: ['삭제', 'Delete'],
  },
  invalid: {
    timeSpentSeconds: ['1분 이상 24시간 이하로 입력하세요.', 'Enter between 1 minute and 24 hours.'],
    started: ['시작 일시를 확인하세요.', 'Check the start date and time.'],
    comment: ['설명은 4,000자까지 쓸 수 있습니다.', 'The description can be up to 4,000 characters.'],
  },
  lock: {
    badge: ['잠김', 'Locked'],
    reason: {
      PERIOD_CLOSED: ['{period} 기간이 마감되어 입력·수정할 수 없습니다.', "The {period} period is closed and can't be changed."],
      PERIOD_SUBMITTED: ['{period} 타임시트가 결재 중입니다. 회수하면 수정할 수 있습니다.', 'Your {period} timesheet is awaiting approval. Withdraw it to make changes.'],
      PERIOD_APPROVED: ['{period} 타임시트가 승인되어 수정할 수 없습니다.', "Your {period} timesheet is approved and can't be changed."],
    },
    movedFrom: ['원래 기간도 열려 있어야 옮길 수 있습니다.', 'The original period must also be open to move this entry.'],
  },
  noPermission: ['이 이슈에 작업 시간을 기록할 권한이 없습니다.', "You don't have permission to log work on this issue."],
};

const TS = {
  close: {
    closed: ['마감됨', 'Closed'],
    autoClosed: ['자동 마감됨', 'Auto-closed'],
    autoCloseAt: ['{date} 자동 마감', 'Auto-closes on {date}'],
    drift: ['마감 후 변경됨', 'Changed after close'],
    driftBody: [
      '마감 뒤 Jira 화면 밖(REST·자동화·모바일 등)에서 작업 로그가 바뀌었습니다({date}, {kind}).',
      'A work log was changed outside the Jira screens (REST, automation, mobile, etc.) after the period closed ({date}, {kind}).',
    ],
    lockedHint: ['이 기간은 마감되어 작업 로그를 추가·수정할 수 없습니다.', "This period is closed; work logs can't be added or changed."],
    column: ['마감 후 변경', 'Changed after close'],
  },
  notice: {
    acceptance: [
      '기간 잠금은 이 앱이 Jira 시간 추적 제공자로 선택된 사이트에서 Jira 화면의 입력만 막습니다. REST·자동화·모바일 등 다른 경로의 변경은 막지 못하며, 감지해 다시 승인받게 합니다.',
      'Period locking only blocks entries made in Jira screens on sites where this app is the selected time tracking provider. Changes made through other paths (REST, automation, mobile, etc.) are not blocked; they are detected and require re-approval.',
    ],
  },
  detail: {
    driftPending: ['{date}에 결재 중 내용이 바뀐 것을 감지했습니다({kind}).', 'A change was detected while the timesheet was awaiting approval on {date} ({kind}).'],
  },
  settings: {
    lockSection: ['기간 잠금', 'Period locking'],
    autoCloseDays: ['기간 종료 후 자동 마감(일, 0 = 끔)', 'Auto-close after period end (days, 0 = off)'],
    lockSubmitted: ['제출·승인된 기간의 작업 로그 입력 잠금', 'Lock work logs in submitted and approved periods'],
  },
  periodClose: {
    title: ['기간 마감', 'Period close'],
    hint: [
      '마감된 기간은 이 앱 화면에서 작업 로그를 추가·수정·삭제할 수 없습니다. 제출·결재는 계속할 수 있습니다.',
      "Closed periods can't have work logs added, edited, or deleted from this app. Submission and approval still work.",
    ],
    state: { OPEN: ['열림', 'Open'], CLOSED: ['마감', 'Closed'], REOPENED: ['재개방', 'Reopened'] },
    close: ['마감', 'Close'],
    reopen: ['재개방', 'Reopen'],
    reopenConfirm: [
      '{period} 기간을 다시 엽니다. 승인 상태는 유지되고, 이후 변경은 다시 승인받아야 합니다.',
      'Reopen {period}? Approval status is kept, and later changes will need re-approval.',
    ],
    notEnded: ['아직 끝나지 않은 기간', 'Period not ended yet'],
    closedBy: ['{name} · {date}', '{name} · {date}'],
    auto: ['자동', 'Automatic'],
    driftCount: ['마감 후 변경 {count}명', '{count} changed after close'],
    autoPolicy: ['기간 종료 {days}일 뒤 자동 마감합니다.', 'Periods close automatically {days} days after they end.'],
    autoOff: ['자동 마감이 꺼져 있습니다. 기간을 직접 마감하세요.', 'Auto-close is off. Close periods manually.'],
    empty: ['표시할 기간이 없습니다.', 'No periods to show.'],
    column: {
      period: ['기간', 'Period'], state: ['상태', 'State'], by: ['처리', 'Handled by'], drift: ['마감 후 변경', 'Changed after close'],
    },
  },
  provider: {
    title: ['시간 추적 제공자', 'Time tracking provider'],
    how: [
      'Jira 설정 > 시스템 > 시간 추적에서 "Moves Approval"을 제공자로 선택하세요. 선택하면 Jira 기본 "작업 시간 기록" 버튼과 작업 로그 탭이 이 앱 화면으로 바뀝니다.',
      'In Jira settings > System > Time tracking, select "Moves Approval" as the provider. Jira\'s built-in "Log work" button and Work log tab are then replaced by this app.',
    ],
    tempo: [
      '제공자는 사이트당 하나입니다. Tempo 등 다른 앱을 제공자로 쓰고 있다면 함께 쓸 수 없습니다.',
      "Only one provider can be active per site. It can't be used alongside another provider such as Tempo.",
    ],
    notSelected: [
      '제공자로 선택하지 않으면 입력 잠금은 동작하지 않고, 변경 감지·재승인만 동작합니다.',
      "If this app isn't the selected provider, input locking is off and only change detection and re-approval work.",
    ],
    license: [
      '라이선스가 만료되면 작업 시간을 기록할 수 없게 됩니다. 만료 전에 제공자를 Jira 기본으로 되돌리세요.',
      "If the license expires, work can't be logged. Switch the provider back to Jira before it expires.",
    ],
    permission: [
      '미소속자의 입력을 막으려면 권한 스킴의 "Work on work items"를 프로젝트 역할에만 부여하세요.',
      'To block people outside a project, grant "Work on work items" only to project roles in the permission scheme.',
    ],
  },
};

const PO = {
  audit: {
    area: { periodClose: ['기간 마감', 'Period close'], timesheetTeam: ['타임시트 팀', 'Timesheet teams'] },
    action: { close: ['마감', 'Close'], reopen: ['재개방', 'Reopen'], autoClose: ['자동 마감', 'Auto-close'] },
  },
};

const ER = {
  WORKLOG_PERIOD_LOCKED: ['잠긴 기간이라 작업 로그를 바꿀 수 없습니다.', "This period is locked, so the work log can't be changed."],
  WORKLOG_INVALID_INPUT: ['입력값을 확인하세요.', 'Check your input.'],
  WORKLOG_NOT_FOUND: ['작업 로그를 찾을 수 없습니다. 이미 삭제됐을 수 있습니다.', 'Work log not found. It may have been deleted.'],
  WORKLOG_NOT_OWNER: ['본인이 기록한 작업 로그만 수정·삭제할 수 있습니다.', 'You can only edit or delete your own work logs.'],
  WORKLOG_PERMISSION_DENIED: ['Jira 권한이 없어 작업 로그를 기록·수정할 수 없습니다.', "You don't have Jira permission to log or change work."],
  WORKLOG_REJECTED_BY_JIRA: ['Jira가 작업 로그를 거부했습니다. 시간 추적 설정을 확인하세요.', 'Jira rejected the work log. Check the time tracking settings.'],
  PERIOD_NOT_ENDED: ['끝나지 않은 기간은 마감할 수 없습니다.', "A period can't be closed before it ends."],
  PERIOD_ALREADY_CLOSED: ['이미 마감된 기간입니다.', 'This period is already closed.'],
  PERIOD_NOT_CLOSED: ['마감되지 않은 기간입니다.', "This period isn't closed."],
};

const pick = (o, i) => Object.fromEntries(Object.entries(o).map(([k, v]) => [k, Array.isArray(v) ? v[i] : pick(v, i)]));
const merge = (dst, src) => {
  Object.entries(src).forEach(([k, v]) => {
    if (typeof v === 'object') {
      if (!dst[k] || typeof dst[k] !== 'object') dst[k] = {};
      merge(dst[k], v);
    } else dst[k] = v;
  });
  return dst;
};
const write = (p, o) => fs.writeFileSync(p, `${JSON.stringify(o, null, 2)}\n`);

[['kr', 0], ['en', 1]].forEach(([lang, i]) => {
  write(path.join(root, lang, 'worklog.json'), pick(W, i));
  [['timesheet', TS], ['policy', PO], ['error', ER]].forEach(([ns, obj]) => {
    const file = path.join(root, lang, `${ns}.json`);
    write(file, merge(JSON.parse(fs.readFileSync(file, 'utf8')), pick(obj, i)));
  });
});
console.log('ok');
