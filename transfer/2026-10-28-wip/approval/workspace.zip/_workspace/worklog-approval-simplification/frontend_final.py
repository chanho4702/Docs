from pathlib import Path
import json
r=Path('C:/CloudJira/moves-approval-jira')
def edit(n,f):
 p=r/n;p.write_text(f(p.read_text(encoding='utf-8')),encoding='utf-8')
edit('static/ui/src/features/detail/ApprovalDetail.jsx',lambda s:s.replace('snapshot={target.worklogCertification?.snapshot} t={t}', 'snapshot={target.worklogCertification?.snapshot} locale={locale} t={t}'))
edit('static/ui/src/features/inbox/InboxPage.test.jsx',lambda s:s.replace("expect(location()).toContain('kind=TIMESHEET'));\n    await waitForAssertion(() => expect(container.querySelector('[data-testid=\"inbox-table\"]')).toHaveTextContent('1 items'));", "expect(location()).toContain('kind=TIMESHEET'));\n    await waitForAssertion(() => expect(container.querySelector('[data-testid=\"inbox-table\"]')).toHaveTextContent('0 items'));"))
def manifest(s):
 a=s.index('    - key: transition-approval-action');b=s.index('\n  # 이슈 승인 우측',a)
 return s[:a]+'    # 워크로그 승인만 제공한다. 기존 상태 승인 모듈 정의는 재활성화용으로 보존한다.\n'+'\n'.join('    # '+line[4:] if line.strip() else line for line in s[a:b].splitlines())+'\n'+s[b:]
edit('manifest.yml',manifest)
for lang in ['kr','en']:
 p=r/f'locales/{lang}/policy.json';d=json.loads(p.read_text(encoding='utf-8'));d['settings']['tab']['features']='기본 승인 규칙' if lang=='kr' else 'Approval rules';d['settings']['tab']['timesheet']='승인 기간 · 팀' if lang=='kr' else 'Periods and teams';p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 p=r/f'locales/{lang}/project.json';d=json.loads(p.read_text(encoding='utf-8'));d['placeholder']['body']='이슈별 워크로그 기록 규칙의 예외를 관리합니다. 연동 이슈의 승인 규칙은 Workforce 프로젝트에서 설정합니다.' if lang=='kr' else 'Manage issue-specific worklog rules. Configure approval rules for linked issues in the Workforce project.';p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
