from pathlib import Path
import json,re
root=Path('C:/CloudJira/moves-approval-jira');wf=Path('C:/CloudJira/moves-workforce')
def edit(name,fn,base=root):
 p=base/name;p.write_text(fn(p.read_text(encoding='utf-8')),encoding='utf-8')
edit('static/ui/src/features/inbox/InboxPage.jsx',lambda s:s.replace("import { showAdminGroup, usePrincipal }", "import StorageNotice from '../settings/StorageNotice';\nimport { showAdminGroup, usePrincipal }").replace("      {view === 'settings' ? (", "      <StorageNotice isAdmin={isAdmin} t={t} onManage={() => setView('records')} />\n      {view === 'settings' ? ("))
edit('static/ui/src/features/settings/SettingsPage.jsx',lambda s:s.replace("import SettingsSkeleton", "import StorageNotice from './StorageNotice';\nimport { usePrincipal } from '../inbox/usePrincipal';\nimport SettingsSkeleton").replace('export function SettingsPage() {','export function SettingsPage() {\n  const principal = usePrincipal();').replace('      <SettingsPanel selected={selected}',"      <StorageNotice isAdmin={principal?.isAdmin === true} t={t} onManage={() => select('data')} />\n      <SettingsPanel selected={selected}"))
edit('static/ui/src/features/settings/TimesheetSettings.jsx',lambda s:re.sub(r"import (FeatureOffNotice|\{ useFeatureState).*\n",'',s).replace("const TimeTrackingProviderGuide = lazyTab(() => import('./TimeTrackingProviderGuide'));\n",'').replace('  const features = useFeatureState({ enabled: true });\n','').replace("      {features?.timesheetApproval === false && <FeatureOffNotice feature=\"timesheetApproval\" onNavigate={onNavigate} />}\n",''))
# 연동 개요 조회에 기대지 않고 서버 편집 컨텍스트가 쓰기 가능 여부를 판정한다.
edit('static/ui/src/features/worklog/WorklogTab.jsx',lambda s:s.replace('      {linkedLayout && overviewQuery.data && <React.Suspense', '      {first?.permissions?.canLog && <React.Suspense').replace('overview={overviewQuery.data}', 'overview={{ ...overviewQuery.data, issueId, issueKey }}').replace('  const linkedLayout = true;','  const linkedLayout = Boolean(first?.permissions?.canLog);'))
edit('static/ui/src/features/worklog/WorklogApprovalPanel.jsx',lambda s:s.replace('  const data = query.data;', '  const data = query.data ?? {};').replace('<details><summary>', '<details open><summary>').replace("onInputChange={setSearch}","onInputChange={(value, meta) => { if (meta.action === 'input-change') setSearch(value); }} onKeyDown={(event) => { if (event.key === 'Enter') event.stopPropagation(); }}").replace("t(`worklogApprovalFlow.event.${event.eventType}`)", "t(`worklogApprovalFlow.event.${event.eventType}`)"))
for lang in ['kr','en']:
 p=root/f'locales/{lang}/worklogApprovalFlow.json';data=json.loads(p.read_text(encoding='utf-8'));data['status']['CANCELLED']=data['status']['CANCELED'];data['event']['CANCELLED']=data['event']['CANCELED'];p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 p=root/f'locales/{lang}/error.json';data=json.loads(p.read_text(encoding='utf-8'));data.update({'REASON_REQUIRED':'소명 사유를 입력하세요.' if lang=='kr' else 'Enter a review reason.','WORKLOG_ORIGIN_UNPROVEN':'이 기록의 정상 입력 경로를 확인할 수 없어 승인 요청할 수 없습니다.' if lang=='kr' else 'This record’s entry source could not be verified.','WORKLOG_APPROVAL_REQUIRED':'기록의 상세에서 승인 요청을 해 주세요.' if lang=='kr' else 'Request approval from the record details.'});p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

# 변경된 사용자 흐름을 테스트한다. 사전승인 전용 UI 기대치는 사후승인 접수 실패 보호로 대체한다.
edit('static/ui/src/features/worklog/__test__/WorklogTab.test.jsx',lambda s:s.replace("jest.mock('../../../api/invokeApproval'", "jest.mock('../LinkedWorklogPanel', () => ({ __esModule: true, default: () => <div data-testid=\"worklog-entry-form\" /> }));\njest.mock('../../../api/invokeApproval'").replace("expect(byTestId('worklog-log-work')).not.toBeNull();","expect(byTestId('worklog-entry-form')).not.toBeNull();"))
def dialogtests(s):
 a=s.index("it('필수 사전승인은");b=s.index("it('생성 —",a)
 s=s[:a]+'''it('저장은 성공했지만 접수 실패이면 재저장을 막고 승인 요청 재시도를 안내한다', async () => {
  invokeApproval.mockImplementation(async (name) => name === 'getWorklogEditorContext' ? editor() : { worklog: { worklogId: '99' }, approval: { status: 'SUBMISSION_FAILED', retryable: true } });
  render();
  await waitFor(() => expect(byTestId('worklog-save')).not.toBeNull());
  type('#worklog-time-spent', '1h');
  await act(async () => byTestId('worklog-save').click());
  await waitFor(() => expect(container.textContent).toContain('worklogApprovalFlow.saved.SUBMISSION_FAILED'));
  expect(byTestId('worklog-save')).toBeNull();
  expect(calls('createWorklog')).toHaveLength(1);
});

'''+s[b:]
 s=s.replace("F4 범위 폼도 필수 사전승인은 직접 작성 대신 승인 요청으로 보낸다", "과거 사전승인 설정이 남아도 정상 저장 뒤 사후 승인한다").replace("expect(byTestId('worklog-save').textContent).toBe('worklogApproval.action.request');","expect(byTestId('worklog-save').textContent).toBe('worklog.form.record');").replace("expect(calls('createWorklogApproval')).toHaveLength(1);\n  expect(calls('createWorklog')).toHaveLength(0);","expect(calls('createWorklogApproval')).toHaveLength(0);\n  expect(calls('createWorklog')).toHaveLength(1);")
 return s
edit('static/ui/src/features/worklog/__test__/WorklogDialog.test.jsx',dialogtests)

edit('static/ui/src/panel/PanelRecentWorklogs.jsx',lambda s:s.replace("import {resolveApprovalRowMode}","import WorklogApprovalBadge from '../components/worklog/WorklogApprovalBadge';\nimport {resolveApprovalRowMode}").replace("const duration = formatWorklogDuration(worklog?.timeSpentSeconds ?? 0);","const duration = formatWorklogDuration(worklog?.claimedSeconds ?? worklog?.timeSpentSeconds ?? 0);").replace("                                {worklog?.via === 'APP'", "                                <WorklogApprovalBadge worklog={worklog} />\n                                {worklog?.via === 'APP'"),wf)
edit('static/ui/src/pages/projectDetail/work/WorklogHistoryList.jsx',lambda s:s.replace("import Avatar", "import WorklogApprovalBadge from '../../../components/worklog/WorklogApprovalBadge';\nimport Avatar").replace('            <span\n                title={comment}', '            <WorklogApprovalBadge worklog={worklog} />\n            <span\n                title={comment}'),wf)
(wf/'static/ui/src/components/worklog/WorklogApprovalBadge.jsx').write_text('''import React from 'react';
import Lozenge from '@atlaskit/lozenge';
import { useI18nStore } from '../../stores/useI18nStore';
export default function WorklogApprovalBadge({ worklog }) {
    const t = useI18nStore((state) => state.t);
    if (!worklog?.approval) return null;
    const { status, locked, countableSeconds } = worklog.approval;
    return <span style={{ display: 'inline-flex', gap: 4, flexWrap: 'wrap' }}>
        <Lozenge appearance={status === 'APPROVED' ? 'success' : status === 'PENDING' ? 'inprogress' : 'default'}>{t(`worklog.approval.status.${status ?? 'UNKNOWN'}`)}</Lozenge>
        {locked && <span>{t('worklog.approval.locked')}</span>}
        {Number(countableSeconds) === 0 && Number(worklog.claimedSeconds) > 0 && <span>{t('worklog.approval.excluded')}</span>}
    </span>;
}
''',encoding='utf-8')
for lang in ['kr','en']:
 p=wf/f'locales/{lang}/worklog.json';data=json.loads(p.read_text(encoding='utf-8'));source=json.loads((root/f'locales/{lang}/worklogApprovalFlow.json').read_text(encoding='utf-8'));data['approval']={'status':{**source['status'],'UNAPPROVED':'승인 안 됨' if lang=='kr' else 'Not approved','FOREIGN':'입력 경로 확인 필요' if lang=='kr' else 'Check entry source'},'locked':source['locked'],'excluded':'통계 제외' if lang=='kr' else 'Excluded from totals'};p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
