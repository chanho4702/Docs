from pathlib import Path
import re
r=Path('C:/CloudJira/moves-approval-jira')
def edit(n,f):
 p=r/n;p.write_text(f(p.read_text(encoding='utf-8')),encoding='utf-8')
def tab(s):
 a=s.index('/**');b=s.index('const LinkedWorklogPanel',a)
 s=s[:a]+'''// 모달은 별도 iframe이므로 닫힌 뒤 목록과 이력을 함께 다시 읽는다.
'''+s[b:]
 s=s.replace('  issueId, issueKey, locale, t, forceCreate = false, initialDraft,','  issueId, issueKey, locale, t, initialDraft,')
 s=s.replace('  // 탭 안 하위 탭 — 작업 로그 / 내 승인 요청. 표 두 개가 위아래로 쌓여 헷갈린다는 사용자 지적(2026-10-12).\n  // 승인 요청 쪽은 고를 때만 마운트해 탭을 열 때 조회가 하나 줄어든다.\n','')
 a=s.index('  const policyQuery =');b=s.index('  const query = useInfiniteQuery',a);s=s[:a]+s[b:]
 s=s.replace('  const linkedLayout = Boolean(first?.permissions?.canLog);\n','').replace(' isDisabled={!policyReady}','')
 a=s.index('        <Inline space="space.100" alignBlock="center">',s.index('  return ('));b=s.index('        <Button\n          appearance="subtle"',a);s=s[:a]+s[b:]
 s=s.replace('      {/* 사전 승인 필수인데 결재선이 없어 기록 버튼이 막힌 경우 — 누가 어디서 정해야 하는지(같은 쿼리키라 추가 조회 없음) */}\n','')
 return s
edit('static/ui/src/features/worklog/WorklogTab.jsx',tab)
def form(s):
 s=s.replace('useMemo, useRef, useState','useMemo, useState').replace("import { newClientIntentId } from '../worklogApproval/worklogApprovalModel';\n",'').replace("import { missingFlowKey } from '../worklogApproval/WorklogApprovalFlowLine';\n",'')
 s=s.replace('  const policy = editor.approvalPolicy;\n  const approvalRequired = false;\n  const policyReady = true;\n  const intent = useRef(null);\n','')
 a=s.index('  const draftKey =');b=s.index('  const save =',a);s=s[:a]+s[b:]
 a=s.index('      if (approvalRequired) {');b=s.index("      return mode === 'edit'",a);s=s[:a]+s[b:]
 s=s.replace('        intent.current = null;\n','').replace('onDone?.({ changed: !approvalRequired, approvalRequested: approvalRequired });',"onDone?.({ changed: true, approvalRequested: result?.approval?.status === 'PENDING' });")
 a=s.index('      } else if (approvalRequired) {');b=s.index('      } else if (result?.policy?',a);s=s[:a]+s[b:]
 s=s.replace(' && policyReady','').replace("t(approvalRequired ? 'worklogApproval.action.request' : rangeInput ? 'worklog.form.record' : 'worklog.dialog.save')","t(rangeInput ? 'worklog.form.record' : 'worklog.dialog.save')")
 a=s.index('        {!policyReady && (');b=s.index('        {!allowed && (',a);s=s[:a]+s[b:];return s
edit('static/ui/src/features/worklog/WorklogDialog.jsx',form)
edit('static/ui/src/features/settings/TimesheetPolicySettings.jsx',lambda s:s.replace("  const approvalModeOptions = APPROVAL_MODES.map((mode) => ({ value: mode, label: t(`timesheet.settings.approvalMode.${mode}`) }));\n",''))
