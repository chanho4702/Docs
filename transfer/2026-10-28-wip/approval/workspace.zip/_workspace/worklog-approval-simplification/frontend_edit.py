from pathlib import Path
import re,json
root=Path('C:/CloudJira/moves-approval-jira')
def edit(name,fn):
 p=root/name;p.write_text(fn(p.read_text(encoding='utf-8')),encoding='utf-8')
edit('static/ui/src/utils/queryKey/approvalKeys.js',lambda s:s.replace("all: ['worklogCertification'],","all: ['worklogCertification'],\n  candidates: (issueId, query) => [...worklogCertificationKeys.all, 'candidates', String(issueId), query],"))
edit('static/ui/src/features/worklog/WorklogDetailModal.jsx',lambda s:s.replace("import CertStateBadge from '../worklogCert/CertStateBadge';","import WorklogApprovalPanel from './WorklogApprovalPanel';").replace("import WorklogPolicySummary from '../worklogPolicy/WorklogPolicySummary';\n",'').replace('          <Tabs id="worklog-detail-tabs"', '''          <WorklogApprovalPanel issueId={issueId} worklogId={worklogId} locale={locale} t={t} onChanged={() => { setChanged(true); refreshLocal(); }} />
          <Tabs id="worklog-detail-tabs"''').replace(s[s.index("                    {Object.hasOwn(worklog, 'certification')"):s.index('                  </Stack>\n                </div>',s.index("                    {Object.hasOwn(worklog, 'certification')"))],''))
edit('static/ui/src/features/worklog/WorklogTab.jsx',lambda s:re.sub(r"import (?:Tabs,.*|MyWorklogApprovals.*|WorklogApprovalFlowLine.*|WorklogRulesLine.*)\n",'',s).replace('  const [section, setSection] = useState(0);\n','').replace('const linkedLayout = forceCreate || overviewQuery.data?.layout === \'LINKED\';',"const linkedLayout = true;").replace('      {policyQuery.data?.policy?.required === true && policyQuery.data.policy.reasonCode && <WorklogApprovalFlowLine issueId={issueId} t={t} />}\n','').replace("t('worklog.column.period')","t('worklogApprovalFlow.statusLabel')").replace(s[s.index('      <Tabs id='):s.index('      </Tabs>')+len('      </Tabs>')],s[s.index('              <CursorPagingTable'):s.index('              />',s.index('              <CursorPagingTable'))+len('              />')]).replace('      {linkedLayout && overviewQuery.data &&', '      {linkedLayout && overviewQuery.data &&'))
edit('static/ui/src/features/worklog/LinkedWorklogPanel.jsx',lambda s:re.sub(r"import Linked(?:SettingSummary|KpiCards).*\n",'',s).replace('    <LinkedSettingSummary overview={overview} locale={locale} t={t} />\n','').replace('    <LinkedKpiCards overview={overview} worklogs={worklogs} list={list} locale={locale} t={t} />\n',''))
edit('static/ui/src/features/worklog/WorklogPeriodCell.jsx',lambda s:s.replace("import CertStateBadge from '../worklogCert/CertStateBadge';","import WorklogApprovalStatus from './WorklogApprovalStatus';").replace('  if (!worklog) return null;','  if (!worklog) return null;\n  if (worklog.approval) return <WorklogApprovalStatus approval={worklog.approval} t={t} />;').replace(s[s.index('      {/* 인증 상태'):s.index('      {worklog.visibilityRestricted')],''))
edit('static/ui/src/entries/issue.jsx',lambda s:'''import React, { useEffect, useState } from 'react';
import { Modal, view } from '@forge/bridge';
import Button from '@atlaskit/button/new';
import SectionMessage from '@atlaskit/section-message';
import { Box, Stack, Text } from '@atlaskit/primitives';
import mount from '../app/mount';
import { ApprovalSkeleton } from '../features/approval/ApprovalStatus';
import { useApprovalI18n } from '../features/approval/useApprovalI18n';
import useI18nStore from '../stores/useI18nStore';
import WorklogTab from '../features/worklog/WorklogTab';
import { resolveIssueView } from '../features/transition/transitionModel';

function IssueApp() {
  const t = useApprovalI18n();
  const { loaded, locale } = useI18nStore();
  const [context, setContext] = useState(null);
  const [error, setError] = useState(null);
  useEffect(() => { view.getContext().then(setContext).catch(setError); }, []);
  if (error) return <SectionMessage appearance="error">{t('error.INVALID_TARGET')}</SectionMessage>;
  if (!context || !loaded) return <ApprovalSkeleton />;
  const target = resolveIssueView(context);
  return <Box padding="space.100">{target.layout === 'compact' ? <Stack space="space.100">
    <Text>{t('worklogApprovalFlow.issueHint')}</Text>
    <Button onClick={() => new Modal({ resource: 'main/worklog', size: 'medium', context: { mode: 'create', issueId: target.issueId, issueKey: target.issueKey } }).open().catch(setError)}>{t('worklog.tab.logWork')}</Button>
  </Stack> : <WorklogTab issueId={target.issueId} issueKey={target.issueKey} locale={locale} t={t} />}</Box>;
}
mount(<IssueApp />);
''')
def dialog(s):
 s=s.replace("  const approvalRequired = mode !== 'edit' && policy?.required === true;","  const approvalRequired = false;").replace("  const policyReady = mode === 'edit' || (typeof policy?.required === 'boolean' && !policy.reasonCode);","  const policyReady = true;")
 s=s.replace('  const [saved, setSaved] = useState(false);','  const [saved, setSaved] = useState(false);\n  const [savedApproval, setSavedApproval] = useState(null);')
 s=s.replace('      if (continuous) {','      setSavedApproval(result?.approval ?? null);\n      if (continuous) {',1)
 s=s.replace('      } else if (result?.policy?.notices?.length) setCompleted(result);','      } else if (result?.policy?.notices?.length || result?.approval) setCompleted(result);')
 start=s.index('        {saved && <SectionMessage');end=s.index('        {!policyReady',start)
 s=s[:start]+'''        {(saved || completed) && <SectionMessage appearance={savedApproval?.status === 'SUBMISSION_FAILED' || savedApproval?.status === 'NEEDS_APPROVER' ? 'warning' : 'success'} testId="linked-worklog-saved"><span role="status">{t(`worklogApprovalFlow.saved.${savedApproval?.status ?? 'SAVED'}`)}</span></SectionMessage>}
        {mode !== 'edit' && <Text color="color.text.subtle">{t('worklogApprovalFlow.saveHint')}</Text>}
'''+s[end:]
 return s
edit('static/ui/src/features/worklog/WorklogDialog.jsx',dialog)
edit('static/ui/src/features/inbox/BulkApproveBar.jsx',lambda s:s.replace('onDone?.();','onDone?.(data);').replace("appearance={result.failed ||", "appearance={result.remaining?.length || result.failed ||").replace('            {applied.waiting > 0 && (', '''            {result.remaining?.length > 0 && <Text>{tFormat(t, 'worklogApprovalFlow.remaining', { count: result.remaining.length })}</Text>}
            {applied.waiting > 0 && ('''))
edit('static/ui/src/features/inbox/InboxPage.jsx',lambda s:s.replace('const bulkDone = useCallback(() => {\n    setSelectedIds(new Set());','const bulkDone = useCallback((result) => {\n    const succeeded = new Set((result?.results ?? []).filter((item) => item.ok).map((item) => String(item.requestId)));\n    setSelectedIds((previous) => new Set([...previous].filter((id) => !succeeded.has(id))));').replace('visibleTabKeys(timesheetContext).map','visibleTabKeys(timesheetContext).filter((key) => key !== \'teamCertification\').map'))
edit('static/ui/src/features/approval/approvalKindModel.js',lambda s:s[:s.index('export const enabledKinds =')]+"export const enabledKinds = (features) => ['WORKLOG_CERTIFICATION', ...(features?.timesheetApproval !== false ? ['TIMESHEET'] : [])];\n")
edit('static/ui/src/features/settings/settingsNavigation.js',lambda s:s.replace("  { key: 'issue', labelKey: 'policy.settings.group.issue', items: ['approval'] },\n",'').replace("items: ['features', 'policy', 'projects', 'managers', 'approvalSetup']","items: ['features', 'managers']").replace("items: ['timesheet', 'worklogControl', 'workforce']","items: ['timesheet', 'workforce']").replace("  { key: 'records'", "  { key: 'advanced', labelKey: 'worklogApprovalFlow.settings.advanced', items: ['policy', 'projects', 'approvalSetup', 'worklogControl'] },\n  { key: 'records'"))
edit('static/ui/src/features/settings/timesheetSettingsModel.js',lambda s:s.replace("['policy', 'cert', 'periodClose', 'teams']","['policy', 'periodClose', 'teams']"))
edit('static/ui/src/features/settings/TimesheetSettings.jsx',lambda s:s.replace("const TimesheetPolicySettings = lazyTab(() => import('./TimesheetPolicySettings'));","const TimesheetPolicySettings = lazyTab(() => import('./WorklogApprovalSettings'));").replace('      <TimeTrackingProviderGuide />\n','').replace("  cert: lazyTab(() => import('./WorklogCertSettings')),\n",''))
edit('static/ui/src/features/settings/FeatureSelectionSettings.jsx',lambda s:'''import React from 'react';
import Button from '@atlaskit/button/new';
import { Stack } from '@atlaskit/primitives';
import { t } from '../../utils/i18n';
import WorklogApprovalSettings from './WorklogApprovalSettings';
export default function FeatureSelectionSettings({ onNavigate }) {
  return <Stack space="space.200"><WorklogApprovalSettings />{onNavigate && <Button appearance="subtle" onClick={() => onNavigate('workforce')}>{t('policy.features.link.workforce')}</Button>}</Stack>;
}
''')
