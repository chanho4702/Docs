from pathlib import Path
import json,re
r=Path('C:/CloudJira/moves-approval-jira');w=Path('C:/CloudJira/moves-workforce')
def edit(n,f,b=r):
 p=b/n;p.write_text(f(p.read_text(encoding='utf-8')),encoding='utf-8')
edit('static/ui/src/features/worklog/__test__/WorklogApprovalFlow.test.jsx',lambda s:s.replace("expect(screen.getByText('worklogApprovalFlow.settings.protectionHint')).toBeInTheDocument();","expect(container.textContent).toContain('worklogApprovalFlow.settings.protectionHint');"))
edit('static/ui/src/features/settings/settingsNavigation.js',lambda s:s.replace("  const key = normalizeSetting(rawSetting);\n  if (key === 'approval') {", "  const key = normalizeSetting(rawSetting);\n  if (rawSetting === 'approval') {").replace(" : { key, section: null };", " : { key: DEFAULT_SETTING, section: null };"))
edit('static/ui/src/entries/projectSettings.jsx',lambda s:re.sub(r'import (?:\{ TransitionRuleSettings \}|WorklogApprovalConfig|\{ FieldChangeRuleSettings \}).*\n','',s).replace('            <WorklogApprovalConfig projectId={projectId} t={t} />\n','').replace('            <TransitionRuleSettings projectId={projectId} t={t} />\n','').replace('            <FieldChangeRuleSettings projectId={projectId} t={t} />\n',''))
edit('static/ui/src/features/worklog/WorklogHandoffPage.jsx',lambda s:s.replace("import ControlBadges", "import WorklogApprovalPanel from './WorklogApprovalPanel';\nimport WorklogHistoryPanel from '../worklogHistory/WorklogHistoryPanel';\nimport ControlBadges").replace('      <DeleteConfirm', '''      <WorklogApprovalPanel issueId={issueId} worklogId={worklogId} locale={locale} t={t} onChanged={invalidate} />
      <details><summary>{t('worklog.detail.tab.historyNone')}</summary><WorklogHistoryPanel issueId={issueId} worklogId={worklogId} locale={locale} timeZone={editor.timeZone} t={t} embedded /></details>
      <DeleteConfirm'''))
edit('static/ui/src/features/worklog/WorklogDialog.jsx',lambda s:s.replace("import WorklogPolicySummary from '../worklogPolicy/WorklogPolicySummary';\n",'').replace('      if (approvalRequired) {\n        await Promise.all(', '      {\n        await Promise.all('))
edit('static/ui/src/features/worklogCert/CertificationListView.jsx',lambda s:s.replace("/**\n *", "const LEGACY_CERTIFICATION_WRITES_ENABLED = false;\n\n/**\n *",1).replace('{false && (','{LEGACY_CERTIFICATION_WRITES_ENABLED && canCertify && (').replace("selectable={false && unit === 'ENTRY'}", "selectable={LEGACY_CERTIFICATION_WRITES_ENABLED && canCertify && unit === 'ENTRY'}"))
edit('static/ui/src/features/worklog/__test__/LinkedWorklogPanel.test.jsx',lambda s:s.replace('.forEach((key) => expect(byId(`linked-kpi-${key}`)).not.toBeNull());','.forEach((key) => expect(byId(`linked-kpi-${key}`)).toBeNull());').replace("expect(container.textContent).toContain('worklog.linked.summary.stale');","expect(container.textContent).not.toContain('worklog.linked.summary.stale');").replace("expect(container.textContent).toContain('worklog.linked.summary.preapproval.REQUIRED');","expect(container.textContent).not.toContain('worklog.linked.summary.preapproval.REQUIRED');").replace("expect(container.textContent).toContain('worklog.kpi.noBasis');","expect(container.textContent).not.toContain('worklog.kpi.noBasis');"))
edit('static/ui/src/features/settings/__test__/TimesheetPolicySettings.test.jsx',lambda s:s.replace("expect(byTestId('ts-approval-mode-section')).not.toBeNull();", "expect(byTestId('ts-approval-mode-section')).toBeNull();").replace("expect(container.querySelector('#ts-approval-mode').value).toBe('CERTIFICATION');", "expect(container.querySelector('#ts-approval-mode')).toBeNull();").replace("expect(container.textContent).toContain('timesheet.settings.approvalModeHelp');","expect(container.textContent).not.toContain('timesheet.settings.approvalModeHelp');").replace("  setValue(container.querySelector('#ts-approval-mode'), 'PREAPPROVAL');\n",'').replace("approvalMode: 'PREAPPROVAL',","approvalMode: 'CERTIFICATION',"))
def timesheettests(s):
 s=s.replace("jest.mock('../TimesheetPolicySettings'", "jest.mock('../WorklogApprovalSettings'").replace("['provider-guide', 'policy-content']", "['policy-content']").replace("['policy', 'cert', 'periodClose', 'teams']", "['policy', 'periodClose', 'teams']")
 a=s.index("  act(() => byTestId('timesheet-settings-tab-cert')");b=s.index('\n});',a)
 s=s[:a]+"  expect(byTestId('timesheet-settings-tab-cert')).toBeNull();"+s[b:]
 a=s.index("it('타임시트 승인을 끄면");b=s.index("it('기능 상태를",a)
 s=s[:a]+'''it('기간 승인 기능이 꺼져도 워크로그 기본 정책과 팀 설정은 사용할 수 있다', async () => {
  mockFeatures.current = { timesheetApproval: false };
  act(() => root.render(<TimesheetSettings />));
  await waitFor(() => expect(contents()).toEqual(['policy-content']));
  expect(byTestId('feature-off-timesheetApproval')).toBeNull();
  act(() => byTestId('timesheet-settings-tab-teams').click());
  await waitFor(() => expect(contents()).toEqual(['teams-content']));
});

'''+s[b:];return s
edit('static/ui/src/features/settings/__test__/TimesheetSettings.test.jsx',timesheettests)
edit('static/ui/src/features/settings/__test__/FeatureSelectionSettings.test.jsx',lambda s:'''import React, { act } from 'react';
import { createRoot } from 'react-dom/client';
import FeatureSelectionSettings from '../FeatureSelectionSettings';
jest.mock('../WorklogApprovalSettings', () => () => <div data-testid="worklog-policy" />);
jest.mock('../../../utils/i18n', () => ({ t: (key) => key }));
jest.mock('@atlaskit/primitives', () => ({ Stack: ({ children }) => <div>{children}</div> }));
jest.mock('@atlaskit/button/new', () => ({ __esModule: true, default: ({ children, onClick }) => <button onClick={onClick}>{children}</button> }));
global.IS_REACT_ACT_ENVIRONMENT = true;
test('기본 설정은 워크로그 규칙 하나와 연동 설정 이동으로 구성한다', () => {
  const container = document.createElement('div'); const root = createRoot(container); const navigate = jest.fn();
  act(() => root.render(<FeatureSelectionSettings onNavigate={navigate} />));
  expect(container.querySelector('[data-testid="worklog-policy"]')).not.toBeNull();
  expect(container.textContent).not.toContain('issueApproval');
  act(() => container.querySelector('button').click());
  expect(navigate).toHaveBeenCalledWith('workforce');
  act(() => root.unmount());
});
''')
def navtests(s):
 s=s.replace("['general', 'issue', 'worklog', 'records']", "['general', 'worklog', 'advanced', 'records']").replace("['general', 'issue', 'worklog']", "['general', 'worklog', 'advanced']").replace('toHaveLength(11)','toHaveLength(10)').replace('toBe(11)','toBe(10)').replace('toHaveLength(9)','toHaveLength(8)').replace("['features', 'policy', 'projects', 'managers', 'approvalSetup']", "['features', 'managers']")
 s=s.replace("    expect(groupOf('approval')).toBe('issue');", "    expect(SETTINGS_NAVIGATION.find((item) => item.key === 'approval')).toBeUndefined();").replace("expect(groupOf('approvalSetup')).toBe('general');", "expect(groupOf('approvalSetup')).toBe('advanced');").replace("['timesheet', 'worklogControl', 'workforce']", "['timesheet', 'workforce']")
 a=s.index("    expect(flat.find((item) => item.key === 'approval'))");b=s.index("    expect(flat.find((item) => item.key === 'features'))",a);s=s[:a]+s[b:]
 s=s.replace("label: 'policy.settings.tab.approvalSetup', group: 'policy.settings.group.general'", "label: 'policy.settings.tab.approvalSetup', group: 'worklogApprovalFlow.settings.advanced'").replace("{ key: 'approval', section: null }", "{ key: 'features', section: null }")
 a=s.index("    expect(off.approval)");b=s.index("    expect(off.timesheet)",a);s=s[:a]+"    expect(off.approval).toBeUndefined();\n"+s[b:]
 a=s.index("    expect(Object.keys(bypass))");b=s.index("\n  });",a);s=s[:a]+"    expect(Object.keys(bypass)).toEqual([]);"+s[b:];return s
edit('static/ui/src/features/settings/__test__/settingsNavigation.test.js',navtests)
edit('static/ui/src/features/approval/__test__/approvalKindModel.test.js',lambda s:s.replace('expect(enabledKinds(null)).toEqual(APPROVAL_KINDS);',"expect(enabledKinds(null)).toEqual(['WORKLOG_CERTIFICATION', 'TIMESHEET']);").replace("toEqual(['TIMESHEET', 'WORKLOG_CREATE', 'WORKLOG_CERTIFICATION'])","toEqual(['WORKLOG_CERTIFICATION', 'TIMESHEET'])").replace("toEqual(['ISSUE', 'ISSUE_TRANSITION', 'FIELD_CHANGE', 'WORKLOG_CREATE', 'WORKLOG_CERTIFICATION'])","toEqual(['WORKLOG_CERTIFICATION'])").replace("WORKLOG_CERTIFICATION: '워크로그 인증(이전 방식)'", "WORKLOG_CERTIFICATION: '워크로그 승인'"))
def inbox(s):
 a=s.index("it('이슈 승인의 옛 정책");b=s.index('\n});',a);block=s[a:b].replace("toBe('approval')", "toBe('features')");s=s[:a]+block+s[b:]
 s=s.replace("await waitForAssertion(() => expect(container.querySelector('[data-testid=\"nav-child-badge-approval\"]')).not.toBeNull());", "await waitForAssertion(() => expect(container.querySelector('[data-testid=\"nav-child-badge-timesheet\"]')).not.toBeNull());").replace("expect(container.querySelector('[data-testid=\"nav-child-badge-approval\"]').textContent).toBe('policy.settings.badge.off');", "expect(container.querySelector('[data-testid=\"nav-child-badge-approval\"]')).toBeNull();")
 a=s.index("it('칩 \"모든 종류\" + 6종");b=s.index("  it('URL 의 kind",a);block=s[a:b].replace("['ISSUE', 'ISSUE_TRANSITION', 'FIELD_CHANGE', 'TIMESHEET', 'WORKLOG_CREATE', 'WORKLOG_CERTIFICATION']","['TIMESHEET', 'WORKLOG_CERTIFICATION']").replace('ISSUE_TRANSITION','TIMESHEET');s=s[:a]+block+s[b:]
 s=s.replace("expect(chip('WORKLOG_CREATE')).not.toBeNull();", "expect(chip('WORKLOG_CREATE')).toBeNull();");return s
edit('static/ui/src/features/inbox/InboxPage.test.jsx',inbox)
def certtests(s):
 a=s.index("  it('매트릭스 →");b=s.index("  it('own 응답의",a)
 s=s[:a]+'''  it('과거 인증 목록은 조회되지만 신규 직접 인증 동작은 제외한다', async () => {
    invokeApproval.mockImplementation(async (name) => name === 'getCertificationMatrix' ? matrix() : name === 'listMemberCertifications' ? memberList() : {});
    draw(<TeamCertificationPage onChange={jest.fn()} locale="en-US" t={t} />);
    await waitFor(() => expect(byTestId('cert-matrix-row-acc-1')).not.toBeNull());
    await click(byTestId('cert-matrix-row-acc-1'));
    await waitFor(() => expect(byTestId('cert-items-row-11')).not.toBeNull());
    expect(byTestId('cert-certify-month')).toBeNull();
    expect(byTestId('cert-certify-selected')).toBeNull();
    expect(calls('certifyWorklogs')).toHaveLength(0);
    expect(calls('certifyOwnWorklogs')).toHaveLength(0);
  });

'''+s[b:];return s
edit('static/ui/src/features/worklogCert/__test__/TeamCertification.test.jsx',certtests)
for lang in ['kr','en']:
 p=r/f'locales/{lang}/audit.json';data=json.loads(p.read_text(encoding='utf-8'));data['approval']['kind']['WORKLOG_CERTIFICATION']='워크로그 승인' if lang=='kr' else 'Worklog approval';p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def wftests(s):
 s=s.replace("setting: null }));", "setting: null, capabilities: { worklogApproval: true } }));").replace("getByLabelText('issueApprovalSetting.pa')", "getByLabelText('issueApprovalSetting.requestMode')").replace("value: 'REQUIRED'", "value: 'AUTO'")
 a=s.index("test('linked-mode-ux");s=s[:a]+'''test('승인 정책을 지원하는 행에만 wa를 보내고 잠금은 고정한다', async () => {
    invoke.mockResolvedValue({ success: true, results: [{ issueId: '1', result: 'SAVED' }], kbStale: false });
    render(<IssueApprovalBulkModal targets={[{ issueId: '1', issueKey: 'AA-1', capabilities: { worklogApproval: true } }, { issueId: '2', issueKey: 'AA-2', capabilities: {} }]} projectId="P" onClose={jest.fn()} onSaved={jest.fn()} />);
    fireEvent.change(screen.getByLabelText('issueApprovalSetting.requestMode'), { target: { value: 'MANUAL' } });
    fireEvent.change(screen.getByLabelText('issueApprovalSetting.closeDays'), { target: { value: '5' } });
    fireEvent.click(screen.getByRole('button', { name: 'issueApprovalSetting.save' }));
    await screen.findByText('AA-1: issueApprovalSetting.result.SAVED');
    expect(invoke.mock.calls[0][1].items[0].wa).toEqual({ v: 1, autoRequest: false, lockApproved: true, closeDays: 5 });
    expect(invoke.mock.calls[0][1].items[1]).not.toHaveProperty('wa');
});
test('구판 승인 앱에는 건별 승인 설정 대신 업데이트 안내를 제공한다', () => {
    render(<IssueApprovalBulkModal targets={[{ issueId: '1' }]} projectId="P" onClose={jest.fn()} onSaved={jest.fn()} />);
    expect(screen.getByText('issueApprovalSetting.approvalUnsupported')).toBeInTheDocument();
    expect(screen.queryByLabelText('issueApprovalSetting.requestMode')).toBeNull();
});
''';return s
edit('static/ui/src/pages/projectDetail/issue/IssueApprovalBulkModal.test.jsx',wftests,w)
def wftabletest(s):
 a=s.index("test('linked-mode-ux");s=s[:a]+'''test('사전승인과 결재선 대신 건별 요청방식과 마감일을 표시한다', () => {
    render(<QueryClientProvider client={client}><IssueApprovalSettingTable projectId="P" query={{ data: { pages: [{ canEdit: false, items: [{ issueId: '1', issueKey: 'AA-1', summary: 'approval', state: 'SET', capabilities: { worklogApproval: true }, setting: { wa: { autoRequest: false, closeDays: 5 }, by: 'lead', at: 0 } }] }] } }} /></QueryClientProvider>);
    expect(screen.getByText('issueApprovalSetting.requestModes.MANUAL')).toBeInTheDocument();
    expect(screen.getByText('5')).toBeInTheDocument();
    expect(screen.queryByText('issueApprovalSetting.paMode.REQUIRED')).toBeNull();
});
''';return s
edit('static/ui/src/pages/projectDetail/issue/IssueApprovalSettingTable.test.jsx',wftabletest,w)
