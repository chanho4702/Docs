from pathlib import Path
import re
root = Path.cwd()
p = root / 'static/ui/src/features/worklogPolicy/WorklogPolicy.test.jsx'
s = p.read_text(encoding='utf-8')
s = s.replace("it('연동 이슈(managedBy WORKFORCE) — 사전 승인(approvalMode)은 \"워크포스 관리\"로 잠그고 저장에서 빼며, 기록 규칙은 편집·저장한다(Q149)'", "it('연동 이슈의 사전승인 필드는 숨기고 기록 규칙 저장 시 기존값을 보존한다'")
s = s.replace(" const approvalRow = await screen.findByTestId('worklog-policy-row-approvalMode');\n expect(approvalRow.querySelector('input[type=\"checkbox\"]')).toBeNull();\n expect(screen.queryByTestId('worklog-policy-managed-approvalMode').textContent).toBe('project.issueExceptions.managedByWorkforce');", " await screen.findByTestId('worklog-policy-row-dailyMaxSeconds');\n expect(screen.queryByTestId('worklog-policy-row-approvalMode')).toBeNull();")
s = s.replace("expect(Object.keys(sent).sort()).toEqual(['dailyMaxSeconds', 'editWindowDays']);", "expect(Object.keys(sent).sort()).toEqual(['approvalMode', 'dailyMaxSeconds', 'editWindowDays']);\n expect(sent.approvalMode).toBe('PREAPPROVAL');")
p.write_text(s, encoding='utf-8')
p = root / 'static/ui/src/features/worklogPolicy/__test__/IssueExceptionList.test.jsx'
s = p.read_text(encoding='utf-8')
s = re.sub(r"const changeSelect = \(select, value\) => act\(\(\) => \{.*?\n\}\);\n", '', s, flags=re.S)
s = s.replace("['worklog.linked.summary.window', 'worklog.linked.summary.preapproval.NOT_REQUIRED']", "['worklog.linked.summary.window']")
s = s.replace("expect(row).toContain('Strict');", "expect(row).not.toContain('Strict');")
s = s.replace("expect(row).toContain('worklog.linked.summary.preapproval.REQUIRED');", "expect(row).not.toContain('worklog.linked.summary.preapproval.REQUIRED');")
s = s.replace("expect(row).toContain('Default');", "expect(row).not.toContain('Default');")
start = s.index("it('삭제 —")
end = s.index("it('이슈 추가", start)
s = s[:start] + '''it('규칙 삭제는 기존 결재선을 건드리지 않는다', async () => {
  render();
  await waitFor(() => expect(byTestId('issue-exception-remove-501')).not.toBeNull());
  click(byTestId('issue-exception-remove-501'));
  click(byTestId('issue-exception-remove-ok'));
  await waitFor(() => expect(calls('saveIssueWorklogPolicy')).toHaveLength(1));
  expect(calls('saveIssueWorklogPolicy')[0][1]).toEqual({ projectId: '10000', issueId: '501', expectedRevision: 3, override: {} });
  expect(calls('selectIssueWorklogApprovalFlow')).toHaveLength(0);
});

it('편집 모달은 기록 규칙만 제공하며 레거시 결재선 선택을 제외한다', async () => {
  render();
  await waitFor(() => expect(byTestId('issue-exception-edit-501')).not.toBeNull());
  click(byTestId('issue-exception-edit-501'));
  await waitFor(() => expect(byTestId('policy-panel')).not.toBeNull());
  expect(byTestId('policy-panel').textContent).toBe('issue:501');
  expect(container.querySelector('#issue-exception-flow')).toBeNull();
  expect(calls('selectIssueWorklogApprovalFlow')).toHaveLength(0);
});

''' + s[end:]
start=s.index("  changeSelect(container.querySelector('#issue-exception-flow'), 'f-1');")
end=s.index("\n});",start)
s=s[:start]+"  expect(container.querySelector('#issue-exception-flow')).toBeNull();"+s[end:]
start=s.index("it('F-3 — 같은 모달")
end=s.index("it('연동 이슈 편집",start)
s=s[:start]+s[end:]
s += '''\nit('규칙 초기화에서도 숨긴 approvalMode와 결재선은 유지한다', async () => {
  invokeApproval.mockImplementation(async (name) => name === 'listIssueWorklogExceptions'
    ? { items: [{ ...appRow, policy: { ...appRow.policy, override: { dailyMaxSeconds: 21600, approvalMode: 'PREAPPROVAL' } } }], flows: FLOWS }
    : {});
  render();
  await waitFor(() => expect(byTestId('issue-exception-remove-501')).not.toBeNull());
  expect(container.textContent).not.toContain('PREAPPROVAL');
  click(byTestId('issue-exception-remove-501'));
  click(byTestId('issue-exception-remove-ok'));
  await waitFor(() => expect(calls('saveIssueWorklogPolicy')).toHaveLength(1));
  expect(calls('saveIssueWorklogPolicy')[0][1].override).toEqual({ approvalMode: 'PREAPPROVAL' });
  expect(calls('selectIssueWorklogApprovalFlow')).toHaveLength(0);
});
'''
p.write_text(s, encoding='utf-8')
