from pathlib import Path
import json,re
root=Path('C:/CloudJira/moves-approval-jira');wf=Path('C:/CloudJira/moves-workforce')
def edit(name,fn,base=root):
 p=base/name;p.write_text(fn(p.read_text(encoding='utf-8')),encoding='utf-8')
def panel(s):
 s=s.replace('useMutation, useQuery,','useInfiniteQuery, useMutation, useQuery,')
 a=s.index('  const query = useQuery(');b=s.index('  const candidates =',a)
 s=s[:a]+'''  const query = useInfiniteQuery({
    queryKey: worklogCertificationKeys.worklog(issueId, worklogId),
    queryFn: ({ pageParam }) => invokeApproval('getWorklogCertification', { issueId, worklogId, ...(pageParam ? { historyBeforeRevision: pageParam } : {}) }),
    initialPageParam: null,
    getNextPageParam: (page) => page.approvalHistoryPage?.hasMore ? page.approvalHistoryPage.nextBeforeRevision : undefined,
    retry: false,
  });
  const data = query.data?.pages?.[0] ?? {};
'''+s[b:]
 s=s.replace("  const events = (data?.approvalHistory ?? []).flatMap((request) => request.events ?? []).sort((a, b) => b.occurredAt - a.occurredAt);", "  const events = (query.data?.pages ?? []).flatMap((page) => (page.approvalHistory ?? []).flatMap((request) => request.events ?? [])).sort((a, b) => b.occurredAt - a.occurredAt);\n  const currentApprovers = (data.approval?.steps ?? []).flatMap((step) => step.approvers ?? []);")
 s=s.replace('events.map((event) => event.actorKey).filter(Boolean)', '[...events.map((event) => event.actorKey), ...currentApprovers.map((person) => person.actorKey)].filter(Boolean)')
 s=s.replace('    {data.lockReason &&', "    {currentApprovers.length > 0 && <Text>{t('worklogApprovalFlow.approver')} {currentApprovers.map((person) => names[person.actorKey] ?? t('worklogApprovalFlow.unknownPerson')).join(', ')}</Text>}\n    {data.lockReason &&")
 s=s.replace('    </details>', '''      {query.hasNextPage && <Button isLoading={query.isFetchingNextPage} onClick={() => query.fetchNextPage()}>{t('worklog.tab.loadMore')}</Button>}
    </details>''')
 return s
edit('static/ui/src/features/worklog/WorklogApprovalPanel.jsx',panel)
edit('static/ui/src/features/worklog/WorklogTab.jsx',lambda s:s.replace("import { token }", "import WorklogRulesLine from '../worklogPolicy/WorklogRulesLine';\nimport { token }").replace('              <CursorPagingTable',"      <WorklogRulesLine policy={first?.policy ?? null} linked={overviewQuery.data?.linked === true} t={t} />\n              <CursorPagingTable"))
def tabtests(s):
 a=s.index("  act(() => { byTestId('worklog-section-approvals')");b=s.index("\n});",a)
 s=s[:a]+"  expect(byTestId('worklog-section-approvals')).toBeNull();\n  expect(calls('listMyWorklogApprovals')).toHaveLength(0);"+s[b:]
 a=s.index("it('인증 상태는");b=s.index("it('\"상세\"",a)
 s=s[:a]+'''it('목록은 사후 승인 상태와 수정 불가를 표시하고 상세 조회는 열 때만 한다', async () => {
  invokeApproval.mockImplementation(async (name) => name === 'getIssueWorklogs' ? page({ worklogs: [view({ approval: { status: 'APPROVED', locked: true } }), view({ worklogId: '7', approval: { status: 'PENDING', locked: false } })] }) : {});
  render();
  await waitFor(() => expect(container.textContent).toContain('worklogApprovalFlow.status.APPROVED'));
  expect(container.textContent).toContain('worklogApprovalFlow.status.PENDING');
  expect(container.textContent).toContain('worklogApprovalFlow.locked');
  expect(calls('getWorklogCertification')).toHaveLength(0);
});

'''+s[b:]
 s=s.replace("await waitFor(() => expect(byTestId('worklog-log-work')).not.toBeNull());", "await waitFor(() => expect(byTestId('worklog-entry-form')).not.toBeNull());")
 return s
edit('static/ui/src/features/worklog/__test__/WorklogTab.test.jsx',tabtests)
edit('static/ui/src/features/inbox/InboxPage.jsx',lambda s:s.replace("onManage={() => setView('records')}","onManage={() => navigateSetting('data')}"))
edit('static/ui/src/features/inbox/InboxTable.jsx',lambda s:s.replace("import { worklogSummary }", "import { formatDuration } from '../worklog/durationInput';\nimport { worklogSummary }").replace("                {targetKind === 'WORKLOG_CREATE'",'''                {item.worklogApproval && <span style={{ color: token('color.text.subtle'), fontSize: 12 }}>
                  {displayDate(item.worklogApproval.started, locale)} · {formatDuration(item.worklogApproval.seconds)}
                  {item.worklogApproval.purpose === 'APPEAL' ? ` · ${t('worklogApprovalFlow.appeal')}` : ''}
                </span>}
                {targetKind === 'WORKLOG_CREATE' ''').replace("targetKind === 'WORKLOG_CREATE'  &&", "targetKind === 'WORKLOG_CREATE' &&"))
# 직접 인증 컴포넌트는 보존하되 레거시 조회 전용으로만 렌더한다.
edit('static/ui/src/features/worklogCert/CertificationListView.jsx',lambda s:s.replace('  canCertify', '  canCertify').replace('canCertify &&', 'false &&').replace('selectable={canCertify}', 'selectable={false}'))
def wfmodal(s):
 s=s.replace("{ ...EMPTY_APPROVAL_FORM, flowId: targets[0].setting?.fl ?? '' }", "{ ...EMPTY_APPROVAL_FORM, flowId: targets[0].setting?.fl ?? '', requestMode: targets[0].setting?.wa ? (targets[0].setting.wa.autoRequest ? 'AUTO' : 'MANUAL') : 'KEEP', closeDays: String(targets[0].setting?.wa?.closeDays ?? 0) }")
 s=s.replace('style={{ display: \'flex\', gap: 12 }}', 'style={{ display: \'flex\', gap: 12, flexWrap: \'wrap\' }}')
 return s
edit('static/ui/src/pages/projectDetail/issue/IssueApprovalBulkModal.jsx',wfmodal,wf)
