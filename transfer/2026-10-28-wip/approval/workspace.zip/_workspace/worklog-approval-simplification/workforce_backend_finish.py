from pathlib import Path
root=Path('C:/CloudJira/moves-workforce')
p=root/'src/resolver/approvalLink/ApprovalCertReader.js'
s=p.read_text(encoding='utf-8')
s=s.replace("viewer, pairs, as = 'user', now = Date.now(), env = process.env, keyring = KEYRING,", "viewer, pairs, as = 'user', cacheScope = '', now = Date.now(), env = process.env, keyring = KEYRING,")
s=s.replace("`${cloudId}|app`", "`${cloudId}|app|${cacheScope}`")
s=s.replace('            worklogId,\n            started: log.started,','            worklogId,\n            issueId: String(log.issueId),\n            started: log.started,')
s=s.replace("    const loaded = await loadApprovalCertDocs({ ...options, as: 'user', viewer: context, pairs: certPairsOfRows(input) });", """    // 타인 사용자 프로퍼티는 asUser로 읽히지 않으므로, 현재 보이는 행을 먼저 다시 검증한 뒤 서명 판정에만 앱 자격을 쓴다.
    const visible = new Set();
    const ids = [...new Set(input.map((row) => String(row.issueId ?? '')).filter((id) => /^\\d+$/.test(id)))];
    for (let start = 0; start < ids.length; start += 100) {
        const part = ids.slice(start, start + 100);
        const checked = await postJiraJson({ as: 'user', url: route`/rest/api/3/permissions/check`,
            body: { projectPermissions: [{ permissions: ['BROWSE_PROJECTS'], issues: part.map(Number) }] },
            logPrefix: '[APPROVAL AGGREGATE PERMISSION]' });
        const allowed = checked?.projectPermissions?.find((entry) => entry.permission === 'BROWSE_PROJECTS')?.issues ?? [];
        allowed.map(String).filter((id) => part.includes(id)).forEach((id) => visible.add(id));
    }
    const current = new Map();
    const worklogIds = input.filter((row) => visible.has(String(row.issueId))).map((row) => String(row.worklogId));
    for (let start = 0; start < worklogIds.length; start += 1000) {
        const part = worklogIds.slice(start, start + 1000);
        const logs = await postJiraJson({ as: 'user', url: route`/rest/api/3/worklog/list`,
            body: { ids: part.map(Number) }, logPrefix: '[APPROVAL AGGREGATE WORKLOG]' });
        for (const log of Array.isArray(logs) ? logs : []) {
            if (part.includes(String(log.id)) && visible.has(String(log.issueId))) current.set(String(log.id), log);
        }
    }
    const allowed = input.filter((row) => {
        const live = current.get(String(row.worklogId));
        return live && String(live.issueId) === String(row.issueId) && live.author?.accountId === row.accountId;
    }).map((row) => ({ ...row, started: current.get(String(row.worklogId)).started,
        claimedSeconds: current.get(String(row.worklogId)).timeSpentSeconds }));
    const loaded = await loadApprovalCertDocs({ ...options, as: 'app', cacheScope: `aggregate|${context.accountId ?? randomUUID()}`,
        viewer: context, pairs: certPairsOfRows(allowed) });""")
s=s.replace("    return input.map((row) => {\n        const approval = approvalOfWorklog(row, loaded.docs, now);", "    return allowed.map((row) => {\n        const approval = approvalOfWorklog(row, loaded.docs, now);\n        delete approval.decidedBy;\n        delete approval.decidedAt;\n        delete approval.requestId;")
p.write_text(s,encoding='utf-8')
p=root/'src/resolver/approvalLink/IssueWorklogControlService.js'
s=p.read_text(encoding='utf-8').replace("        approvalStatus: envelope ? 'PROCESSING' : null,", "        ...(settings.approvalLinkMode === 'ON' && envelope ? { approvalStatus: 'PROCESSING' } : {}),")
p.write_text(s,encoding='utf-8')
