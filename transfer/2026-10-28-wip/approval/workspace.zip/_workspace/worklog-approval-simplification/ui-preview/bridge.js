import dictionary from '../../../locales/ko-KR.json';
export const view = { getContext: async () => ({ locale: 'ko-KR', accountId: 'writer' }), close: async () => {} };
export const i18n = { getTranslations: async () => ({ translations: dictionary }) };
export const router = { open: async () => {}, navigate: async () => {} };
export class Modal { constructor(context) { this.context = context; } async open() { window.previewModal = this.context; } }
export const invoke = async () => ({ success: true, content: {} });
export const events = { on: async () => ({ unsubscribe() {} }), emit: async () => {} };
