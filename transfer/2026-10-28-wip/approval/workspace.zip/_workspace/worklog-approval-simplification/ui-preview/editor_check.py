import json
from pathlib import Path
from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True, executable_path='C:/Users/DMOVE/AppData/Local/ms-playwright/chromium-1223/chrome-win64/chrome.exe')
    page = browser.new_page(viewport={'width': 480, 'height': 900})
    errors = []
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.route('https://**', lambda route: route.abort())
    page.goto('http://127.0.0.1:8766/?screen=dialog')
    page.wait_for_load_state('networkidle')
    print(page.locator('input').evaluate_all('(nodes)=>nodes.map(n=>({id:n.id,type:n.type,value:n.value}))'))
    print(page.get_by_role('button').all_text_contents())
    page.locator('[contenteditable=true]').fill('승인 기준과 작업 내용을 기록합니다.')
    page.locator('#worklog-time-spent').fill('2h')
    page.get_by_test_id('worklog-save').click()
    page.wait_for_function('window.previewCalls.some(c=>c.name==="createWorklog")')
    saved = page.evaluate('window.previewCalls.find(c=>c.name==="createWorklog")')
    assert saved['payload']['comment']['type'] == 'doc', saved
    assert saved['payload']['timeSpentSeconds'] == 7200, saved
    assert not errors, errors
    page.screenshot(path=str(Path(__file__).parent / 'screenshots/editor-saved-480.png'), full_page=True)
    (Path(__file__).parent / 'screenshots/editor-result.json').write_text(json.dumps({'passed':True,'payload':saved,'errors':errors},ensure_ascii=False,indent=2),encoding='utf-8')
    browser.close()
