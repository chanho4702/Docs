from playwright.sync_api import sync_playwright
import json
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='C:/Users/DMOVE/AppData/Local/ms-playwright/chromium-1223/chrome-win64/chrome.exe')
    page=browser.new_page(viewport={'width':480,'height':900})
    errors=[]
    page.on('pageerror',lambda error:errors.append(str(error)))
    page.goto('http://127.0.0.1:8766/?screen=appeal')
    page.wait_for_load_state('networkidle')
    page.wait_for_timeout(1000)
    print(json.dumps({'errors':errors,'text':page.locator('body').inner_text(),'calls':page.evaluate('window.previewCalls ?? null'),'buttons':page.get_by_role('button').all_text_contents()},ensure_ascii=True,indent=2))
    browser.close()
