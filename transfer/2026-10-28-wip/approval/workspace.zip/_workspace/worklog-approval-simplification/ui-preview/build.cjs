const path = require('path');
const fs = require('fs');
const { createRequire } = require('module');
const root = path.resolve(__dirname, '../../..');
const ui = createRequire(path.join(root, 'static/ui/package.json'));
const webpack = ui('webpack');
const source = path.join(root, 'static/ui/src');
const config = {
  mode: 'development', entry: path.join(__dirname, 'entry.jsx'), devtool: false,
  output: { path: path.join(__dirname, 'dist'), filename: 'preview.js', chunkFilename: 'preview-[id].js', publicPath: '' },
  resolve: { extensions: ['.js', '.jsx', '.json'], modules: ['node_modules', path.join(root, 'static/ui/node_modules')], alias: {
    [path.join(source, 'api/invokeApproval')]: path.join(__dirname, 'api.js'),
    [path.join(source, 'features/settings/directoryApi')]: path.join(__dirname, 'directory.js'),
    '@forge/bridge': path.join(__dirname, 'bridge.js'),
  } },
  module: { rules: [
    { test: /\.[jt]sx?$/, exclude: /node_modules/, use: { loader: ui.resolve('babel-loader'), options: { babelrc: false, configFile: false, presets: [ui.resolve('@babel/preset-env'), [ui.resolve('@babel/preset-react'), { runtime: 'automatic' }]] } } },
    { test: /\.css$/, use: [ui.resolve('style-loader'), ui.resolve('css-loader')] },
    { test: /\.(png|svg|woff2?)$/, type: 'asset/resource' },
  ] },
};
webpack(config, (error, stats) => {
  if (error || stats.hasErrors()) { process.stderr.write(String(error || stats.toString({ all: false, errors: true }))); process.exitCode = 1; return; }
  fs.writeFileSync(path.join(__dirname, 'dist/index.html'), '<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>워크로그 승인 실제 컴포넌트 검증</title><style>body{margin:0;padding:16px;font-family:Arial,"Malgun Gothic",sans-serif;color:#172b4d;background:#fff;box-sizing:border-box}*,*:before,*:after{box-sizing:border-box}#root{max-width:960px;margin:auto}</style><div id="root"></div><script src="preview.js"></script></html>');
  process.stdout.write('실제 React·Atlaskit 컴포넌트와 테스트용 API를 연결한 로컬 검증 화면 생성\n');
});
