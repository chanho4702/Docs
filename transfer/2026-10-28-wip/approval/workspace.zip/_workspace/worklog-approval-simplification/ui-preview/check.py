from pathlib import Path
import json
import re
from playwright.sync_api import sync_playwright

output = Path(__file__).parent / 'screenshots'
output.mkdir(exist_ok=True)
results = []
with sync_playwright() as p:
    browser = p.chromium.launch(headless=True, executable_path='C:/Users/DMOVE/AppData/Local/ms-playwright/chromium-1223/chrome-win64/chrome.exe')
    for width in (320, 480, 1280):
        for screen in ('issue', 'detail', 'appeal', 'dialog', 'settings'):
            page = browser.new_page(viewport={'width': width, 'height': 900}, device_scale_factor=1)
            errors = []
            page.on('pageerror', lambda error: errors.append(str(error)))
            page.route('https://**', lambda route: route.abort())
            page.goto(f'http://127.0.0.1:8766/?screen={screen}')
            page.wait_for_load_state('networkidle')
            page.wait_for_function('window.previewReady === true')
            page.screenshot(path=str(output / f'{screen}-{width}.png'), full_page=True)
            dimensions = page.evaluate('({width:innerWidth, documentWidth:document.documentElement.scrollWidth, height:document.documentElement.scrollHeight})')
            row = {'screen': screen, 'viewport': width, **dimensions, 'errors': errors.copy()}
            if screen == 'issue':
                page.get_by_test_id('worklog-create').click()
                row['createOpensModal'] = page.evaluate('window.previewModal.context.mode === "create"')
            if screen == 'appeal':
                page.get_by_role('button', name=re.compile('소명')).first.click()
                page.wait_for_selector('#worklog-request-reason')
                submit = page.locator('form button[type="submit"]')
                row['appealEmptyDisabled'] = submit.is_disabled()
                page.locator('#worklog-request-reason').fill('근무시간 증빙과 원래 승인 내용을 확인해 주세요.')
                row['appealFilledEnabled'] = submit.is_enabled()
                row['approvalStayedLocked'] = '수정 불가' in page.locator('body').inner_text()
                page.screenshot(path=str(output / f'appeal-form-{width}.png'), full_page=True)
            if screen == 'settings':
                page.locator('#worklog-close-days').fill('91')
                row['invalidDaysMarked'] = page.locator('#worklog-close-days').get_attribute('aria-invalid')
                row['invalidDaysSaveDisabled'] = page.get_by_role('button', name='정책 저장', exact=True).is_disabled()
                page.locator('#worklog-close-days').fill('5')
                row['validDaysSaveEnabled'] = page.get_by_role('button', name='정책 저장', exact=True).is_enabled()
            results.append(row)
            page.close()
    browser.close()
(output / 'browser-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(results, ensure_ascii=False, indent=2))
if any(row['documentWidth'] > row['width'] or row['errors'] for row in results):
    raise SystemExit(1)
