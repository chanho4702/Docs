const now = Date.parse('2026-10-15T01:00:00Z');
const people = [{ accountId: 'lead', displayName: '이팀장' }, { accountId: 'backup', displayName: '박승인자' }];
export class ApprovalError extends Error {}
export const invokeApproval = async (name, payload = {}) => {
  window.previewCalls ??= [];
  window.previewCalls.push({ name, payload });
  if (name === 'getLinkedIssueOverview') return { issueId: '10002', issueKey: 'DEMO-42' };
  if (name === 'getWorklogEditorContext') return { issueId: '10002', timeZone: 'Asia/Seoul', unit: 'MONTH', now, permissions: { canLog: true, canEditOwn: true, canDeleteOwn: true }, lockRanges: [], worklog: null, approvalPolicy: { required: false } };
  if (name === 'getIssueWorklogs') return {
    timeZone: 'Asia/Seoul', permissions: { canLog: true }, nextOffset: null, history: { enabled: true },
    worklogs: ['501', '502', '503'].map((worklogId, index) => ({ worklogId, issueId: '10002', authorAccountId: 'writer', authorDisplayName: '김기록', mine: true, started: now - index * 86400000, timeSpentSeconds: 7200, canEdit: index === 0, canDelete: index === 0, approval: { status: ['PENDING', 'APPROVED', 'REJECTED'][index], locked: index === 1 }, history: { entryCount: 2, changeCount: 1 } })),
  };
  if (name === 'getWorklogCertification') {
    const approved = payload.worklogId === '502';
    return { approval: { status: approved ? 'APPROVED' : 'UNSUBMITTED', steps: [{ approvers: [{ actorKey: 'lead' }] }] }, canRequest: !approved, canAppeal: approved, locked: approved, lockReason: approved ? 'APPROVED' : null, approvers: people, defaultApproverIds: ['lead'], approvalHistory: [{ events: [
      { eventId: 'requested', eventType: 'REQUESTED', actorKey: null, occurredAt: now - 7200000 },
      { eventId: 'approved', eventType: approved ? 'APPROVED' : 'REJECTED', actorKey: 'lead', occurredAt: now - 3600000, reason: approved ? null : '작업 기간과 기록한 시간을 확인해 다시 요청해 주세요.' },
    ] }], approvalHistoryPage: { hasMore: false } };
  }
  if (name === 'listWorklogApprovalCandidates') return { users: people, defaultApproverIds: ['lead'] };
  if (name === 'getApprovalSettings') return { workforceLinkEnabled: true, worklogAutoRequest: true, timesheetAutoCloseDays: 3 };
  if (name === 'getStorageUsage') return { management: { level: 'WARNING', action: 'EXPORT_AND_REVIEW', usedPercent: 87, automaticDeletion: false } };
  if (name === 'resolveUsers') return { users: people };
  if (name === 'saveApprovalSettings') return { workforceLinkEnabled: true, ...payload };
  if (name === 'createWorklog') return { approval: { status: 'PENDING' }, worklog: { worklogId: '504' } };
  if (['requestWorklogApproval', 'appealWorklogApproval'].includes(name)) return { status: 'PENDING', created: true };
  return {};
};
