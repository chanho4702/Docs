export const resolveUsersInChunks = async (ids) => ids.map((accountId) => ({ accountId, displayName: accountId === 'lead' ? '이팀장' : '박승인자' }));
