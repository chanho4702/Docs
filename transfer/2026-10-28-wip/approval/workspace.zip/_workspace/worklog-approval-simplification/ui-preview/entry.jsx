import React from 'react';
import { createRoot } from 'react-dom/client';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { WorklogTab } from '../../../static/ui/src/features/worklog/WorklogTab';
import WorklogApprovalPanel from '../../../static/ui/src/features/worklog/WorklogApprovalPanel';
import WorklogDialog from '../../../static/ui/src/features/worklog/WorklogDialog';
import WorklogApprovalSettings from '../../../static/ui/src/features/settings/WorklogApprovalSettings';
import StorageNotice from '../../../static/ui/src/features/settings/StorageNotice';
import { t } from '../../../static/ui/src/utils/i18n';
import { i18nReady } from '../../../static/ui/src/stores/useI18nStore';

const client = new QueryClient({ defaultOptions: { queries: { retry: false } } });
const mode = new URLSearchParams(window.location.search).get('screen') ?? 'issue';
const props = { issueId: '10002', issueKey: 'DEMO-42', locale: 'ko-KR', t };
const screens = {
  issue: <WorklogTab {...props} />,
  detail: <WorklogApprovalPanel {...props} worklogId="501" />,
  appeal: <WorklogApprovalPanel {...props} worklogId="502" />,
  dialog: <WorklogDialog {...props} mode="create" onDone={()=>{window.previewSaved=true;}} onCancel={()=>{}} />,
  settings: <><StorageNotice isAdmin t={t} onManage={() => { window.previewAction = 'storage'; }} /><WorklogApprovalSettings /></>,
};
i18nReady.then(() => {
  createRoot(document.getElementById('root')).render(<QueryClientProvider client={client}>{screens[mode]}</QueryClientProvider>);
  window.previewReady = true;
});
