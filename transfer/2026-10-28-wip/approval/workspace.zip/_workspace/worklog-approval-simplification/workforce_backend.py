from pathlib import Path

root = Path('C:/CloudJira/moves-workforce')
def edit(name, old, new):
    p = root / name
    text = p.read_text(encoding='utf-8-sig')
    if old not in text:
        raise RuntimeError('일치 구문 없음: ' + name + ' ' + old[:70])
    p.write_text(text.replace(old, new), encoding='utf-8', newline='\n')

(root/'src/integration/approval/contract.js').write_text(Path('src/integration/workforce/contract.js').read_text(encoding='utf-8'),encoding='utf-8',newline='\n')

(root/'src/integration/approval/worklogApproval.js').write_text('''import { createHash } from 'crypto';
import { startedMsOf } from './certification';

const fingerprint = (row) => {
    const started = Number.isSafeInteger(row.startedMs) ? row.startedMs : startedMsOf(row.started);
    const seconds = Number(row.claimedSeconds ?? row.timeSpentSeconds);
    if (!row.issueId || !row.accountId || !Number.isSafeInteger(started) || !Number.isSafeInteger(seconds)) return null;
    return createHash('sha256').update(JSON.stringify([String(row.worklogId ?? row.id), String(row.issueId), row.accountId, started, seconds]), 'utf8').digest('base64url').slice(0, 16);
};

export const approvalOfWorklog = (row, docs, now) => {
    const id = String(row.worklogId ?? row.id ?? '');
    const started = startedMsOf(row.started);
    const candidates = [...(docs?.values?.() ?? [])].filter((doc) => doc.accountId === row.accountId);
    const doc = candidates.find((item) => item.approval?.entries.some((entry) => entry[0] === id))
        ?? candidates.find((item) => started >= item.start && started < item.end);
    const entry = doc?.approval?.entries.find((item) => item[0] === id);
    const unknown = { status: 'UNKNOWN', countableSeconds: 0, normalOrigin: false, locked: false };
    if (!entry || !doc?.approval) return unknown;
    const [worklogId, status, requestId, decidedBy, decidedAt, origin, approvedFingerprint, seconds] = entry;
    const normalOrigin = ['APP', 'WORKFORCE', 'PREAPPROVAL'].includes(origin);
    const matched = fingerprint(row) === approvedFingerprint;
    const closed = Number.isFinite(doc.approval.closeAt) && now >= doc.approval.closeAt;
    const approved = status === 'APPROVED';
    return { worklogId, status: !matched ? 'CHANGED' : status, requestId, decidedBy, decidedAt, normalOrigin,
        locked: approved || closed, lockReason: approved ? 'APPROVED' : closed ? 'PERIOD_CLOSED' : null,
        countableSeconds: normalOrigin && matched && (!closed || approved) ? seconds : 0 };
};
''', encoding='utf-8', newline='\n')

edit('src/integration/approval/certification.js', '            entries,\n', '            entries,\n            approval: body.approval ?? null,\n')
edit('src/integration/approval/controlDoc.js', '            ch: b.ch ?? null,', '            ch: b.ch ?? null,\n            wa: b.wa ?? null,')
edit('src/integration/approval/issueSetting.js', '        ...(fl ? { fl } : {}),', "        ...(fl ? { fl } : {}),\n        ...((changes.wa ?? current?.wa) ? { wa: changes.wa ?? current.wa } : {}),")
edit('src/integration/approval/issueSetting.js', 'const publish = !current ||', 'const publish = JSON.stringify(current?.wa ?? null) !== JSON.stringify(body.wa ?? null) || !current ||')
edit('src/resolver/approvalLink/IssueApprovalSettingService.js', "if (item.pol !== undefined) fail('INVALID_TARGET');", "if (item.pol !== undefined) fail('INVALID_TARGET');\n        if (item.wa !== undefined && !validateBody(TYP.RMS_ISSUE, {s:null,e:null,pa:null,by:'validation',tk:null,rev:0,wa:item.wa})) fail('INVALID_TARGET');")
edit('src/resolver/approvalLink/IssueApprovalSettingService.js', 'fl: current.body.fl ?? null, by:', 'fl: current.body.fl ?? null, wa: current.body.wa ?? null, by:')
edit('src/resolver/approvalLink/IssueApprovalSettingService.js', 'capabilities: { fl: rx.includes(RX_FLOW_FIELD),', "capabilities: { worklogApproval: rx.includes('rms.issue.wa'), fl: rx.includes(RX_FLOW_FIELD),")

edit('src/resolver/approvalLink/ApprovalCertReader.js', "import", "import",)
p=root/'src/resolver/approvalLink/ApprovalCertReader.js'
s=p.read_text(encoding='utf-8')
s="import { randomUUID } from 'crypto';\nimport { approvalOfWorklog } from '../../integration/approval/worklogApproval';\nimport { getSettingDataService } from '../backoffice/setting/SettingService';\nimport { resolveInstallCloudId } from './InstallCloudId';\n"+s
s=s.replace("${viewer?.accountId ?? '-'}", "${viewer?.accountId ?? randomUUID()}")
s += '''
// 집계 직전에 사용자 자격으로 검증한다. 서명 확인 불가는 주장 시간을 확정 시간으로 바꾸지 않는다.
export const applyWorklogApproval = async (rows, viewer = null, options = {}) => {
    const list = Array.isArray(rows) ? rows : [];
    const settings = await getSettingDataService();
    if (settings.approvalLinkMode !== 'ON' || !list.length) return list;
    const context = viewer ?? { cloudId: resolveInstallCloudId().cloudId };
    const input = list.map((row) => ({ ...row, worklogId: row.worklogId ?? row.id,
        accountId: row.accountId ?? row.author?.accountId, issueId: row.issueId ?? row.issue?.id }));
    const loaded = await loadApprovalCertDocs({ ...options, as: 'user', viewer: context, pairs: certPairsOfRows(input) });
    const now = options.now ?? Date.now();
    return input.map((row) => {
        const approval = approvalOfWorklog(row, loaded.docs, now);
        return { ...row, claimedSeconds: row.claimedSeconds ?? row.timeSpentSeconds,
            timeSpentSeconds: approval.countableSeconds, countableSeconds: approval.countableSeconds, approval };
    });
};
'''
s=s.replace('const { rows: out, expectedRows, summary } = applyCertToCostRows(input, loaded.docs, { projectIssues });', '''const settings = await getSettingDataService();
    if (settings.approvalLinkMode === 'ON') {
        const now = options.now ?? Date.now();
        const counted = input.map((row) => ({ ...row, claimedSeconds: row.claimedSeconds ?? row.timeSpentSeconds,
            timeSpentSeconds: approvalOfWorklog(row, loaded.docs, now).countableSeconds }));
        return { rows: counted, expectedRows: input, certification: { applied: true }, digest: loaded.digest };
    }
    const { rows: out, expectedRows, summary } = applyCertToCostRows(input, loaded.docs, { projectIssues });''')
p.write_text(s,encoding='utf-8',newline='\n')

for name,relative in [('src/resolver/resourceAnalysis/ResourceWorklogFetcher.js','../approvalLink/ApprovalCertReader'),('src/resolver/utils/worklog/WorklogService.js','../../approvalLink/ApprovalCertReader')]:
    p=root/name
    s=p.read_text(encoding='utf-8-sig')
    s="import { applyWorklogApproval } from '"+relative+"';\n"+s
    s=s.replace('return results.flat();','return applyWorklogApproval(results.flat());')
    if 'ResourceWorklogFetcher' in name:
        s=s.replace('worklogId:        log.id ?? null,','worklogId:        log.id ?? null,\n    issueId:          String(issue.id ?? log.issueId),')
    else:
        s=s.replace('const cached = await kvs.get(cacheKey, {','const cached = null; /* 집계는 매번 현재 승인 문서를 적용한다. */\n    /* const cached = await kvs.get(cacheKey, {').replace('metadataFields: [MetadataField.EXPIRE_TIME]\n    });','metadataFields: [MetadataField.EXPIRE_TIME]\n    }); */')
    p.write_text(s,encoding='utf-8',newline='\n')

p=root/'src/api/jira/worklog/CollabWorklogFetcher.js'
s=p.read_text(encoding='utf-8-sig')
s="import { applyWorklogApproval } from '../../../resolver/approvalLink/ApprovalCertReader';\n"+s
s=s.replace('return { items: results.filter(Boolean), truncated: state.truncated || !!budget?.exhausted };', '''const items = results.filter(Boolean);
    const counted = await applyWorklogApproval(items.flatMap((item) => item.worklogs.map((row) => ({ ...row, issueId: row.issueId ?? item.issue.id }))));
    let cursor = 0;
    items.forEach((item) => { item.worklogs = counted.slice(cursor, cursor + item.worklogs.length); cursor += item.worklogs.length; });
    return { items, truncated: state.truncated || !!budget?.exhausted };''')
s=s.replace('const hit = await kvs.get(cacheKey, { metadataFields: [MetadataField.EXPIRE_TIME] });','const hit = null;')
p.write_text(s,encoding='utf-8',newline='\n')

p=root/'src/resolver/approvalLink/IssueWorklogControlService.js'
s=p.read_text(encoding='utf-8-sig')
s="import { verifyOwnIssueSetting } from '../../integration/approval/issueSetting';\nimport { localDateOf, dateWindowOf, inWindow } from '../../integration/approval/controlDoc';\n"+s
s=s.replace('return { target: target !== false, writeChannel, createChannel: writeChannel };', '''const createChannel = writeChannel === WriteChannel.HANDOFF && target === true && link.linked
        && link.control?.wa?.v === 1 && linkSigner.ready() ? WriteChannel.DIRECT : writeChannel;
    return { target: target !== false, writeChannel, createChannel };''')
s=s.replace('(await creationState(issue, link, settings, deps)).writeChannel','(await creationState(issue, link, settings, deps)).createChannel',1)
s=s.replace('    const body = {\n        started,', '''    if (settings.approvalLinkMode === 'ON' && link.linked) {
        if (!envelope || !link.control?.wa || now - link.control.iat > 36 * 3600000) throw new LogicalError(ErrorCodes.WORKLOG_LINK_UNCONFIRMED, ErrorCodes.WORKLOG_LINK_UNCONFIRMED);
        const own = verifyOwnIssueSetting({entry: issue.properties?.[ISSUE_SETTING_PROPERTY_KEY],cloudId:context.cloudId,
            projectId:issue.fields.project.id,issueId,now,signer:linkSigner});
        const days = own?.body?.wa?.closeDays ?? link.control.wa.closeDays;
        const day = localDateOf(startedMs, link.control.tz);
        const today = localDateOf(now, link.control.tz);
        if (!day || !today) throw new LogicalError(ErrorCodes.WORKLOG_LINK_UNCONFIRMED, ErrorCodes.WORKLOG_LINK_UNCONFIRMED);
        const [year, month] = day.split('-').map(Number);
        const boundary = new Date(Date.UTC(year,month,1 + days)).toISOString().slice(0,10);
        if (days > 0 && today >= boundary) throw new LogicalError('WORKLOG_PERIOD_LOCKED','WORKLOG_PERIOD_LOCKED');
        if (own?.body?.s && day < own.body.s || own?.body?.e && day > own.body.e) throw new LogicalError('WORKLOG_OUTSIDE_ISSUE_WINDOW','WORKLOG_OUTSIDE_ISSUE_WINDOW');
        if (link.control.dw && !(own?.body?.s || own?.body?.e)) {
            const fields = (await loadIssueAsUser(issueId, `project,duedate,${link.control.sf ?? ''}`)).fields;
            if (!inWindow({startedMs,window:dateWindowOf({sf:link.control.sf,fields}),timeZone:link.control.tz}).inside) throw new LogicalError('WORKLOG_OUTSIDE_ISSUE_WINDOW','WORKLOG_OUTSIDE_ISSUE_WINDOW');
        }
    }
    const body = {
        started,''',1)
s=s.replace('        signed: Boolean(envelope),','        signed: Boolean(envelope),\n        approvalStatus: envelope ? \'PROCESSING\' : null,')
p.write_text(s,encoding='utf-8',newline='\n')
print('Workforce backend: 생성, 팀장 정책, 검증 문서 및 공용 집계 연결 완료')
