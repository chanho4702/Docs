import { createHash } from 'crypto';
import { approvalOfWorklog } from '../worklogApproval';

const started = Date.parse('2026-10-10T00:00:00Z');
const row = { worklogId: '1', issueId: '10', accountId: 'a', started: '2026-10-10T00:00:00Z', timeSpentSeconds: 3600 };
const fp = createHash('sha256').update(JSON.stringify(['1', '10', 'a', started, 3600])).digest('base64url').slice(0, 16);
const docs = ({ status = 'PENDING', closeAt = 500, globalClose = 100, origin = 'APP', legacy = false } = {}) => {
  const entry = ['1', status, null, null, null, origin, fp, 3600, started];
  if (!legacy) entry.push(closeAt);
  return new Map([['doc', { accountId: 'a', approval: { closeAt: globalClose, entries: [entry] } }]]);
};

test('진행 중 정상 기록은 집계하고 해당 이슈의 마감부터 미승인 시간을 제외한다', () => {
  expect(approvalOfWorklog(row, docs(), 499)).toMatchObject({ countableSeconds: 3600, locked: false });
  expect(approvalOfWorklog(row, docs(), 500)).toMatchObject({ countableSeconds: 0, locked: true, lockReason: 'PERIOD_CLOSED' });
});

test('수동 재개방은 전역 마감일이 지나도 건별 미승인 집계를 허용한다', () => {
  expect(approvalOfWorklog(row, docs({ closeAt: null }), 1000)).toMatchObject({ countableSeconds: 3600, locked: false });
});

test('승인된 기록이 외부에서 바뀌어도 확정 시간은 보존하고 변경 상태를 알린다', () => {
  expect(approvalOfWorklog({ ...row, timeSpentSeconds: 7200 }, docs({ status: 'APPROVED' }), 1000))
    .toMatchObject({ status: 'CHANGED', countableSeconds: 3600, locked: true, lockReason: 'APPROVED' });
});

test('정상 출처가 없거나 미승인 내용이 바뀌면 집계하지 않는다', () => {
  expect(approvalOfWorklog(row, docs({ status: 'APPROVED', origin: 'NONE' }), 1000).countableSeconds).toBe(0);
  expect(approvalOfWorklog({ ...row, timeSpentSeconds: 7200 }, docs(), 1).countableSeconds).toBe(0);
  expect(approvalOfWorklog(row, new Map(), 1)).toMatchObject({ status: 'UNKNOWN', countableSeconds: 0 });
});

test.each(['APP', 'WORKFORCE', 'APP_CHANGED', 'WF_CHANGED'])('서버가 증명한 정상 출처 %s는 동일하게 집계한다', (origin) => {
  expect(approvalOfWorklog(row, docs({ status: 'APPROVED', origin }), 1000).countableSeconds).toBe(3600);
});

test('기존9칸 계약은 전역 마감일을 따른다', () => {
  expect(approvalOfWorklog(row, docs({ legacy: true }), 100).countableSeconds).toBe(0);
});
