from pathlib import Path
import hashlib
import re

approval = Path('C:/CloudJira/moves-approval-jira')
workforce = Path('C:/CloudJira/moves-workforce')
contract = (approval / 'src/integration/workforce/contract.js').read_text(encoding='utf-8')
(workforce / 'src/integration/approval/contract.js').write_text(contract, encoding='utf-8', newline='\n')
digest = hashlib.sha256(contract.encode('utf-8')).hexdigest()
vectors = workforce / 'src/integration/approval/__test__/vectors.test.js'
text = vectors.read_text(encoding='utf-8')
text = re.sub(r"('integration/approval/contract.js', 'integration/workforce/contract.js', ')[a-f0-9]{64}", lambda match: match[1] + digest, text)
vectors.write_text(text, encoding='utf-8', newline='\n')
decoder = workforce / 'src/integration/approval/worklogApproval.js'
text = decoder.read_text(encoding='utf-8')
text = text.replace('const closed = Number.isFinite(doc.approval.closeAt) && now >= doc.approval.closeAt;', 'const closeAt = entry.length >= 10 ? entry[9] : doc.approval.closeAt;\n    const closed = Number.isFinite(closeAt) && now >= closeAt;')
text = text.replace('countableSeconds: normalOrigin && matched && (!closed || approved) ? seconds : 0', 'countableSeconds: normalOrigin && (approved || (matched && !closed)) ? seconds : 0')
text = text.replace("['APP', 'WORKFORCE', 'PREAPPROVAL'].includes(origin)", "['APP', 'WORKFORCE', 'APP_CHANGED', 'WF_CHANGED'].includes(origin)")
decoder.write_text(text, encoding='utf-8', newline='\n')
test = approval / '_workspace/worklog-approval-simplification/worklogApproval.fixture.js'
if test.exists():
    (workforce / 'src/integration/approval/__test__/worklogApproval.test.js').write_text(test.read_text(encoding='utf-8'), encoding='utf-8', newline='\n')
print('Shared contract and per-worklog closure decoder synchronized:', digest)
