from pathlib import Path
root=Path('C:/CloudJira/moves-workforce')
p=root/'src/api/jira/worklog/CollabWorklogFetcher.js'
s=p.read_text(encoding='utf-8')
s=s.replace("    return { worklogs: items.flatMap((i) => i.worklogs), truncated: truncated || searchTruncated };", "    const counted = await applyWorklogApproval(items.flatMap((i) => i.worklogs), { cloudId },\n        { includeHidden: true, startDate, endDate, issueIds: issues.map((issue) => String(issue.id)) });\n    return { worklogs: authors.length ? counted.filter((row) => allowed.has(row.accountId)) : counted, truncated: truncated || searchTruncated };")
p.write_text(s,encoding='utf-8')
p=root/'src/api/jira/worklog/CollabWorklogFetcher.js'
s=p.read_text(encoding='utf-8')
s=s.replace("    const counted = await applyWorklogApproval(items.flatMap((item) => item.worklogs.map((row) => ({ ...row, issueId: row.issueId ?? item.issue.id }))));\n    let cursor = 0;\n    items.forEach((item) => { item.worklogs = counted.slice(cursor, cursor + item.worklogs.length); cursor += item.worklogs.length; });\n", "")
p.write_text(s,encoding='utf-8')
p=root/'src/resolver/projectCollab/CollabCalendarService.js'
s=p.read_text(encoding='utf-8')
if "import { applyWorklogApproval }" not in s:
 s="import { applyWorklogApproval } from '../approvalLink/ApprovalCertReader';\n"+s
 s=s.replace("    return {\n        data: collected.items.map(({ issue, worklogs }) => toCollabCalendarIssue(issue, worklogs)),", """    const input = collected.items.flatMap(({issue,worklogs}) => worklogs.map((row)=>({...row,issueId:String(issue.id)})));
    const counted = await applyWorklogApproval(input, {accountId:principal?.accountId,cloudId},
        {includeHidden:true,selfOnly:true,startDate,endDate,issueIds:issues.map((issue)=>String(issue.id))});
    return {
        data: issues.map((issue)=>toCollabCalendarIssue(issue,counted.filter((row)=>String(row.issueId)===String(issue.id)))).filter((issue)=>(issue.fields?.worklog?.worklogs??[]).length),""")
p.write_text(s,encoding='utf-8')
p=root/'src/resolver/projectCollab/CollabDto.js'
s=p.read_text(encoding='utf-8').replace("    comment: log?.comment,", "    comment: log?.comment,\n    ...(log?.approval ? { approval: log.approval, claimedSeconds: log.claimedSeconds, countableSeconds: log.countableSeconds } : {}),")
p.write_text(s,encoding='utf-8')
p=root/'src/resolver/projectCollab/CollabCalendarService.js'
s=p.read_text(encoding='utf-8').replace("counted.filter((row)=>String(row.issueId)===String(issue.id))", "counted.filter((row)=>String(row.issueId)===String(issue.id)).map((row)=>({...row,id:row.id??row.worklogId,author:row.author??{accountId:row.accountId}}))")
p.write_text(s,encoding='utf-8')
for rel,mockpath in [
 ('src/resolver/projectCalendar/__test__/ProjectCalendarTeamAxis.test.js','../../approvalLink/ApprovalCertReader'),
 ('src/resolver/projectCollab/__test__/CollabWorklogServices.test.js','../../approvalLink/ApprovalCertReader'),
 ('src/resolver/projectCollab/__test__/CollabApprovalHiddenRows.test.js','../../approvalLink/ApprovalCertReader'),
 ('src/api/jira/worklog/__test__/CollabWorklogFetcher.test.js','../../../../resolver/approvalLink/ApprovalCertReader'),
 ('src/api/jira/worklog/__test__/CollabApprovalHidden.test.js','../../../../resolver/approvalLink/ApprovalCertReader')]:
 p=root/rel
 s=p.read_text(encoding='utf-8')
 statement=f"jest.mock('{mockpath}', () => ({{ applyWorklogApproval: async (rows) => rows }}));\n"
 if statement not in s:s=statement+s
 p.write_text(s,encoding='utf-8')
p=root/'src/resolver/resourceAnalysis/__test__/ResourceAnalysisDenominator.test.js'
s=p.read_text(encoding='utf-8').replace("expect(mockGetWorklogs).toHaveBeenCalledWith({\n            projectId:", "expect(mockGetWorklogs).toHaveBeenCalledWith({\n            includeHidden: true, viewer: null,\n            projectId:")
p.write_text(s,encoding='utf-8')
p=root/'src/resolver/approvalLink/ApprovalCertReader.js'
s=p.read_text(encoding='utf-8').replace("[principal.accountId, ...(principal.leadingScopeAccountIds ?? [])]", "[principal.accountId, ...(options.selfOnly ? [] : principal.leadingScopeAccountIds ?? [])]")
p.write_text(s,encoding='utf-8')
p=root/'src/resolver/projectCalendar/ProjectCalendarService.js'
s=p.read_text(encoding='utf-8')
s=s.replace("const chunks = worklogChunks.filter(Boolean);", "const chunks = issues.map((issue) => worklogChunks.find((chunk) => chunk?.id === issue.id) ?? { ...issue, fields: { ...issue.fields, worklog: { ...issue.fields?.worklog, worklogs: [] } } });")
s=s.replace("const approved = await applyWorklogApproval(input);", "const approved = await applyWorklogApproval(input, { accountId: principal?.accountId }, { includeHidden: true, selfOnly: true, startDate, endDate, issueIds: issues.map((issue)=>String(issue.id)) });")
s=s.replace("worklogs: (issue.fields?.worklog?.worklogs ?? []).map((row) => byId.get(String(row.id))).filter(Boolean)", "worklogs: approved.filter((row) => String(row.issueId) === String(issue.id)).map((row) => ({ ...row, id: row.id ?? row.worklogId, author: row.author ?? { accountId: row.accountId } }))")
s=s.replace("    const byId = new Map(approved.map((row) => [String(row.id ?? row.worklogId), row]));\n", "")
p.write_text(s,encoding='utf-8')
p=root/'src/resolver/approvalLink/__test__/WorklogApprovalAggregate.test.js'
p.write_text('''const mockGet = jest.fn();
const mockPost = jest.fn();
jest.mock('../../../api/jira/util/RequestJiaJson',()=>({requestJiraJson:(...args)=>mockGet(...args),postJiraJson:(...args)=>mockPost(...args)}));
jest.mock('../../backoffice/setting/SettingService',()=>({getSettingDataService:async()=>({approvalLinkMode:'ON'})}));
jest.mock('../../../permission/PrincipalResolver',()=>({resolvePrincipal:async()=>({accountId:'viewer',leadingScopeAccountIds:['u1']})}));
jest.mock('../ApprovalControlLookup',()=>({createApprovalControlLookup:()=>({usable:true,isApprovalHidden:async()=>true})}));
jest.mock('@forge/api',()=>({route:(parts,...values)=>parts.reduce((text,part,i)=>text+part+(values[i]??''),'')}));
import { applyWorklogApproval,resetApprovalCertCache } from '../ApprovalCertReader';
import { CLOUD_ID,NOW,testEnv,testKeyring,certDocValue,certBody } from '../../../integration/approval/__test__/testKeys';
import { createHash } from 'crypto';
const started='2026-10-02T09:00:00.000+0900';
const row={worklogId:'501',issueId:'100',accountId:'u1',started,timeSpentSeconds:3600,date:'2026-10-02'};
const fp=createHash('sha256').update(JSON.stringify(['501','100','u1',Date.parse(started),3600])).digest('base64url').slice(0,16);
const value=()=>certDocValue({body:certBody({w:[['501',3600]],wn:1,cs:3600,cn:1,mn:0,sc:0,sn:0,
 approval:{v:1,closeAt:null,entries:[['501','APPROVED','11111111-1111-4111-8111-111111111111','lead',NOW,'APP',fp,3600,Date.parse(started),null]],truncated:false}})});
const options={now:NOW,env:testEnv,keyring:testKeyring()};
beforeEach(()=>{jest.clearAllMocks();resetApprovalCertCache();
 mockGet.mockImplementation(async({url})=>url.includes('/user/properties?')?{keys:[{key:'movesApproval.cert.2026-10'}]}:{value:value()});
 mockPost.mockImplementation(async({url})=>url.includes('permissions/check')?{projectPermissions:[{permission:'BROWSE_PROJECTS',issues:[100]}]}:
 [{id:'501',issueId:'100',author:{accountId:'u1'},started,timeSpentSeconds:3600}]);
});
test('현재 asUser 행과 이슈 열람을 확인한 뒤 서명된 승인만 집계하며 타인 결재 정보는 내보내지 않는다',async()=>{
 const out=await applyWorklogApproval([row],{accountId:'viewer',cloudId:CLOUD_ID},options);
 expect(out[0].timeSpentSeconds).toBe(3600);
 expect(out[0].approval.status).toBe('APPROVED');
 expect(out[0].approval).not.toHaveProperty('decidedBy');
 expect(out[0].approval).not.toHaveProperty('requestId');
 expect(mockPost.mock.calls.every(([arg])=>arg.as==='user')).toBe(true);
 expect(mockGet.mock.calls.every(([arg])=>arg.as==='app')).toBe(true);
});
test('열람 권한이 사라진 이슈는 승인 프로퍼티를 읽지 않고 집계에서 제외한다',async()=>{
 mockPost.mockResolvedValue({projectPermissions:[]});
 expect(await applyWorklogApproval([row],{accountId:'viewer',cloudId:CLOUD_ID},options)).toEqual([]);
 expect(mockGet).not.toHaveBeenCalled();
});
test('현재 워크로그 작성자가 바뀌면 기존 입력 작성자의 서명 문서를 읽지 않는다',async()=>{
 mockPost.mockImplementation(async({url})=>url.includes('permissions/check')?{projectPermissions:[{permission:'BROWSE_PROJECTS',issues:[100]}]}:
 [{id:'501',issueId:'100',author:{accountId:'another'},started,timeSpentSeconds:3600}]);
 expect(await applyWorklogApproval([row],{accountId:'viewer',cloudId:CLOUD_ID},options)).toEqual([]);
 expect(mockGet).not.toHaveBeenCalled();
});
test('일반 숫자 집계는 공개 행이 없어도 현재 팀원 숨김 승인분을 복구한다',async()=>{
 mockPost.mockImplementation(async({url,as})=>{
   if(url.includes('permissions/check'))return {projectPermissions:[{permission:'BROWSE_PROJECTS',issues:[100]}]};
   if(url.includes('issue/bulkfetch'))return {issues:[{id:'100',key:'A-1',fields:{project:{id:'10'}}}]};
   if(as==='app')return [{id:'501',issueId:'100',author:{accountId:'u1'},started,timeSpentSeconds:3600}];
   return [];
 });
 const out=await applyWorklogApproval([],{accountId:'viewer',cloudId:CLOUD_ID},{...options,includeHidden:true,issueIds:['100'],startDate:'2026-10-01',endDate:'2026-10-31'});
 expect(out).toHaveLength(1);
 expect(out[0]).toMatchObject({accountId:'u1',timeSpentSeconds:3600,approvalHidden:true});
 expect(out[0]).not.toHaveProperty('comment');
 expect(mockGet.mock.calls.filter(([arg])=>arg.url.includes('/user/properties?')).every(([arg])=>arg.url.endsWith('=u1')||arg.url.endsWith('=viewer'))).toBe(true);
});
''',encoding='utf-8')
