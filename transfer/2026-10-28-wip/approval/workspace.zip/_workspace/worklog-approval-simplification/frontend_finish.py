from pathlib import Path
import json,re
root=Path('C:/CloudJira/moves-approval-jira')
def edit(name,fn,base=root):
 p=base/name;p.write_text(fn(p.read_text(encoding='utf-8')),encoding='utf-8')
kr={
 'loading':'승인 상태를 확인하고 있습니다.','statusLabel':'승인 상태','locked':'수정 불가','request':'승인 요청','changeApprover':'승인자 변경','appeal':'소명·재승인 요청','appealHint':'검토 중에도 기존 승인과 수정 잠금은 유지됩니다.','approver':'누가 승인하나요?','chooseApprover':'이름으로 승인자 검색','noApprover':'승인자를 검색해 선택하세요.','reason':'요청 사유 (선택)','requiredReason':'소명 사유 (필수)','history':'승인·반려 이력','noHistory':'아직 승인 이력이 없습니다.','unknownPerson':'사용자 정보 확인 중','system':'자동 접수','submitted':'승인 요청이 접수되었습니다.','saveHint':'저장한 워크로그는 정책에 따라 승인 요청됩니다. 목록의 상세에서 승인자를 선택하거나 요청 상태를 확인하세요.','issueHint':'작업 로그에서 기록을 입력하고 승인 상태와 이력을 확인하세요.','remaining':'{count}건은 아직 처리되지 않았습니다. 선택된 항목을 계속 승인하세요.',
 'lock':{'APPROVED':'승인된 기록은 수정하거나 삭제할 수 없습니다.','PERIOD_CLOSED':'승인 기간이 마감되어 수정하거나 삭제할 수 없습니다.'},
 'status':dict(zip(['UNKNOWN','UNSUBMITTED','NEEDS_APPROVER','PENDING','APPROVED','REJECTED','CANCELED','EXPIRED','DELETED','CHANGED','APPEAL_PENDING','CLOSED','PROCESSING','SUBMISSION_FAILED','NONE'],['상태 확인 필요','승인 요청 전','승인자 선택 필요','승인 대기','승인됨','반려됨','요청 취소','요청 만료','삭제됨','변경 확인 필요','소명 검토 중','기간 마감','접수 처리 중','접수 실패','승인 요청 전'])),
 'saved':{'PENDING':'저장되었습니다. 승인 대기 중입니다.','NEEDS_APPROVER':'기록은 저장되었습니다. 목록의 상세에서 승인자를 선택해 요청하세요.','UNSUBMITTED':'기록은 저장되었습니다. 목록의 상세에서 승인 요청할 수 있습니다.','CLOSED':'기록은 저장되었지만 승인 기간이 마감되었습니다. 상세에서 소명 가능 여부를 확인하세요.','SUBMISSION_FAILED':'기록은 저장되었지만 승인 요청에 실패했습니다. 다시 저장하지 말고 목록의 상세에서 승인 요청을 재시도하세요.','PROCESSING':'기록은 저장되었습니다. 승인 요청 접수를 확인 중입니다.','SAVED':'저장되었습니다.'},
 'event':{'REQUESTED':'승인 요청','APPROVED':'승인','REJECTED':'반려','CANCELED':'요청 취소','EXPIRED':'요청 만료','AUTO_EXPIRED':'요청 만료','DECIDED':'승인 결정','APPROVER_ADDED':'승인자 추가','DELEGATED':'대리 승인','RESUBMITTED':'재승인 요청','CONTENT_CHANGED':'기록 변경','REMINDER_SENT':'알림 전송'},
 'settings':{'title':'워크로그 승인','intro':'기록을 저장한 뒤 승인받는 규칙을 설정합니다.','when':'언제 승인 요청하나요?','automatic':'저장하면 자동으로 요청','manual':'작성자가 직접 요청','close':'월이 끝난 뒤 며칠까지 승인하나요?','closeHint':'0일은 월말 마감입니다. 예: 5일이면 다음 달 5일까지 승인합니다. 마감 후 통계에는 승인된 정상 입력 기록만 반영됩니다.','invalidDays':'0~90 사이의 정수를 입력하세요.','approverHint':'기본은 작성자의 팀장입니다. 직접 요청할 때 다른 승인자를 선택할 수 있습니다.','protection':'승인·마감 후 수정','protectionHint':'수정과 삭제가 차단됩니다. 작성자는 사유를 적어 소명·재승인을 요청할 수 있습니다.','linked':'Workforce에 연결된 이슈는 Workforce 프로젝트의 승인 설정을 우선합니다. 아래는 별도 규칙이 없는 이슈의 기본값입니다.','advanced':'고급 설정','setup':'입력 창구 설정 안내'},
 'storage':{'NOTICE':'보관 용량을 미리 점검하세요.','WARNING':'보관 파일을 내보낼 시점입니다.','CRITICAL':'저장 공간이 거의 찼습니다.','steps':'자료를 파일로 내보내고 파일을 확인한 다음, 시스템에서 보관 확정 범위만 정리하세요. 감사 자료를 자동으로 삭제하지 않습니다.','action':'내보내기·보관 관리로 이동'}
}
en={
 'loading':'Checking approval status…','statusLabel':'Approval','locked':'Read only','request':'Request approval','changeApprover':'Change approver','appeal':'Request review / reapproval','appealHint':'The existing approval and edit lock remain in place during review.','approver':'Who approves?','chooseApprover':'Search approvers by name','noApprover':'Search for and select an approver.','reason':'Reason (optional)','requiredReason':'Review reason (required)','history':'Approval and rejection history','noHistory':'No approval history yet.','unknownPerson':'Loading user information','system':'Automatic request','submitted':'Approval requested.','saveHint':'Saved worklogs follow the approval policy. Open a record’s details to choose an approver or check its status.','issueHint':'Use Work logs to record time and view approval status and history.','remaining':'{count} items are still unprocessed. Continue approving the selected items.',
 'lock':{'APPROVED':'Approved records cannot be edited or deleted.','PERIOD_CLOSED':'The approval period has closed. This record cannot be edited or deleted.'},
 'status':dict(zip(kr['status'],['Check status','Not requested','Choose approver','Awaiting approval','Approved','Rejected','Canceled','Expired','Deleted','Changed','Review pending','Period closed','Processing','Request failed','Not requested'])),
 'saved':{'PENDING':'Saved. Awaiting approval.','NEEDS_APPROVER':'Saved. Open the record details to choose an approver.','UNSUBMITTED':'Saved. Request approval from the record details.','CLOSED':'Saved, but the approval period is closed. Check the record details for review options.','SUBMISSION_FAILED':'Saved, but the approval request failed. Do not save again; retry approval from the record details.','PROCESSING':'Saved. The approval request is being processed.','SAVED':'Saved.'},
 'event':dict(zip(kr['event'],['Requested','Approved','Rejected','Canceled','Expired','Expired','Decision','Approver added','Delegated','Resubmitted','Record changed','Reminder sent'])),
 'settings':{'title':'Worklog approval','intro':'Set how recorded work is requested and approved.','when':'When is approval requested?','automatic':'Automatically after saving','manual':'The author requests manually','close':'How many days after month end can work be approved?','closeHint':'0 closes at month end. For example, 5 allows approval through the 5th of the next month. After closing, statistics include only approved records from supported entry points.','invalidDays':'Enter a whole number from 0 to 90.','approverHint':'The author’s team lead is the default. The author can choose another approver when requesting.','protection':'Editing after approval or closing','protectionHint':'Editing and deletion are blocked. The author can request review with a reason.','linked':'Connected issues use the Workforce project approval settings first. These defaults apply where no issue rule is set.','advanced':'Advanced settings','setup':'Set up worklog entry points'},
 'storage':{'NOTICE':'Review storage usage ahead of time.','WARNING':'Export records for retention.','CRITICAL':'Storage is nearly full.','steps':'Export records, verify the downloaded file, then remove only the confirmed archival range in the system. Audit records are never deleted automatically.','action':'Go to export and retention'}
}
for lang,data in [('kr',kr),('en',en)]:
 (root/f'locales/{lang}/worklogApprovalFlow.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 edit(f'locales/{lang}/approvalKind.json',lambda s:json.dumps({**json.loads(s),'label':{**json.loads(s)['label'],'WORKLOG_CERTIFICATION':'워크로그 승인' if lang=='kr' else 'Worklog approval'}},ensure_ascii=False,indent=2)+'\n')
edit('static/ui/src/features/worklog/WorklogApprovalPanel.jsx',lambda s:s.replace('formatDate }','formatDateTime }').replace('formatDate(event.occurredAt','formatDateTime(event.occurredAt'))
edit('static/ui/src/features/settings/DataSettings.jsx',lambda s:s.replace("percent >= 90 ? 'critical' : percent >= 80", "percent >= 95 ? 'critical' : percent >= 70").replace('          <SettingsRows','''          {data?.management?.action === 'EXPORT_AND_REVIEW' && <SectionMessage appearance={data.management.level === 'CRITICAL' ? 'error' : 'warning'} title={t(`worklogApprovalFlow.storage.${data.management.level}`)}>
            <p>{t('worklogApprovalFlow.storage.steps')}</p>
            <Button appearance="link" onClick={() => document.getElementById('record-retention-management')?.scrollIntoView({ behavior: 'smooth' })}>{t('worklogApprovalFlow.storage.action')}</Button>
          </SectionMessage>}
          <SettingsRows''',1).replace('<RecordRetentionSection format={format} />','<div id="record-retention-management"><RecordRetentionSection format={format} /></div>'))
# 새 기본 폼에서 다루는 마감·승인 방식은 고급 폼에서 중복 편집하지 않는다.
edit('static/ui/src/features/settings/TimesheetPolicySettings.jsx',lambda s:re.sub(r'        <NumberField\s+name="timesheetAutoCloseDays".*?        />\n','',s,flags=re.S).replace(s[s.index('      <SettingsSection level="sub" title={t(\'timesheet.settings.approvalModeSection\')}'):s.index('      <SettingsSection level="sub" title={t(\'worklogHistory.policy.section\')}')],''))

wf=Path('C:/CloudJira/moves-workforce')
edit('static/ui/src/pages/projectDetail/issue/approvalBulk.js',lambda s:s.replace("flowId: '' }","flowId: '', requestMode: 'KEEP', closeDays: '0' }").replace('    return item;','''    if (form.requestMode !== 'KEEP' && form.requestMode && row.capabilities?.worklogApproval) {
        item.wa = { v: 1, autoRequest: form.requestMode === 'AUTO', lockApproved: true, closeDays: Number(form.closeDays) };
    }
    return item;''').replace("|| (Object.hasOwn(item, 'fl')", "|| (item.wa && JSON.stringify(item.wa) !== JSON.stringify(row.setting?.wa))\n        || (Object.hasOwn(item, 'fl')"),wf)
def bulk(s):
 s=s.replace("const invalid = invalidApprovalRange(items) || (form.flow === 'SET' && !form.flowId);","const invalid = invalidApprovalRange(items) || (form.requestMode !== 'KEEP' && (!/^\\d+$/.test(String(form.closeDays)) || Number(form.closeDays) > 90));")
 a=s.index("            <label>{label('pa')}");b=s.index('        </fieldset>',a)
 s=s[:a]+'''            {targets.some((row) => row.capabilities?.worklogApproval) ? <>
                <label>{label('requestMode')} <select value={form.requestMode} onChange={update('requestMode')}>
                    {['KEEP', 'AUTO', 'MANUAL'].map((value) => <option key={value} value={value}>{label(`requestModes.${value}`)}</option>)}
                </select></label>
                {form.requestMode !== 'KEEP' && <label>{label('closeDays')} <input type="number" min={0} max={90} value={form.closeDays} onChange={update('closeDays')} /></label>}
                <p>{label('approvalHint')}</p><p>{label('lockHint')}</p>
            </> : <SectionMessage appearance="warning"><p>{label('approvalUnsupported')}</p></SectionMessage>}
'''+s[b:]
 return s
edit('static/ui/src/pages/projectDetail/issue/IssueApprovalBulkModal.jsx',bulk,wf)
def table(s):
 s=s.replace("'window', 'pa',\n        ...(flowsVisible ? ['flow'] : []),", "'window', 'requestMode', 'closeDays',")
 s=s.replace("        { key: 'pa', content: edit(row, label(`paMode.${row.setting?.pa ?? 'DEFAULT'}`)) },\n        ...(flowsVisible ? [{ key: 'flow', content: row.capabilities?.fl && row.capabilities?.flows ? edit(row, flowLabel(row)) : '—' }] : []),", "        { key: 'requestMode', content: row.capabilities?.worklogApproval ? edit(row, label(`requestModes.${row.setting?.wa?.autoRequest === false ? 'MANUAL' : 'AUTO'}`)) : '—' },\n        { key: 'closeDays', content: row.capabilities?.worklogApproval ? edit(row, String(row.setting?.wa?.closeDays ?? 0)) : '—' },")
 s=s.replace("        {pages.some((page) => page.approvalPresent) && !flowCapable && <p>{label('flowMissing')}</p>}\n",'')
 return s
edit('static/ui/src/pages/projectDetail/issue/IssueApprovalSettingTable.jsx',table,wf)
edit('static/ui/src/panel/PanelWorklogForm.jsx',lambda s:s.replace("    if (timeTrackingOff) {",'''    if (approval?.linked) {
        return <SectionMessage appearance="information"><p>{t('issuePanel.approval.singleEntry')}</p>
            {handoffPath && <Button onClick={() => router.navigate(handoffPath).catch(() => setError(t('issuePanel.approval.create.openFailed')))}>{t('issuePanel.approval.create.open')}</Button>}
            {error && <p role="alert">{error}</p>}
        </SectionMessage>;
    }
    if (timeTrackingOff) {'''),wf)
for lang in ['kr','en']:
 p=wf/f'locales/{lang}/issueApprovalSetting.json'
 if p.exists():
  data=json.loads(p.read_text(encoding='utf-8'))
  data.update({'requestMode':'승인 요청 방식' if lang=='kr' else 'Approval request','requestModes':{'KEEP':'변경 안 함','AUTO':'저장 후 자동 요청','MANUAL':'작성자가 직접 요청'} if lang=='kr' else {'KEEP':'Keep current','AUTO':'Automatically after saving','MANUAL':'Author requests manually'},'closeDays':'월말 이후 승인 가능 일수' if lang=='kr' else 'Days after month end','approvalHint':'기본 승인자는 작성자의 팀장입니다. 직접 요청할 때 변경할 수 있습니다. 0일은 월말 마감입니다.' if lang=='kr' else 'The author’s team lead is the default approver; authors may choose another. 0 closes at month end.','lockHint':'승인되거나 마감된 기록은 수정·삭제할 수 없습니다. 소명 요청 중에도 잠금은 유지됩니다.' if lang=='kr' else 'Approved or closed records cannot be edited or deleted, including during review.','approvalUnsupported':'승인 앱을 연결하고 최신 버전으로 업데이트하면 건별 승인 정책을 설정할 수 있습니다.' if lang=='kr' else 'Connect and update Approval to configure worklog approval.'})
  p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 p=wf/f'locales/{lang}/issuePanel.json'
 if p.exists():
  data=json.loads(p.read_text(encoding='utf-8'));data['approval']['singleEntry']='이 이슈의 워크로그 입력과 승인 이력은 Approval 패널에서 관리합니다. Workforce 앱 내부에서도 기록할 수 있습니다.' if lang=='kr' else 'Record work and review approval history in the Approval panel. You can also record work inside the Workforce app.';p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
