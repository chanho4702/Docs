from pathlib import Path
import json

root = Path(__file__).resolve().parents[2]
docs = root / 'docs/worklog-approval'
readme = docs / 'README.md'
text = readme.read_text(encoding='utf-8')
start = text.index('프론트 89 suites')
end = text.index('실사이트에서 확인해야', start)
text = text[:start] + '''최종 로컬 검증(2026-10-13): Approval 백엔드 186 suites/2,789 tests, UI 90 suites/803 tests; Workforce 백엔드 173 suites/2,386 tests, UI 171 suites/2,711 tests와 snapshot 1건이 통과했다. Approval `check:bundle`의 실제 webpack 번들 로드도 통과했다. 최종 실행과 브라우저 결과는 [검증 기록](VALIDATION.md)에 기록한다.

이 수치는 실제 Jira 사이트 설치·권한 스킴·큐를 실행한 결과가 아니다. 배포·사이트 실측은 수행하지 않았다.

''' + text[end:]
text = text.replace('diagrams/architecture.html', 'diagrams/architecture.v2.html').replace('diagrams/architecture.json', 'diagrams/architecture.v2.json')
text = text.replace('diagrams/workflow.html', 'diagrams/workflow.v2.html').replace('diagrams/workflow.json', 'diagrams/workflow.v2.json')
text = text.replace('관리자 감사 export와 저장된 최소 자료의 범위는 별도로 취급한다.', '승인 export에서도 현재 권한 필터로 제외될 수 있다. 변경 이력의 가린 기본 metadata export와 삭제 전 보관 파일을 별도로 취급한다.')
readme.write_text(text, encoding='utf-8')

guide_root = root / 'docs/guide'
for language in ('ko', 'en'):
    for name in ('00-index.md','01-overview.md','03-requester-guide.md','06-worklog-period-lock.md','07-transition-approval.md','08-field-change-approval.md','09-admin-guide.md','10-workforce-integration.md'):
        file = guide_root / language / name
        if not file.exists():
            continue
        old = file.read_text(encoding='utf-8')
        first, rest = old.split('\n', 1)
        note = '\n> 2026-10-13 변경: 현재 제공 기능은 워크로그 건별 승인 중심이다. 일반 이슈·상태·필드 승인과 사전 승인 절차는 현재 신규 사용자 흐름에서 제외하며 과거 설명을 보존한다. 최신 [사용자·관리자 가이드](../../worklog-approval/USER_AND_ADMIN_GUIDE.md)와 [설계·검증 자료](../../worklog-approval/README.md)를 먼저 읽는다.\n'
        file.write_text(first + '\n' + note + rest, encoding='utf-8')

diagram_dir = docs / 'diagrams'
receipts = {
    'architecture': ('defccaafec86b74d80242ac87c8a979cddaf102accb26acc475021a1f006d165',8622,'6112cf87bc69b6c60cc1238febcd661a9cfdcfdb86293790124d4ca50c856643',713433),
    'workflow': ('d1047be36aa5bc52813c6bb7c011b8832d8d85c335a7bcf7ae31798574438c29',6707,'5f010cbb5dd9653f5fe49b7bdf976ea5a307e7e00c2718ce1672f66f5536a030',714129),
}
for kind, (spec_hash,spec_bytes,artifact_hash,artifact_bytes) in receipts.items():
    receipt = {'schemaVersion':1,'ok':True,'command':'deliver','type':kind,
        'input':f'{kind}.v2.json','output':f'{kind}.v2.html',
        'specification':{'sha256':spec_hash,'bytes':spec_bytes},'artifact':{'sha256':artifact_hash,'bytes':artifact_bytes},
        'validation':{'checksPassed':9,'checkCount':9,'compositionProfile':'showcase','compositionStatus':'pass','errors':0,'warnings':0}}
    (diagram_dir / f'{kind}.v2.delivery.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
for file in diagram_dir.glob('*.json'):
    data = file.read_bytes()
    if data.startswith((b'\xff\xfe', b'\xfe\xff')):
        file.write_text(data.decode('utf-16'),encoding='utf-8')
