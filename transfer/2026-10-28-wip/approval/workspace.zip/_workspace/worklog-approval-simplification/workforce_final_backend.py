from pathlib import Path
root=Path('C:/CloudJira/moves-workforce')
p=root/'src/resolver/utils/worklog/WorklogService.js'
s=p.read_text(encoding='utf-8').replace('issueId: log.issueId,', 'issueId: String(log.issueId ?? issue.id),')
s=s.replace("return applyWorklogApproval(results.flat(), null, { includeHidden: true, startDate, endDate, issueIds: issues.map((issue)=>String(issue.id)) });", "const counted = await applyWorklogApproval(results.flat(), null, { includeHidden: true, startDate, endDate, issueIds: issues.map((issue)=>String(issue.id)) });\n    return accountIdArray ? counted.filter((row) => accountIdArray.includes(row.accountId)) : counted;")
p.write_text(s,encoding='utf-8')
p=root/'src/resolver/resourceAnalysis/ResourceAnalysisService.js'
s=p.read_text(encoding='utf-8')
if 'approval: l.approval ?? null' not in s:
 s=s.replace('            worklogId:    l.worklogId ?? null,', '            worklogId:    l.worklogId ?? null,\n            approval: l.approval ?? null,\n            claimedSeconds: l.claimedSeconds ?? l.timeSpentSeconds,\n            countableSeconds: l.countableSeconds ?? l.timeSpentSeconds,')
s=s.replace('hours:        Math.round(l.timeSpentSeconds / 3600 * 10) / 10,', 'hours:        Math.round((l.claimedSeconds ?? l.timeSpentSeconds) / 3600 * 10) / 10,')
s=s.replace('md:           Math.round(l.timeSpentSeconds / (hourRate * 3600) * 10) / 10,', 'md:           Math.round((l.claimedSeconds ?? l.timeSpentSeconds) / (hourRate * 3600) * 10) / 10,')
p.write_text(s,encoding='utf-8')
