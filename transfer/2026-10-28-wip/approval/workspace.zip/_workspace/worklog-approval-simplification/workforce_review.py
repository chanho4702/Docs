from pathlib import Path
root=Path('C:/CloudJira/moves-workforce')
p=root/'src/resolver/approvalLink/ApprovalCertReader.js'
s=p.read_text(encoding='utf-8').replace("const context = viewer ?? { cloudId: resolveInstallCloudId().cloudId };", "const context = { ...viewer, cloudId: viewer?.cloudId ?? resolveInstallCloudId().cloudId };")
s=s.replace('count < 36','count < 1200')
s=s.replace("            const issues = await postJiraJson({ as: 'user', url: route`/rest/api/3/issue/bulkfetch`,", "            if (!part.some((id) => permitted.has(id))) continue;\n            const issues = await postJiraJson({ as: 'user', url: route`/rest/api/3/issue/bulkfetch`,")
p.write_text(s,encoding='utf-8')
p=root/'src/resolver/approvalLink/IssueApprovalSettingService.js'
s=p.read_text(encoding='utf-8').replace('indexed.has(String(item.issueId)) && wantsFlow(item)', "indexed.has(String(item.issueId)) && (wantsFlow(item) || Object.hasOwn(item, 'wa'))")
s=s.replace("            if (!rx.includes(RX_FLOW_FIELD)) fail('ISSUE_SETTING_UNSUPPORTED');", "            if (Object.hasOwn(item, 'wa') && !rx.includes('rms.issue.wa')) fail('ISSUE_SETTING_UNSUPPORTED');\n            if (!wantsFlow(item)) continue;\n            if (!rx.includes(RX_FLOW_FIELD)) fail('ISSUE_SETTING_UNSUPPORTED');")
s=s.replace("targets.filter((item) => item.fl !== null)", "targets.filter((item) => wantsFlow(item) && item.fl !== null)")
p.write_text(s,encoding='utf-8')
p=root/'src/resolver/approvalLink/__test__/ApprovalCertReader.test.js'
s=p.read_text(encoding='utf-8')
s="jest.mock('../../backoffice/setting/SettingService', () => ({ getSettingDataService: async () => ({ approvalLinkMode: 'OFF' }) }));\njest.mock('../../../permission/PrincipalResolver', () => ({ resolvePrincipal: jest.fn() }));\n"+s
p.write_text(s,encoding='utf-8')
p=root/'AGENTS.md'
s=p.read_text(encoding='utf-8')
s+='''
## 워크로그 사후 승인 집계 예외 (2026-10-13)

- 사용자 요청에 따라 진행월은 정상 출처 기록, 마감 뒤에는 정상 출처의 승인 기록만 집계한다. 타인 사용자 프로퍼티의 asUser 제한으로 집계가 비는 문제를 해결하기 위해 `ApprovalCertReader.applyWorklogApproval`에 한해 승인 서명 문서를 asApp으로 읽는다.
- 공개 행은 조회자 asUser `permissions/check`와 `worklog/list`로 다시 제한하고 id·issueId·author 및 현재 지문을 대조한다. 승인 문서 원문과 타인 결정자·결정시각·requestId는 반환하지 않는다. 원가 캐시와 일반/숨김 집계 캐시는 각각 분리하고 조회자 키를 포함한다.
- 숨김 승인분은 숫자 집계에만 보충한다. `resolvePrincipal`의 본인 및 `leadingScopeAccountIds` 범위로 문서를 먼저 제한하고, 조회자의 `permissions/check`+`issue/bulkfetch`를 통과한 이슈 집합만 사용한다. 기존 `hiddenCertifiedRowsOf`의 author·issue·서명된 통제 visibility 재대조를 모두 유지한다. 리소스 개별 상세/캘린더에 남의 숨김 행을 내보내지 않는다.
- 연동 작성은 승인 이슈 패널과 Workforce 앱 내부 두 경로를 허용한다. Workforce의 Jira 이슈 패널 중복 작성 UI는 제외한다. 생성은 유효한 양방향 서명과 `wa` 지원 신호가 있어야 하며 asUser만 쓴다. 수정·삭제는 Approval의 현재 DB 판정 경로로 넘긴다.
'''
p.write_text(s,encoding='utf-8')
