from pathlib import Path
root=Path('C:/CloudJira/moves-workforce')
p=root/'src/resolver/approvalLink/ApprovalCertReader.js'
s=p.read_text(encoding='utf-8')
s="import { resolvePrincipal } from '../../permission/PrincipalResolver';\n"+s
s=s.replace("    if (settings.approvalLinkMode !== 'ON' || !list.length) return list;", "    if (settings.approvalLinkMode !== 'ON') return list;\n    if (!list.length && !options.includeHidden) return list;")
s=s.replace("    const context = viewer ?? { cloudId: resolveInstallCloudId().cloudId };", """    const context = viewer ?? { cloudId: resolveInstallCloudId().cloudId };
    if (!context.accountId) {
        const self = await requestJiraJson({ as: 'user', url: route`/rest/api/3/myself`, logPrefix: '[APPROVAL AGGREGATE SELF]' });
        context.accountId = self?.accountId;
    }
    if (!context.accountId) throw new Error('APPROVAL_AGGREGATE_PRINCIPAL_REQUIRED');""")
s=s.replace("    return allowed.map((row) => {\n        const approval", """    let counted = allowed;
    if (options.includeHidden && options.issueIds?.length && options.startDate && options.endDate) {
        const principal = await resolvePrincipal(context);
        const subjects = [...new Set([principal.accountId, ...(principal.leadingScopeAccountIds ?? [])])].filter(Boolean);
        const seeds = [];
        const first = new Date(`${options.startDate.substring(0,7)}-01T00:00:00Z`);
        const last = new Date(`${options.endDate.substring(0,7)}-01T00:00:00Z`);
        for (let date = first, count = 0; date <= last && count < 36; date = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth()+1, 1)), count += 1) {
            for (const accountId of subjects) seeds.push({ accountId, date: date.toISOString().substring(0,10) });
        }
        const hiddenDocs = await loadApprovalCertDocs({ ...options, as: 'app', cacheScope: `hidden-aggregate|${context.accountId}`,
            viewer: context, pairs: certPairsOfRows(seeds) });
        const projectIssues = new Map();
        const wanted = [...new Set(options.issueIds.map(String))].filter((id) => /^\\d+$/.test(id));
        for (let offset = 0; offset < wanted.length; offset += 100) {
            const part = wanted.slice(offset, offset+100);
            const permission = await postJiraJson({ as: 'user', url: route`/rest/api/3/permissions/check`,
                body: { projectPermissions: [{ permissions: ['BROWSE_PROJECTS'], issues: part.map(Number) }] }, logPrefix: '[APPROVAL HIDDEN PERMISSION]' });
            const permitted = new Set((permission?.projectPermissions?.find((entry) => entry.permission === 'BROWSE_PROJECTS')?.issues ?? []).map(String));
            const issues = await postJiraJson({ as: 'user', url: route`/rest/api/3/issue/bulkfetch`,
                body: { issueIdsOrKeys: part.filter((id) => permitted.has(id)), fields: ['project'] }, logPrefix: '[APPROVAL HIDDEN ISSUES]' });
            for (const issue of issues?.issues ?? []) {
                if (part.includes(String(issue.id)) && permitted.has(String(issue.id)) && issue.fields?.project?.id) {
                    projectIssues.set(String(issue.id), { projectId: String(issue.fields.project.id), key: issue.key });
                }
            }
        }
        const hidden = await hiddenCertifiedRowsOf({ rows: allowed, docs: hiddenDocs.docs, projectIssues, viewer: context });
        const scopedHidden = hidden.filter((row) => subjects.includes(row.accountId) && row.date >= options.startDate && row.date <= options.endDate);
        for (const [key, doc] of hiddenDocs.docs) loaded.docs.set(key, doc);
        counted = [...allowed, ...scopedHidden];
    }
    return counted.map((row) => {
        const approval""")
p.write_text(s,encoding='utf-8')

p=root/'src/resolver/resourceAnalysis/ResourceWorklogFetcher.js'
s=p.read_text(encoding='utf-8').replace("accountId, as = 'user' })", "accountId, as = 'user', includeHidden = false, viewer = null })")
s=s.replace('return applyWorklogApproval(results.flat());', "return applyWorklogApproval(results.flat(), viewer, { includeHidden, startDate, endDate, issueIds: issues.map((issue)=>String(issue.id)) });")
p.write_text(s,encoding='utf-8')
p=root/'src/resolver/resourceAnalysis/ResourceAnalysisController.js'
s=p.read_text(encoding='utf-8').replace("async ({ payload }) => {\n        return await getResourceAnalysisListService(payload);", "async ({ payload, context }) => {\n        return await getResourceAnalysisListService(payload, { accountId: context?.accountId, cloudId: context?.cloudId });")
p.write_text(s,encoding='utf-8')
p=root/'src/resolver/resourceAnalysis/ResourceAnalysisService.js'
s=p.read_text(encoding='utf-8').replace("async ({ projectId, startDate, endDate }) =>", "async ({ projectId, startDate, endDate }, viewer = null) =>")
s=s.replace("const cached = await kvs.get(cacheKey, { metadataFields: [MetadataField.EXPIRE_TIME] });", "const cached = null;")
s=s.replace('getResourceProjectWorklogs({ projectId, startDate, endDate: effectiveEndDate })', 'getResourceProjectWorklogs({ projectId, startDate, endDate: effectiveEndDate, includeHidden: true, viewer })')
s=s.replace('getResourceProjectWorklogs({ projectId, startDate, endDate, accountId })','getResourceProjectWorklogs({ projectId, startDate, endDate, accountId, viewer })')
p.write_text(s,encoding='utf-8')
p=root/'src/resolver/utils/worklog/WorklogService.js'
s=p.read_text(encoding='utf-8').replace('return applyWorklogApproval(results.flat());', "return applyWorklogApproval(results.flat(), null, { includeHidden: true, startDate, endDate, issueIds: issues.map((issue)=>String(issue.id)) });")
p.write_text(s,encoding='utf-8')

p=root/'src/resolver/projectCalendar/ProjectCalendarService.js'
s=p.read_text(encoding='utf-8')
s="import { applyWorklogApproval } from '../approvalLink/ApprovalCertReader';\n"+s
s=s.replace("    return {\n        data: worklogChunks.filter(Boolean),", """    const chunks = worklogChunks.filter(Boolean);
    const input = chunks.flatMap((issue) => (issue.fields?.worklog?.worklogs ?? []).map((row) => ({ ...row, issueId: String(issue.id) })));
    const approved = await applyWorklogApproval(input);
    const byId = new Map(approved.map((row) => [String(row.id ?? row.worklogId), row]));
    return {
        data: chunks.map((issue) => ({ ...issue, fields: { ...issue.fields, worklog: { ...issue.fields?.worklog,
            worklogs: (issue.fields?.worklog?.worklogs ?? []).map((row) => byId.get(String(row.id))).filter(Boolean) } } })),""")
p.write_text(s,encoding='utf-8')

p=root/'src/resolver/projectDashboard/RelationGraphService.js'
s=p.read_text(encoding='utf-8')
s="import { getResourceProjectWorklogs } from '../resourceAnalysis/ResourceWorklogFetcher';\n"+s
s=s.replace("    const graph = buildRelationGraph({ issues: fetched.issues, projectName, hourRate });", """    let graphIssues = fetched.issues;
    if (settings.approvalLinkMode === 'ON') {
        const rows = await getResourceProjectWorklogs({ projectId, includeHidden: true,
            startDate: '2000-01-01', endDate: new Date().toISOString().substring(0,10), viewer: { accountId: principal?.accountId } });
        const sums = new Map();
        for (const row of rows) sums.set(row.issueKey, (sums.get(row.issueKey) ?? 0) + row.timeSpentSeconds);
        graphIssues = fetched.issues.map((issue) => ({ ...issue, fields: { ...issue.fields,
            timetracking: { ...issue.fields?.timetracking, timeSpentSeconds: sums.get(issue.key) ?? 0 } } }));
    }
    const graph = buildRelationGraph({ issues: graphIssues, projectName, hourRate });""")
p.write_text(s,encoding='utf-8')
