/*
 * timesheet-approval 프론트 회차의 번역 추가분. 재실행해도 같은 결과(키 덮어쓰기 + 기존 순서 유지).
 * node _workspace/timesheet-approval/tmp/locales_timesheet.js
 */
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..', '..', '..', 'locales');

const kr = {
  error: {
    PERMISSION_TEAM_LEAD_REQUIRED: '팀장만 볼 수 있습니다.',
    TIMESHEET_PERIOD_INVALID: '제출할 수 없는 기간입니다.',
    TIMESHEET_EMPTY: '작업 로그가 없는 기간은 제출할 수 없습니다.',
    TIMESHEET_LIMIT_BLOCKED: '제한선을 넘은 기록이 있어 제출할 수 없습니다.',
    TIMESHEET_CONTENT_CHANGED: '화면을 연 뒤 작업 로그가 바뀌었습니다. 내용을 다시 확인하세요.',
    TIMESHEET_NO_TEAM: '소속 팀이 없습니다. 관리자에게 팀 등록을 요청하세요.',
    TIMESHEET_NO_APPROVER: '팀에 결재할 팀장이 없습니다.',
    TIMESHEET_TOO_LARGE: '이 기간의 작업 로그가 너무 많아 처리할 수 없습니다.',
    TIMESHEET_TEAM_MEMBER_CONFLICT: '이미 다른 팀에 속한 구성원이 있습니다.',
  },
  notification: {
    template: {
      timesheetChanged: '승인된 타임시트({period})가 바뀌었습니다. 다시 제출해야 합니다.',
      timesheetChangedWhilePending: '결재 중인 타임시트({period})가 바뀌어 요청이 닫혔습니다. 다시 제출하세요.',
    },
  },
  detail: { event: { changed_after_approval: '승인 후 변경 감지' } },
  state: { expiry: { CONTENT_CHANGED: '결재 중 내용 변경' } },
  policy: { settings: { tab: { timesheet: '타임시트' } } },
  inbox: { type: { timesheet: '타임시트' } },
  cert: {
    target: { timesheet: '타임시트' },
    timesheet: {
      subject: '대상자',
      period: '기간',
      total: '합계',
      violations: '제한선 위반',
      changed: '승인 후 변경',
      changedAt: '{date}에 승인된 작업 로그가 바뀐 것을 감지했습니다.',
      hash: '작업 로그 지문',
      hashHint: '제출 시점 작업 로그 묶음을 같은 방식으로 계산한 값이 아래 값과 같으면, 증명서가 가리키는 내용이 바뀌지 않았다는 뜻입니다.',
    },
  },
  timesheet: {
    nav: { mine: '내 타임시트', team: '팀 타임시트' },
    period: {
      month: '{year}년 {month}월',
      week: '{year}년 {week}주차',
      range: '{start} ~ {end} ({timeZone})',
      prev: '이전 기간',
      next: '다음 기간',
      label: '기간',
      current: '현재 기간으로',
    },
    status: {
      NOT_SUBMITTED: '미제출',
      SUBMITTED: '제출됨',
      APPROVED: '승인됨',
      REJECTED: '반려됨',
      CHANGED_AFTER_APPROVAL: '승인 후 변경됨',
      needsResubmit: '재제출 필요',
    },
    summary: {
      total: '합계 {hours}',
      count: '작업 로그 {count}건',
      byDay: '일별',
      byIssue: '이슈별',
      hiddenIssue: '볼 수 없는 이슈',
      empty: '이 기간에 기록한 작업 로그가 없습니다.',
      date: '날짜',
      hours: '시간',
      issue: '이슈',
      live: '현재 작업 로그',
    },
    submit: {
      button: '제출',
      resubmit: '다시 제출',
      cancel: '제출 회수',
      message: '결재자에게 남길 말(선택)',
      changedSince: '제출 후 작업 로그가 바뀌었습니다. 다시 제출해야 합니다.',
      notStarted: '아직 시작하지 않은 기간은 제출할 수 없습니다.',
      routing: '결재: {team} 팀장',
      viewSubmitted: '제출본 보기',
      submittedAt: '제출 {date}',
      decidedAt: '처리 {date}',
      done: '제출했습니다.',
      doneExtraStep: '제출했습니다. 제한선을 넘어 예외 승인 단계가 추가되었습니다.',
    },
    notice: {
      acceptance: '작업 로그는 미리 막히지 않습니다. 승인 후 바뀐 내용은 감지해 다시 승인받습니다.',
    },
    violation: {
      title: {
        WARN: '제한선을 넘은 기록이 있습니다',
        EXTRA_STEP: '제한선 초과 — 예외 승인 단계가 추가됩니다',
        BLOCK: '제한선 초과 — 제출할 수 없습니다',
      },
      DAILY_MAX: '{date}: 하루 {hours} (한도 {limit})',
      WEEKLY_MAX: '{week}: 주 {hours} (한도 {limit})',
      FUTURE_DATE: '{date}: 미래 날짜 기록',
      BACKDATED: '{date}: {days}일 뒤에 기록(한도 {limit}일)',
      more: '외 {count}건',
    },
    team: {
      select: '팀',
      all: '전체 팀',
      column: {
        member: '팀원',
        status: '상태',
        total: '합계',
        count: '건수',
        violations: '위반',
        submittedAt: '제출일',
        decidedAt: '처리일',
        step: '결재 단계',
      },
      summary: '전체 {total} · 미제출 {notSubmitted} · 제출 {submitted} · 승인 {approved} · 반려 {rejected} · 변경 {changed}',
      approveSelected: '선택 {count}건 승인',
      progress: '{done}/{total} 처리 중',
      result: '승인 {approved}건, 실패 {failed}건',
      reject: '반려',
      rejectReason: '반려 사유',
      export: '엑셀로 내보내기',
      empty: '이끄는 팀에 구성원이 없습니다.',
      bulkHint: '내 차례인 제출 건을 골라 한 번에 승인할 수 있습니다.',
      nothingToDecide: '{period}에 지금 내가 결정할 제출 건이 없습니다.',
    },
    inbox: {
      title: '{name} · {period} 타임시트',
      someone: '사용자',
    },
    detail: {
      drift: '{date}에 승인된 내용이 바뀐 것을 감지했습니다({kind}).',
      driftKind: { CREATED: '추가', UPDATED: '수정', DELETED: '삭제' },
      snapshot: '제출 시점 작업 로그',
      resubmitHint: '다시 제출은 업무함의 내 타임시트 탭에서 합니다.',
    },
    settings: {
      title: '타임시트 승인',
      unit: { label: '승인 단위', MONTH: '월', WEEK: '주(ISO)' },
      unitChangeWarning: '단위를 바꾸면 새 제출부터 적용됩니다. 이미 제출된 기간은 그대로 남습니다.',
      timeZone: '기간 기준 시간대',
      allowEmpty: '작업 로그가 없는 기간도 제출 허용',
      limits: '제한선',
      dailyMax: '하루 최대(분, 0=끔)',
      weeklyMax: '주 최대(분, 0=끔)',
      futureDate: '미래 날짜 기록 검사',
      backdate: '소급 입력 허용 일수(0=끔)',
      action: {
        label: '위반 처리',
        WARN: '경고만',
        EXTRA_STEP: '예외 승인 단계 추가',
        BLOCK: '제출 거부',
      },
      exceptionGroup: '예외 승인 그룹',
      exceptionGroupRequired: '예외 승인 단계를 추가하려면 예외 승인 그룹을 고르세요.',
      none: '없음',
      teams: '팀',
      team: {
        name: '팀 이름',
        leads: '팀장',
        members: '구성원',
        secondStep: '2단계 결재 그룹',
        enabled: '사용',
        import: 'Jira 그룹에서 가져오기',
        importHint: '가져온 뒤 저장해야 반영됩니다. 그룹이 바뀌어도 자동으로 따라가지 않습니다.',
        importPlaceholder: 'Jira 그룹 이름',
        importButton: '가져오기',
        imported: '{count}명을 구성원에 더했습니다.',
        importTruncated: '그룹이 커서 앞의 {max}명까지만 가져왔습니다.',
        source: '마지막으로 가져온 그룹: {group}',
        openRequests: '팀을 삭제했습니다. 진행 중인 요청 {count}건은 기존 결재선으로 계속됩니다.',
        deleted: '팀을 삭제했습니다.',
        deleteHint: '삭제하면 이 팀 구성원은 타임시트를 제출할 수 없습니다. 진행 중인 요청은 기존 결재선으로 계속됩니다.',
        add: '팀 추가',
        edit: '팀 수정',
        addPeople: '사용자 추가',
        leadsCount: '팀장 {count}/{max}명',
        membersCount: '구성원 {count}/{max}명',
        nobody: '아직 없습니다.',
        hint: '팀장은 자기 팀 구성원의 타임시트만 봅니다. 구성원은 한 팀에만 속할 수 있습니다.',
        search: '팀 이름으로 검색',
        empty: '등록된 팀이 없습니다.',
      },
    },
  },
};

const en = {
  error: {
    PERMISSION_TEAM_LEAD_REQUIRED: 'Only team leads can view this.',
    TIMESHEET_PERIOD_INVALID: "This period can't be submitted.",
    TIMESHEET_EMPTY: "You can't submit a period with no work logs.",
    TIMESHEET_LIMIT_BLOCKED: "You can't submit because some entries exceed the limits.",
    TIMESHEET_CONTENT_CHANGED: 'Your work logs changed. Review them and try again.',
    TIMESHEET_NO_TEAM: "You're not in a team. Ask an admin to add you.",
    TIMESHEET_NO_APPROVER: 'Your team has no lead to approve.',
    TIMESHEET_TOO_LARGE: 'This period has too many work logs to process.',
    TIMESHEET_TEAM_MEMBER_CONFLICT: 'Some members already belong to another team.',
  },
  notification: {
    template: {
      timesheetChanged: 'An approved timesheet ({period}) changed and needs resubmission.',
      timesheetChangedWhilePending: 'A timesheet under review ({period}) changed, so the request was closed. Please resubmit.',
    },
  },
  detail: { event: { changed_after_approval: 'Change detected after approval' } },
  state: { expiry: { CONTENT_CHANGED: 'Changed while under review' } },
  policy: { settings: { tab: { timesheet: 'Timesheets' } } },
  inbox: { type: { timesheet: 'Timesheet' } },
  cert: {
    target: { timesheet: 'Timesheet' },
    timesheet: {
      subject: 'Person',
      period: 'Period',
      total: 'Total',
      violations: 'Limit violations',
      changed: 'Changed after approval',
      changedAt: 'A change to the approved work logs was detected on {date}.',
      hash: 'Work log fingerprint',
      hashHint: 'If computing the submitted work logs the same way gives the value below, the content this certificate refers to has not changed.',
    },
  },
  timesheet: {
    nav: { mine: 'My timesheet', team: 'Team timesheets' },
    period: {
      month: '{month}/{year}',
      week: 'Week {week}, {year}',
      range: '{start} – {end} ({timeZone})',
      prev: 'Previous',
      next: 'Next',
      label: 'Period',
      current: 'Go to current period',
    },
    status: {
      NOT_SUBMITTED: 'Not submitted',
      SUBMITTED: 'Submitted',
      APPROVED: 'Approved',
      REJECTED: 'Rejected',
      CHANGED_AFTER_APPROVAL: 'Changed after approval',
      needsResubmit: 'Resubmission needed',
    },
    summary: {
      total: 'Total {hours}',
      count: '{count} work logs',
      byDay: 'By day',
      byIssue: 'By work item',
      hiddenIssue: 'Restricted work item',
      empty: 'No work logged in this period.',
      date: 'Date',
      hours: 'Time',
      issue: 'Work item',
      live: 'Current work logs',
    },
    submit: {
      button: 'Submit',
      resubmit: 'Resubmit',
      cancel: 'Withdraw',
      message: 'Note to approver (optional)',
      changedSince: 'Your work logs changed after submission. Please resubmit.',
      notStarted: "You can't submit a period that hasn't started.",
      routing: 'Approval: {team} lead',
      viewSubmitted: 'View submission',
      submittedAt: 'Submitted {date}',
      decidedAt: 'Closed {date}',
      done: 'Submitted.',
      doneExtraStep: 'Submitted. An exception approval step was added because limits were exceeded.',
    },
    notice: {
      acceptance: "Work logs aren't blocked in advance. Changes after approval are detected and need re-approval.",
    },
    violation: {
      title: {
        WARN: 'Some entries exceed the limits',
        EXTRA_STEP: 'Limits exceeded — an exception approval step will be added',
        BLOCK: "Limits exceeded — you can't submit",
      },
      DAILY_MAX: '{date}: {hours} in a day (limit {limit})',
      WEEKLY_MAX: '{week}: {hours} in a week (limit {limit})',
      FUTURE_DATE: '{date}: logged for a future date',
      BACKDATED: '{date}: logged {days} days later (limit {limit})',
      more: 'and {count} more',
    },
    team: {
      select: 'Team',
      all: 'All teams',
      column: {
        member: 'Member',
        status: 'Status',
        total: 'Total',
        count: 'Logs',
        violations: 'Violations',
        submittedAt: 'Submitted',
        decidedAt: 'Closed',
        step: 'Step',
      },
      summary: '{total} total · {notSubmitted} not submitted · {submitted} submitted · {approved} approved · {rejected} rejected · {changed} changed',
      approveSelected: 'Approve {count} selected',
      progress: 'Processing {done}/{total}',
      result: '{approved} approved, {failed} failed',
      reject: 'Reject',
      rejectReason: 'Reason for rejection',
      export: 'Export to Excel',
      empty: 'Your team has no members.',
      bulkHint: 'Select submissions waiting for you to approve them at once.',
      nothingToDecide: 'Nothing is waiting for your decision in {period}.',
    },
    inbox: {
      title: '{name} · {period} timesheet',
      someone: 'Someone',
    },
    detail: {
      drift: 'A change to the approved content was detected on {date} ({kind}).',
      driftKind: { CREATED: 'added', UPDATED: 'edited', DELETED: 'deleted' },
      snapshot: 'Work logs at submission',
      resubmitHint: 'Resubmit from the My timesheet tab in the inbox.',
    },
    settings: {
      title: 'Timesheet approval',
      unit: { label: 'Approval period', MONTH: 'Month', WEEK: 'Week (ISO)' },
      unitChangeWarning: 'Changing the period applies to new submissions only. Existing submissions stay as they are.',
      timeZone: 'Time zone for periods',
      allowEmpty: 'Allow submitting empty periods',
      limits: 'Limits',
      dailyMax: 'Daily maximum (minutes, 0 = off)',
      weeklyMax: 'Weekly maximum (minutes, 0 = off)',
      futureDate: 'Check entries logged for future dates',
      backdate: 'Days allowed for late logging (0 = off)',
      action: {
        label: 'When limits are exceeded',
        WARN: 'Warn only',
        EXTRA_STEP: 'Add exception approval step',
        BLOCK: 'Block submission',
      },
      exceptionGroup: 'Exception approval group',
      exceptionGroupRequired: 'Choose an exception approval group to add an exception step.',
      none: 'None',
      teams: 'Teams',
      team: {
        name: 'Team name',
        leads: 'Leads',
        members: 'Members',
        secondStep: 'Second approval group',
        enabled: 'Enabled',
        import: 'Import from Jira group',
        importHint: "Save to apply. The team won't follow later group changes automatically.",
        importPlaceholder: 'Jira group name',
        importButton: 'Import',
        imported: 'Added {count} people to members.',
        importTruncated: 'The group is large, so only the first {max} people were imported.',
        source: 'Last imported group: {group}',
        openRequests: 'Team deleted. {count} open requests keep their current approvers.',
        deleted: 'Team deleted.',
        deleteHint: "Members of this team won't be able to submit timesheets. Open requests keep their current approvers.",
        add: 'Add team',
        edit: 'Edit team',
        addPeople: 'Add people',
        leadsCount: 'Leads {count}/{max}',
        membersCount: 'Members {count}/{max}',
        nobody: 'No one yet.',
        hint: 'Team leads see only their own team members. A member can belong to one team only.',
        search: 'Search by team name',
        empty: 'No teams yet.',
      },
    },
  },
};

const isObject = (value) => value && typeof value === 'object' && !Array.isArray(value);
const deepMerge = (target, source) => {
  Object.entries(source).forEach(([key, value]) => {
    if (isObject(value)) {
      if (!isObject(target[key])) target[key] = {};
      deepMerge(target[key], value);
    } else {
      target[key] = value;
    }
  });
  return target;
};

[['kr', kr], ['en', en]].forEach(([dir, additions]) => {
  Object.entries(additions).forEach(([namespace, values]) => {
    const file = path.join(root, dir, `${namespace}.json`);
    const exists = fs.existsSync(file);
    const current = exists ? JSON.parse(fs.readFileSync(file, 'utf8')) : {};
    const merged = deepMerge(current, values);
    const text = `${JSON.stringify(merged, null, 2)}\n`.replace(/\n/g, '\r\n');
    fs.writeFileSync(file, text, 'utf8');
  });
});
console.log('ok');
