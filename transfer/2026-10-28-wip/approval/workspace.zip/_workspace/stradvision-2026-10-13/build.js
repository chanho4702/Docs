/* 스트라드비전 요구사항 대응 보고 PPT — Moves_Workforce 제품소개 v2.1 의 디자인 토큰·헬퍼를 그대로 사용 */
const fs = require('fs');
const path = require('path');
const pptxgen = require('pptxgenjs');
const sharp = require('sharp');
const React = require('react');
const ReactDOMServer = require('react-dom/server');
const FA = require('react-icons/fa');

const DOC = 'C:/CloudJira/moves-approval-jira/_workspace/stradvision-2026-10-13';
const IMG = (f) => path.join(DOC, 'images', f);
const ASSET = (f) => path.join('C:/CloudJira/moves-workforce/_workspace/product-intro-ppt/assets', f);
const OUT = path.join(DOC, '스트라드비전_요구사항_대응방안_Workforce+Approval.pptx');

// ───────── 디자인 토큰 (참고 PPT 와 동일) ─────────
const T = { 900: '103F3A', 700: '14756E', 600: '1A9A90', 500: '21ADAD', 300: '6FD3C6', 100: 'C9ECE6', 50: 'E9F7F4' };
const INK = '10201E', GRAY = '55625F', MUTED = '8A9896', LINE = 'D9E4E2', BG = 'F4F8F7', WHITE = 'FFFFFF';
const AMBER = 'E39B2C', RED = 'D64545', GREEN = '2E9E6B', BLUE = '2F6FDE', SLATE = '6B7A78';
const AMBER_BG = 'FDF3E3', RED_BG = 'FBE9E9', GREEN_BG = 'E6F4EC';
const FONT = 'Noto Sans KR', MONO = 'Consolas';
const W = 13.333, H = 7.5, M = 0.6, CW = W - 2 * M;
const TOP = 2.02, BOTTOM = 6.8;
const sh = () => ({ type: 'outer', color: '000000', blur: 8, offset: 2, angle: 90, opacity: 0.12 });

const iconCache = new Map();
async function icon(name, color = '#' + WHITE, size = 256) {
  const k = name + color;
  if (iconCache.has(k)) return iconCache.get(k);
  const Comp = FA[name];
  if (!Comp) throw new Error('icon not found: ' + name);
  const svg = ReactDOMServer.renderToStaticMarkup(React.createElement(Comp, { color, size: String(size) }));
  const png = await sharp(Buffer.from(svg)).png().toBuffer();
  const data = 'image/png;base64,' + png.toString('base64');
  iconCache.set(k, data);
  return data;
}
async function iconCircle(s, name, x, y, d, { bg = T[500], fg = WHITE } = {}) {
  s.addShape(pres.shapes.OVAL, { x, y, w: d, h: d, fill: { color: bg }, line: { color: bg, width: 0 } });
  const pad = d * 0.27;
  s.addImage({ data: await icon(name, '#' + fg), x: x + pad, y: y + pad, w: d - 2 * pad, h: d - 2 * pad });
}

let pres;
const slides = [];
function rect(s, x, y, w, h, fill, o = {}) {
  s.addShape(o.round ? pres.shapes.ROUNDED_RECTANGLE : pres.shapes.RECTANGLE, {
    x, y, w, h, fill: fill ? { color: fill } : { type: 'none' },
    line: o.line ? { color: o.line, width: o.lineW ?? 0.75, dashType: o.dash ?? 'solid' } : { color: fill || WHITE, width: 0 },
    rectRadius: o.round ? (o.radius ?? 0.08) : undefined, shadow: o.shadow ? sh() : undefined,
  });
}
function txt(s, text, x, y, w, h, o = {}) {
  s.addText(text, {
    x, y, w, h, fontFace: o.mono ? MONO : FONT, fontSize: o.size ?? 13, color: o.color ?? INK, bold: !!o.bold, italic: !!o.italic,
    align: o.align ?? 'left', valign: o.valign ?? 'top', margin: o.margin ?? 0, charSpacing: o.spacing, lineSpacingMultiple: o.lh ?? 1.15,
    paraSpaceAfter: o.para, fit: o.fit, isTextBox: true,
  });
}
function bullets(s, items, x, y, w, h, o = {}) {
  const arr = [];
  items.forEach((it, i) => {
    const last = i === items.length - 1;
    const base = { bullet: { indent: 13 }, paraSpaceAfter: o.gap ?? 7 };
    if (typeof it === 'string') arr.push({ text: it, options: { ...base, breakLine: !last } });
    else {
      arr.push({ text: it.t, options: { ...base, bold: true, color: o.headColor ?? T[900] } });
      arr.push({ text: it.d ? '  ' + it.d : '', options: { breakLine: !last, color: o.color ?? INK } });
    }
  });
  s.addText(arr, { x, y, w, h, fontFace: FONT, fontSize: o.size ?? 12.5, color: o.color ?? INK, valign: 'top', margin: 0, lineSpacingMultiple: 1.18, isTextBox: true });
}
function chip(s, text, x, y, w, h, { bg = T[50], fg = T[700], size = 9.5, bold = true } = {}) {
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, fill: { color: bg }, line: { color: bg, width: 0 }, rectRadius: h / 2 });
  txt(s, text, x, y, w, h, { size, color: fg, bold, align: 'center', valign: 'middle' });
}
function content(chapter, secLabel, title, sub, o = {}) {
  const s = pres.addSlide();
  s.background = { color: o.bg ?? WHITE };
  txt(s, (chapter ? chapter + '   ' : '') + secLabel, M, 0.55, 9, 0.3, { size: 10.5, color: T[600], bold: true, valign: 'middle', spacing: 1.5 });
  txt(s, title, M, 0.98, CW, 0.62, { size: 26, bold: true, color: INK, valign: 'middle' });
  if (sub) txt(s, sub, M, 1.58, CW, 0.32, { size: 13, color: GRAY, valign: 'middle' });
  slides.push({ s, kind: 'content' });
  return s;
}
function section(num, title, sub, items) {
  const s = pres.addSlide();
  s.background = { color: T[900] };
  rect(s, 0, 0, 0.28, H, T[500]);
  txt(s, num, M + 0.2, 1.05, 6, 2.2, { size: 120, bold: true, color: T[700] });
  txt(s, title, M + 0.25, 3.35, 7.2, 0.9, { size: 38, bold: true, color: WHITE, valign: 'middle' });
  txt(s, sub, M + 0.25, 4.3, 7.2, 1.1, { size: 15, color: T[100], lh: 1.3 });
  const lh = 0.36;
  rect(s, 8.55, 1.3, 0.04, Math.min(5.2, 0.55 + items.length * lh), T[600]);
  txt(s, '이 파트에서 다루는 내용', 8.85, 1.25, 4, 0.35, { size: 10.5, color: T[300], bold: true, spacing: 1 });
  const arr = items.map((t, i) => ({ text: t, options: { breakLine: i < items.length - 1, paraSpaceAfter: 6 } }));
  s.addText(arr, { x: 8.85, y: 1.7, w: 4.0, h: Math.min(5.0, items.length * lh + 0.2), fontFace: FONT, fontSize: 12.5, color: WHITE, valign: 'top', margin: 0, lineSpacingMultiple: 1.18, isTextBox: true });
  s.addImage({ path: ASSET('dmove_wordmark_white.png'), x: M + 0.25, y: 6.75, w: 1.1, h: 0.25 });
  slides.push({ s, kind: 'section' });
  return s;
}
async function imgFit(s, file, x, y, w, h, o = {}) {
  const m = await sharp(file).metadata();
  const r = m.width / m.height;
  let iw = w, ih = w / r;
  if (ih > h) { ih = h; iw = h * r; }
  const ix = o.alignLeft ? x : x + (w - iw) / 2, iy = o.alignTop ? y : y + (h - ih) / 2;
  if (o.frame) rect(s, ix - 0.08, iy - 0.08, iw + 0.16, ih + 0.16, WHITE, { line: LINE, shadow: true });
  s.addImage({ path: file, x: ix, y: iy, w: iw, h: ih });
  if (o.caption) txt(s, o.caption, ix, iy + ih + 0.12, iw, 0.24, { size: 9, color: MUTED, italic: true });
  return { x: ix, y: iy, w: iw, h: ih };
}
function points(s, pts, x, y, w, rowH, o = {}) {
  pts.forEach((pt, i) => {
    const [t, d] = pt;
    const yy = y + i * rowH;
    rect(s, x, yy + 0.13, 0.22, 0.05, o.dark ? T[300] : T[500]);
    txt(s, t, x + 0.35, yy, w - 0.35, 0.3, { size: o.titleSize ?? 12, bold: true, color: o.dark ? WHITE : INK });
    txt(s, d, x + 0.35, yy + 0.32, w - 0.35, rowH - 0.35, { size: o.size ?? 10, color: o.dark ? T[100] : GRAY, lh: 1.3 });
  });
}
async function card(s, x, y, w, h, { num, iconName, title, body, bg = WHITE, accent = T[500], titleSize = 13, bodySize = 11, iconD = 0.5, bodyColor = GRAY, line = LINE } = {}) {
  rect(s, x, y, w, h, bg, { line, shadow: bg === WHITE });
  let ty = y + 0.2;
  if (iconName) { await iconCircle(s, iconName, x + 0.22, y + 0.2, iconD, { bg: accent }); ty = y + 0.2 + iconD + 0.12; }
  if (num !== undefined) txt(s, String(num), x + w - 0.6, y + 0.12, 0.45, 0.4, { size: 20, bold: true, color: T[100], align: 'right' });
  if (title) txt(s, title, x + 0.22, ty, w - 0.44, 0.32, { size: titleSize, bold: true, color: INK });
  if (body) {
    const arr = Array.isArray(body) ? body.map((t, i) => ({ text: t, options: { breakLine: i < body.length - 1, paraSpaceAfter: 3 } })) : body;
    s.addText(arr, { x: x + 0.22, y: ty + (title ? 0.36 : 0), w: w - 0.44, h: h - (ty - y) - (title ? 0.36 : 0) - 0.15, fontFace: FONT, fontSize: bodySize, color: bodyColor, valign: 'top', margin: 0, lineSpacingMultiple: 1.18, isTextBox: true });
  }
}
function table(s, rows, x, y, w, colW, o = {}) {
  const data = rows.map((r, ri) => r.map((c, ci) => {
    const cell = typeof c === 'object' && c !== null && 'text' in c ? c : { text: String(c) };
    const head = ri === 0;
    return { text: cell.text, options: { fontFace: FONT, fontSize: head ? (o.headSize ?? 10.5) : (cell.size ?? o.size ?? 10.5), bold: head || !!cell.bold || (o.boldFirstCol && ci === 0), color: head ? WHITE : (cell.color ?? INK), fill: { color: head ? (o.headFill ?? T[700]) : (cell.fill ?? (ri % 2 ? 'F7FAF9' : WHITE)) }, align: cell.align ?? (o.align?.[ci] ?? 'left'), valign: 'middle', margin: [4, 6, 4, 6], hyperlink: cell.url ? { url: cell.url } : undefined } };
  }));
  s.addTable(data, { x, y, w, colW, rowH: o.rowH, border: { type: 'solid', pt: 0.5, color: LINE }, autoPage: false });
}
// 상태 셀 색
const OK = (t) => ({ text: t, color: GREEN, bold: true });
const WARN = (t) => ({ text: t, color: AMBER, bold: true });
const NO = (t) => ({ text: t, color: RED, bold: true });

async function build() {
  pres = new pptxgen();
  pres.layout = 'LAYOUT_WIDE';
  pres.author = 'Dmove Inc.';
  pres.title = '스트라드비전 요구사항 대응 방안 — Moves Workforce + Moves Approval';
  pres.lang = 'ko-KR';

  // 1. 표지
  {
    const s = pres.addSlide(); s.background = { color: T[900] };
    rect(s, 0, 0, 0.28, H, T[500]);
    s.addImage({ path: ASSET('app_logo.png'), x: M + 0.25, y: 0.75, w: 0.9, h: 0.9 });
    txt(s, 'ATLASSIAN JIRA CLOUD  ·  WORKFORCE + APPROVAL', M + 0.25, 1.95, 7.4, 0.3, { size: 11, color: T[300], bold: true, spacing: 3 });
    txt(s, '스트라드비전\n요구사항 대응 방안', M + 0.2, 2.3, 7.5, 1.6, { size: 44, bold: true, color: WHITE, valign: 'middle', lh: 1.1 });
    txt(s, '워크로그 락킹·승인 · 변경 이력 · SAP 연동 · 사용자 관리 —\n두 앱으로 어떻게 제공하는지, 무엇이 구현됐고 무엇이 남았는지.', M + 0.25, 4.05, 7.4, 0.9, { size: 16, bold: true, color: T[100], lh: 1.3 });
    txt(s, '미팅 기록(Tempo 담당 PM 포함 5명) 5개 요구를 워크포스 + 어프로벌 두 앱 기준으로 재판정하고,\n아키텍처·구현 현황·제약·데이터 관리 방안을 공식 문서 근거와 함께 정리했습니다.', M + 0.25, 5.0, 7.4, 0.75, { size: 12, color: 'B9D9D3', lh: 1.35 });
    ['코드 구현 완료 · 실측 전', '수용 기준 8항', '코덱스 독립 검토 반영', '공식 문서 근거 40건'].forEach((t, i) => chip(s, t, M + 0.25 + i * 1.85, 5.95, 1.75, 0.34, { bg: '1B4F49', fg: T[300], size: 9.5 }));
    slides.push({ s, kind: 'cover' });
    await imgFit(s, IMG('01-architecture.png'), 8.1, 1.3, 4.75, 3.6, { frame: true });
    txt(s, '두 앱 역할 분담 · 연동 아키텍처', 8.1, 5.0, 4.75, 0.25, { size: 9, color: '8FBDB6', italic: true, align: 'right' });
    s.addImage({ path: ASSET('dmove_wordmark_white.png'), x: M + 0.25, y: 6.72, w: 1.3, h: 0.3 });
    txt(s, '내부 검토 · 2026-10-13', 9.5, 6.72, 3.35, 0.3, { size: 10, color: T[300], align: 'right', valign: 'middle', spacing: 2 });
  }

  // 2. 목차
  {
    const s = content('', 'AGENDA', '오늘 다룰 내용', '요구별 판정 → 아키텍처 → 핵심 기능 구현 → 데이터 관리 → 수용 기준·후속 순서로 설명합니다.');
    const items = [
      ['01', '요약과 결론', '요구 5건 판정, "코드 구현"과 "제공 가능"의 구분', 'FaClipboardCheck'],
      ['02', '아키텍처', '전체 시스템, 두 앱 역할 분담, 연동 계약(프로퍼티+서명)', 'FaSitemap'],
      ['03', '워크로그 락킹·승인', '승인 흐름, 잠금 4층, 통제 Phase·관문, 인증 모델, 구현 근거', 'FaLock'],
      ['04', '이력·데이터 관리', '변경 이력 파이프라인, 데이터 지도, 보존·용량, 개인정보·제거', 'FaDatabase'],
      ['05', 'SAP·사용자 관리·기타', 'apiRoute vs xlsx, 조직 동기화 범위, 기타 5건', 'FaExchangeAlt'],
      ['06', '수용 기준과 후속', '계약 문구 8항, 코덱스 검토 반영, 후속 조치, 공식 문서', 'FaFlagCheckered'],
    ];
    const cw = (CW - 0.3 * 2) / 3, ch = 2.1;
    for (let i = 0; i < items.length; i++) {
      const [n, t, d, ic] = items[i];
      const x = M + (i % 3) * (cw + 0.3), y = TOP + 0.15 + Math.floor(i / 3) * (ch + 0.3);
      rect(s, x, y, cw, ch, i % 3 === 1 ? T[50] : WHITE, { line: LINE, shadow: true });
      await iconCircle(s, ic, x + cw - 0.85, y + 0.25, 0.55, { bg: T[100], fg: T[900] });
      txt(s, n, x + 0.3, y + 0.22, 1.2, 0.5, { size: 26, bold: true, color: T[500] });
      txt(s, t, x + 0.3, y + 0.85, cw - 0.5, 0.4, { size: 16, bold: true, color: INK });
      txt(s, d, x + 0.3, y + 1.28, cw - 0.5, 0.7, { size: 11, color: GRAY, lh: 1.3 });
    }
  }

  // ═══ 01 요약 ═══
  section('01', '요약과 결론', '미팅 기록의 "미지원·구조상 불가"는 워크포스 단독 기준입니다.\n어프로벌 앱을 포함하면 핵심 요구는 코드 구현이 끝나 있습니다.',
    ['요구 5건 × 두 앱 기준 판정', '"코드 구현 완료"와 "제공 가능"은 다른 열', '지금 제공 가능한 것 / 미완료인 것']);

  // 4. 요약 표
  {
    const s = content('01', '요약과 결론 · 요구별 판정', '다섯 가지 요구를 두 앱 기준으로 다시 판정했습니다', '미팅 기록은 워크포스 단독 기준입니다. 어프로벌(moves-approval-jira)을 같이 보면 3·4번 판정이 바뀝니다.');
    const rows = [
      ['#', '요구사항', '미팅 기록 판정', '두 앱 기준 판정', '담당', '지금 제공 가능', '미완료'],
      ['1', 'SAP 연동(월 1회)', '조건부 지원', WARN('조건부 지원'), '워크포스', '워크로그 xlsx 수동 추출', 'apiRoute(Preview) 실기능 · 호출자 신원 실측 · SAP 필드 매핑'],
      ['2', '사용자 관리 자동화', '부분 지원', WARN('부분 지원'), '워크포스', '엑셀 사용자 등록 · 퇴사자 워크로그는 Jira 원본이라 보존', '입·퇴사 자동 반영 · Jira 그룹/역할 동기화 · 팀 열 Import'],
      ['3', '워크로그 락킹·승인 ⭐', NO('미지원 · 구조상 불가'), OK('코드 구현 완료 · 실측·연동 전'), '어프로벌', '월 제출→팀장 승인 · 팀 일괄 승인 · 승인자 로깅 · 우리 화면 기간 잠금 · 다른 경로 사후 감지', 'Jira 경로 수정·삭제 차단(Phase B)은 실측 관문 5종 통과 후 · 연동 팀장 명부 게시'],
      ['4', '변경 이력 감사', NO('미지원(Storage 제약)'), OK('코드 구현 완료'), '어프로벌', '수집 이후 생성·수정·삭제 이력(전/후 값·행위자·출처) · 보존·내보내기', '삭제 행위자·누락률 실측 · 용량 산정'],
      ['5', '기타 5건', '확인 필요', WARN('6-1 경로 있음 / 6-2 부분 / 6-3·4·5 없음'), '혼합', '공휴일 수동 등록 · 미소속자 가이드', 'OKR·Outlook 범위 밖 권고 · 알림 채널 확인'],
    ];
    table(s, rows, M, TOP + 0.1, CW, [0.35, 1.7, 1.55, 1.85, 0.85, 2.95, CW - 9.25], { size: 9.5, headSize: 10, rowH: [0.4, 0.75, 0.75, 0.95, 0.75, 0.75], boldFirstCol: true });
    txt(s, '미팅 기록 4.2 "Worklog 를 쌓는 로직을 앱이 직접 컨트롤해야 함" = 어프로벌의 jira:timeTrackingProvider + 통제권 이관 설계. 고객에게는 두 앱 번들로 제안합니다.', M, 6.58, CW, 0.3, { size: 10.5, color: T[700], bold: true });
  }

  // 5. 결론 — 구현 vs 제공
  {
    const s = content('01', '요약과 결론 · 상태 구분', '"코드 구현 완료"와 "고객에게 제공 가능"을 구분합니다', '코덱스 독립 검토가 가장 먼저 지적한 점입니다. 세 상태를 섞으면 고객 앞에서 약속이 깨집니다.');
    const cols = [
      ['FaCode', '코드 구현 완료', GREEN, ['타임시트 제출·팀장 승인·일괄 승인(50건/PIN 1회)', '승인자·일시·기간 로깅 + 서명/PIN + 증명서', 'timeTrackingProvider 로 Jira Log work 대체', 'visibility 숨김 통제(Phase A~D) + 진단 도구', '워크로그 미러·이력 + 보존·내보내기', '인증 모델(RFC-220) + 사용자×월 서명 문서', '테스트 BE 2,460 · UI 677 통과']],
      ['FaVial', '플랫폼 실측 · 연동 미완료', AMBER, ['실측 관문 0건 — G_ROLE·G_BLOCK·G_PRESERVE·G_AGG·G_RECOVER', 'timeTrackingProvider 의 REST·자동화·모바일 차단 여부', '워크포스 RFC-220 브랜치 master 미병합 · 일부 미커밋', '팀·팀장 명부(rms.org)·제한선(rms.check) 게시 미구현', '3LO 호출자 accountId 수신 여부(apiRoute)', '삭제 이벤트 행위자 · 이벤트 누락률']],
      ['FaRocket', '운영 준비 미완료', RED, ['운영 설치처 없음 · Marketplace 미등록', '연동 서명 운영(prd) 키 미등록 · 교체 절차 미정', '통제 알림(Q130) 미해결', '개인정보 보존 정책 법무·Marketplace 확인', '고객 인원·건수 기준 용량·정산 완전성 검증']],
    ];
    const cw = (CW - 0.6) / 3;
    for (let i = 0; i < 3; i++) {
      const [ic, t, c, body] = cols[i];
      const x = M + i * (cw + 0.3);
      await card(s, x, TOP + 0.1, cw, 4.35, { iconName: ic, title: t, body: body.map((b) => '· ' + b), accent: c, titleSize: 14, bodySize: 10.5 });
    }
    rect(s, M, 6.55, CW, 0.3, T[50]);
    txt(s, '제안: 두 앱 번들로 제안하되, 왼쪽 열만 "제공"으로 말하고 가운데·오른쪽 열은 일정과 조건으로 말한다.', M + 0.2, 6.55, CW - 0.4, 0.3, { size: 10.5, bold: true, color: T[900], valign: 'middle' });
  }

  // ═══ 02 아키텍처 ═══
  section('02', '아키텍처', '두 앱 모두 Atlassian Forge 안에서 실행되고,\nJira 엔티티 프로퍼티로만 대화합니다.',
    ['전체 시스템 아키텍처(5계층)', '두 앱의 역할 분담', '연동 계약 — 엔티티 프로퍼티 + Ed25519 서명', '연동 모드는 관리자가 명시적으로 켠다']);

  // 7. 전체 시스템 아키텍처
  {
    const s = content('02', '아키텍처 · 전체 시스템', '브라우저부터 저장소·외부까지 — 외부 서버 없이 Forge 안에서 끝납니다', '① Jira 화면 안 Forge UI → ② Forge 함수(resolver·트리거·큐) → ③ 앱 저장소 → ④ Jira 데이터·프로퍼티 → ⑤ 테넌트 밖');
    await imgFit(s, IMG('00-system-architecture.png'), M, TOP + 0.05, 7.9, 4.75, { frame: true, alignLeft: true, alignTop: true });
    points(s, [
      ['① UI 는 Jira 화면 안 iframe', 'globalPage·adminPage·issueAction·issueActivity 등 Forge 모듈. CRA 멀티 엔트리 + Atlaskit.'],
      ['② 함수는 샌드박스에서 25초', 'resolver 는 guardedDefine + PermissionMap(미선언 거부). 트리거·스케줄·큐 fan-out.'],
      ['③ 저장소는 설치당 분리', 'Forge SQL(어프로벌) / SQL+KVS(워크포스). 앱 간 공유 불가 → 프로퍼티로 교환.'],
      ['④ Jira 가 원본', '워크로그·권한 스킴·visibility. asUser 기본, asApp 은 사유 명시.'],
      ['⑤ 외부로 나가는 길은 둘', 'SAP(관리자가 켜는 apiRoute 또는 xlsx)와 사용자 다운로드. 앱의 외부 전송 없음 → Runs on Atlassian.'],
    ], 8.8, TOP + 0.1, W - M - 8.8, 0.95, { titleSize: 11.5, size: 9.5 });
  }

  // 8. 두 앱 역할
  {
    const s = content('02', '아키텍처 · 역할 분담', '잠금·승인·이력은 어프로벌, 인력·계획·원가·API 는 워크포스', '워크포스는 어프로벌이 없으면 지금 그대로 단독 동작합니다. 어프로벌은 워크포스가 없으면 앱 내 팀 명부로 팀장을 판정합니다.');
    await imgFit(s, IMG('01-architecture.png'), M, TOP + 0.05, 7.9, 4.75, { frame: true, alignLeft: true, alignTop: true });
    const rows = [
      ['', '워크포스', '어프로벌'],
      ['역할', '팀·팀장·인력 배정·계획·원가·가동률·간트·외부 API', '타임시트 승인·기간 잠금·통제·인증·변경 이력·감사·증명서'],
      ['저장소', 'Forge SQL + KVS · 연동으로 새 테이블 없음', 'Forge SQL · 마이그레이션 v063'],
      ['Jira 모듈', 'globalPage · issueActivity · customField 6 · scheduledTrigger 4', 'timeTrackingProvider · workflowValidator · issueAction 2 · trigger 4 · preUninstall'],
      ['상태', '커밋 524 · 운영 배포 경험 · 연동은 RFC-220 브랜치', '커밋 30(10/04~12) · 개발 사이트 1회 배포 · Marketplace 미등록'],
    ];
    table(s, rows, 8.8, TOP + 0.1, W - M - 8.8, [0.75, 1.55, W - M - 8.8 - 2.3], { size: 8.5, headSize: 9.5, rowH: [0.3, 0.9, 0.7, 0.95, 0.95], boldFirstCol: true });
  }

  // 9. 연동 계약
  {
    const s = content('02', '아키텍처 · 연동 계약', '프로퍼티는 운반 수단일 뿐, 신뢰는 서명으로 만듭니다', 'Forge 앱끼리는 저장소 공유·직접 호출이 불가합니다. 엔티티 프로퍼티는 편집 권한자 누구나 쓸 수 있어 서명 검증 후에만 신뢰합니다.');
    const rows = [
      ['방향', '엔티티 · 키', '내용', '상태'],
      ['어프로벌 → 워크포스', '사용자 movesApproval.cert.{YYYY-MM}', '인증 시간 문서: 합계 cs · 건수 · [worklogId,초,flag] ≤1,000 · 삭제분 이슈 di · kid/iat/sig', OK('구현 · dev/stg 키')],
      ['어프로벌 → 워크포스', '사용자 movesApproval.{YYYY}', '기간별 결재 상태 · 워크로그 묶음 지문(배지용)', OK('구현')],
      ['어프로벌 → 워크포스', '이슈·프로젝트 movesApproval.ctl', '통제 설정 · 하위 경로 넘김 정보', OK('구현')],
      ['워크포스 → 어프로벌', '사용자 movesRms.org (cap wlorigin)', '능력 신호 · 작성 출처 서명', WARN('구현 · 미커밋')],
      ['워크포스 → 어프로벌', '사용자 rms.org.leaderKeys · 프로젝트 rms.pm', '팀·팀장 명부 · PM — 연동 모드 팀장 판정의 전제', NO('미구현(계약만)')],
      ['워크포스 → 어프로벌', '워크로그 rms.check', '제한선 위반 코드(OVER_PLAN·NOT_MEMBER) → 예외 승인 단계', NO('미구현(계약만)')],
    ];
    table(s, rows, M, TOP + 0.1, 8.3, [1.5, 2.35, 3.2, 1.25], { size: 9, headSize: 10, rowH: [0.35, 0.72, 0.5, 0.5, 0.5, 0.62, 0.62], boldFirstCol: true });
    points(s, [
      ['서명 = 위조 방지', 'Ed25519 · 서명 대상에 cloudId·엔티티 id 포함 → 다른 사이트·다른 워크로그로 복사 재사용 불가. 검증 실패 = 없는 것(단독 경로) + 감사 로그.'],
      ['서명 ≠ 기밀성', '프로퍼티 읽기 범위는 Jira 엔티티 열람 권한. 판정 결과·지문·합계만 싣고 설명 원문·급여·단가는 싣지 않는다.'],
      ['연동은 명시적으로 켠다', '어프로벌 workforceLinkEnabled 기본 false(10/12) · 워크포스 approvalLinkMode 기본 OFF. 자동 감지 없음.'],
      ['키 운영', '개인키는 forge variables set --encrypt, 공개키는 상대 앱 keyring.js 내장. dev·stg 등록, prd 미등록, 교체·폐기 절차 미정.'],
    ], 9.15, TOP + 0.1, W - M - 9.15, 1.15, { titleSize: 11, size: 9 });
  }

  // ═══ 03 락킹·승인 ═══
  section('03', '워크로그 락킹·승인', '고객의 핵심 요구입니다.\n승인·일괄 승인·로깅은 구현됐고, 잠금은 4층으로 막되 "막지 못하는 것"을 명시합니다.',
    ['타임시트 승인 흐름(사용자×월)', '잠금 4층 — 경로별로 다른 장치', '통제 Phase A~D 와 실측 관문', '인증 모델(RFC-220) — 인증값은 바뀌지 않는다', '구현 근거 — 모듈·테이블·resolver']);

  // 11. 승인 흐름
  {
    const s = content('03', '워크로그 락킹·승인 · 승인 흐름', '사용자×월 단위로 제출하고 팀장이 결재합니다 — 결정이 진실, 상태는 파생', 'Tempo 수준의 "단순 1단계 승인 + 팀장 일괄 승인 + 누가 승인했는지 로깅" 요구에 그대로 대응합니다.');
    await imgFit(s, IMG('03-approval-flow.png'), M, TOP + 0.05, 8.3, 4.75, { frame: true, alignLeft: true, alignTop: true });
    points(s, [
      ['제출 단위 = 사용자×기간', 'scopeKey TIMESHEET:{accountId}:{periodKey}, 기본 월(approvalUnit 으로 주 변경). 열린 요청은 대상당 하나.'],
      ['팀장 일괄 승인', '팀×기간 매트릭스에서 decideTimesheets 최대 50건 · PIN 1회 · 18초 예산 초과분은 remaining 으로 반환.'],
      ['승인자 로깅', 'approval_approver 행이 원천, approval_event 는 결정적 id. 서명/PIN · 증명서 PDF · 감사 탭 검색·엑셀.'],
      ['승인 후 변경 감지', '스냅샷 hash 불일치 → CHANGED_AFTER_APPROVAL. 결재 중 변경은 EXPIRED(CONTENT_CHANGED).'],
      ['마감·재개방', 'closePeriod / reopenPeriod 두 단계(새 입력만 · 수정까지: 승인·인증 해제 + 사유 필수).'],
    ], 9.15, TOP + 0.1, W - M - 9.15, 0.95, { titleSize: 11, size: 9 });
  }

  // 12. 잠금 4층
  {
    const s = content('03', '워크로그 락킹·승인 · 잠금 4층', '경로마다 다른 층이 막고, 막지 못하는 것은 감지합니다', '"Jira 에 워크로그 쓰기 사전 훅이 없다"는 제약은 그대로입니다. 그래서 화면 대체(2층)·확정분 숨김(4층)·감지(3층)·권한 스킴(1층)을 조합합니다.');
    await imgFit(s, IMG('02-lock-layers.png'), M, TOP + 0.05, 8.3, 4.75, { frame: true, alignLeft: true, alignTop: true });
    const rows = [
      ['층', '장치', '상태'],
      ['1 누가', 'Jira 권한 스킴 "Work on work items" → 프로젝트 역할만 (고객 관리자)', WARN('가이드만')],
      ['2 언제', 'jira:timeTrackingProvider(Preview) — Jira Log work 숨김 → 우리 화면이 서버 판정 후 거부', OK('구현 · 실측 전')],
      ['3 감지', '워크로그 이벤트 3종 + 일일 스윕(worklog/updated·deleted since)', OK('구현')],
      ['4 보호', 'visibility 를 앱 역할로 제한 → 확정분 수정·삭제는 사람 불가, 앱이 asApp 실행', WARN('구현 · 기본 OFF · 관문 전')],
    ];
    table(s, rows, 9.15, TOP + 0.1, W - M - 9.15, [0.55, 2.05, W - M - 9.15 - 2.6], { size: 8.5, headSize: 9.5, rowH: [0.3, 0.75, 0.85, 0.65, 0.85], boldFirstCol: true });
    rect(s, 9.15, 5.75, W - M - 9.15, 1.0, AMBER_BG, { line: AMBER });
    txt(s, '막지 못하는 것(수용 기준)', 9.3, 5.82, 3.5, 0.25, { size: 10, bold: true, color: AMBER });
    txt(s, '다른 경로의 새 입력 · 마감만 되고 미승인인 기록 · 원래 제한 공개였던 기록. 비동기 사후 감지(수 초~수 분, 누락 시 하루).', 9.3, 6.08, W - M - 9.3 - 0.1, 0.65, { size: 9, color: INK, lh: 1.3 });
  }

  // 13. Phase·관문
  {
    const s = content('03', '워크로그 락킹·승인 · 통제 Phase', '위험 모드는 기본 OFF — 사이트별 실측 관문을 통과해야 서버가 켜 줍니다', '1차 목표는 Phase B(승인·인증된 건만 숨김). Phase D(자동 삭제)는 사용자 결정으로 쓰지 않습니다.');
    await imgFit(s, IMG('07-control-phases.png'), M, TOP + 0.05, CW, 3.0, { frame: true, alignTop: true });
    const rows = [
      ['관문', '확인하는 것', '실패하면'],
      ['G_ROLE', 'Forge 앱 계정이 제한 역할(atlassian-addons-project-access) 멤버이고 Edit/Delete all 보유', 'visibility 안 전체 재검토'],
      ['G_PRESERVE', 'visibility 만 PUT 해도 다른 값 보존 · null 로 해제 · notifyUsers=false', '후퇴 모드 미구현 → C 금지'],
      ['G_BLOCK', '작성자·관리자·API 토큰 REST 가 숨김분을 GET/PUT/DELETE 못함(404/403)', 'Phase B 약속 불가'],
      ['G_AGG · G_RECOVER', '이슈 timespent·JQL·리포트 집계 보존 · 해제·제거 복구(preUninstall 55초)', 'Phase B 약속 불가'],
    ];
    table(s, rows, M, 5.2, CW, [1.5, 7.8, CW - 9.3], { size: 9, headSize: 9.5, rowH: [0.27, 0.28, 0.28, 0.28, 0.28], boldFirstCol: true });
  }

  // 14. 인증 모델
  {
    const s = content('03', '워크로그 락킹·승인 · 인증 모델(RFC-220)', '인증된 시간의 원본은 어프로벌 DB — Jira 가 바뀌어도 인증값은 그대로', '"수정을 완전히 막을 수 없으니 수정해도 인증된 시간은 안 바뀌게" — 감사 대응의 핵심 장치입니다.');
    await imgFit(s, IMG('04-certification.png'), M, TOP + 0.05, 8.3, 4.75, { frame: true, alignLeft: true, alignTop: true });
    points(s, [
      ['인증 = 값 고정', '팀장이 인증하는 순간 이슈·작성자·시작·초의 지문을 worklog_cert 에 고정. 상위자 인증 원칙, 상위자 없는 팀장만 본인 인증.'],
      ['이후 변경은 표시만', '수정 → MISMATCH, 삭제 → DELETED. deletedCertifiedHandling KEEP(기본)/ZERO.'],
      ['워크포스는 문서 범위만 인증 적용', '사용자×월 서명 문서가 있는 범위에 인증 시간, 없는 범위는 기존 계산(legacySeconds). 인증 필수 모드는 결정 필요.'],
      ['정산 완전성 상한', '문서 30,000B · 목록 1,000건(초과 시 wt 잘림 → 목록 밖은 UNKNOWN 으로 원가 제외) · 조회 300명.'],
      ['FLAG 는 인증을 막지 않음', '다른 경로 입력은 출처 경고만. 서버 자동 제외는 워크포스 출처 서명 가동 후.'],
    ], 9.15, TOP + 0.1, W - M - 9.15, 0.95, { titleSize: 11, size: 9 });
  }

  // 15. 구현 근거
  {
    const s = content('03', '워크로그 락킹·승인 · 구현 근거', '"구현했다"의 근거 — manifest 모듈, 테이블, resolver', '어프로벌 리포 master b23524f(2026-10-12). 테스트 BE 157 suites/2,460 · UI 78/677 통과(마지막 검증 기록).');
    const rows = [
      ['요구', 'Jira 모듈(manifest)', '테이블(Forge SQL)', 'resolver · 함수'],
      ['승인 요청/승인', 'globalPage 업무함 · issueActivity 작업 로그 탭', 'approval_request · approval_approver · approval_event · timesheet_submission', 'submitTimesheet · decideApproval · getTeamTimesheetMatrix'],
      ['일괄 승인', 'globalPage 업무함(팀 매트릭스)', 'approval_approver(조건부 UPDATE, 삭제-재삽입 금지)', 'decideTimesheets(≤50건·PIN 1회·18초) · bulkApprove'],
      ['승인 이력 로깅', 'adminPage 설정 > 기록 > 감사', 'approval_event(결정적 id) · approval_signature · approval_pin', 'getApprovalCertificate · 감사 검색·엑셀 · 보관 내보내기'],
      ['기간 락킹', 'jira:timeTrackingProvider · issueAction Log work · trigger worklog-changed · scheduledTrigger approval-sweep', 'approval_period_close · approval_period_reopen · timesheet_close_drift', 'closePeriod · reopenPeriod · onWorklogChanged · runSweep'],
      ['확정분 보호(통제)', 'preUninstall worklog-control-pre-uninstall · consumer sweep-job', 'worklog_control · worklog_control_intent · worklog_control_log', 'WorklogControlWorker(숨김/해제) · recordWorklogControlGate · 진단 도구'],
      ['인증', 'issueActivity(인증 배지) · queue(게시)', 'worklog_cert · worklog_cert_batch · worklog_cert_log', 'certifyWorklogs · certifyOwnWorklogs · WorkforcePublisher'],
      ['변경 이력', 'trigger worklog-changed · scheduledTrigger', 'worklog_mirror · worklog_history (PK worklog_id, seq)', 'WorklogHistoryRecorder · exportExpiredRecords · purgeExportedRecords'],
    ];
    table(s, rows, M, TOP + 0.1, CW, [1.45, 3.6, 3.6, CW - 8.65], { size: 8.5, headSize: 9.5, rowH: [0.3, 0.55, 0.5, 0.5, 0.65, 0.55, 0.5, 0.5], boldFirstCol: true });
    txt(s, '근거 파일: manifest.yml · src/rdb/schema/ddl/*.sql.js(29종) · src/permission/PermissionMap.js(resolver 3단계 등록 계약 테스트) · docs/DESIGN.md §2.0·§4 · _workspace/worklog-control/01_architect_design.md', M, 6.35, CW, 0.4, { size: 9, color: MUTED, mono: false });
  }

  // ═══ 04 이력·데이터 ═══
  section('04', '이력·데이터 관리', '미팅 기록의 "Forge Storage 제약"은 KVS 기준입니다.\n어프로벌은 Forge SQL 을 쓰고, 보존·내보내기·용량·개인정보를 설계에 넣었습니다.',
    ['변경 이력 파이프라인(이벤트 → 미러·이력 → 내보내기)', '데이터 지도 — 어디에, 누가 주인인가', '보존 기간과 용량 계획', '개인정보 · 앱 제거 · 레지던시']);

  // 17. 이력 파이프라인
  {
    const s = content('04', '이력·데이터 관리 · 변경 이력', '생성·수정·삭제를 이벤트로 받아 전/후 값·행위자·출처를 남깁니다', '범위는 "수집 시작 이후 관측한 변경" 입니다. 설치 이전 이력·이벤트 사이 중간 수정·Jira 경로 삭제 행위자(미검증)는 빠질 수 있습니다.');
    await imgFit(s, IMG('05-history-pipeline.png'), M, TOP + 0.05, 8.3, 4.75, { frame: true, alignLeft: true, alignTop: true });
    points(s, [
      ['KVS 가 아니라 Forge SQL', '업무함의 다축 필터·정렬·페이징을 Custom Entity(인덱스 7개)로 표현할 수 없어 SQL 선택. 설치당 운영 1GiB.'],
      ['중복 없는 이력', '이력 PK (worklog_id, seq) 결정적 · 미러 CAS rev=rev+1. 같은 이벤트·스윕 경합은 두 번째가 차이 0 으로 무기록.'],
      ['삭제 본문 복원', '삭제 이벤트에 본문이 없어도 미러의 마지막 스냅샷에서 삭제 기록 생성.'],
      ['설명 원문', '기본은 지문 + 앞 40자. worklogHistoryKeepComment 로 원문 보관(+54MB/년).'],
      ['알 수 없는 것', 'Jira 경로 삭제의 행위자(페이로드 실측 전) · 입력 경로(웹/REST/모바일) 구분 · 설치 이전 이력.'],
    ], 9.15, TOP + 0.1, W - M - 9.15, 0.95, { titleSize: 11, size: 9 });
  }

  // 18. 데이터 지도
  {
    const s = content('04', '이력·데이터 관리 · 데이터 지도', '원본은 Jira 에, 앱 데이터는 Atlassian 인프라 안에', '앱이 외부 서버로 보내는 경로는 없습니다(Runs on Atlassian). 테넌트 밖으로 나가는 것은 사용자 다운로드와 고객이 켜는 SAP 연동뿐입니다.');
    await imgFit(s, IMG('08-data-map.png'), M, TOP + 0.05, 8.3, 4.75, { frame: true, alignLeft: true, alignTop: true });
    const rows = [
      ['데이터', '원본', '주인'],
      ['워크로그', 'Jira', '고객'],
      ['승인 결정·서명/PIN', '어프로벌 SQL', '고객(설치 단위)'],
      ['인증된 시간', '어프로벌 SQL', '고객'],
      ['변경 이력·통제·설정 감사', '어프로벌 SQL', '고객'],
      ['팀·인력·급여·계획', '워크포스 SQL+KVS', '고객'],
      ['서명 개인키', 'Forge 환경 변수(암호화)', '디무브'],
      ['다운로드 파일(xlsx·PDF)', '고객 PC', '고객'],
    ];
    table(s, rows, 9.15, TOP + 0.1, W - M - 9.15, [1.7, 1.3, W - M - 9.15 - 3.0], { size: 8.5, headSize: 9.5, rowH: 0.36, boldFirstCol: true });
    txt(s, '접근 통제: asUser 기본 · asApp 은 승인된 예외 6조건(호출자=principal · SQL 소유자 조건 선적용 · 건별 열람 재확인 · 우리가 가린 것만 · 설명은 본인만 · 합계·캐시 동일 범위) · 가드 통과 ≠ 범위 확정.', 9.15, 5.25, W - M - 9.15, 1.4, { size: 9, color: GRAY, lh: 1.3 });
  }

  // 19. 보존·용량
  {
    const s = content('04', '이력·데이터 관리 · 보존과 용량', '보존 기간이 지나도 내보낸 뒤에만 지우고, 용량은 인원 기준으로 산정합니다', 'Forge SQL 한도는 환경별(prod 1GiB · stg 256MiB · dev 128MiB)입니다. 앱 환경 변수 STORAGE_LIMIT_BYTES 는 표시 기준만 바꿉니다.');
    const rows = [
      ['기록', '테이블', '기본 보존 · 선택지', '만료 처리'],
      ['워크로그 변경', 'worklog_mirror · worklog_history', '일반 12개월 / 워크포스 연결분 36개월(0·12·24·36·60)', '내보내기 확정 후 삭제'],
      ['결재', 'approval_event/request/approver', '3년(0·1·3·5·10)', '내보내기 확정 후 삭제'],
      ['인증', 'worklog_cert_batch · _log', '무기한(0·3·5·7·10)', '내보내기 확정 후 삭제'],
      ['통제 조치', 'worklog_control_log', '무기한(0·1·3·5·7·10)', '내보내기 확정 후 삭제'],
      ['설정 변경 · 알림', 'approval_settings_audit · approval_notification', '365일 고정 · 180일', WARN('스윕이 자동 정리')],
    ];
    table(s, rows, M, TOP + 0.1, 7.9, [1.3, 2.5, 2.4, 1.7], { size: 9, headSize: 9.5, rowH: [0.3, 0.5, 0.42, 0.42, 0.42, 0.5], boldFirstCol: true });
    txt(s, '내보내기(exportExpiredRecords → confirmRecordExport → purgeExportedRecords)는 기록 추출이지 복원 가능한 백업이 아닙니다. 라이선스 INACTIVE 면 내보내기도 막히므로 해지 전에 내려받습니다.', M, 5.0, 7.9, 0.6, { size: 9.5, color: RED, lh: 1.3 });
    // 용량 카드
    const cx = 8.8, cw = W - M - cx;
    rect(s, cx, TOP + 0.1, cw, 1.5, T[900]);
    txt(s, '200명 기준 연간 적재(실측 전)', cx + 0.25, TOP + 0.22, cw - 0.5, 0.3, { size: 10.5, color: T[300], bold: true, spacing: 1 });
    txt(s, '약 465 MB / 년', cx + 0.25, TOP + 0.5, cw - 0.5, 0.6, { size: 30, bold: true, color: WHITE, valign: 'middle' });
    txt(s, '→ 3년 보관이면 운영 한도 1GiB 초과 가능 · 1,000명이면 약 5배', cx + 0.25, TOP + 1.12, cw - 0.5, 0.35, { size: 10, color: T[100] });
    const rows2 = [
      ['항목', '연간'],
      ['결재·타임시트', '약 150MB'],
      ['워크로그 이력', '약 148MB(원문 +54)'],
      ['인증', '약 80MB'],
      ['통제(최악)', '약 80MB'],
      ['프로퍼티 상한', '32KB/건 · 목록 1,000건 · 조회 300명'],
    ];
    table(s, rows2, cx, TOP + 1.8, cw, [1.6, cw - 1.6], { size: 9, headSize: 9.5, rowH: 0.34, boldFirstCol: true });
    txt(s, '고객 산정 입력값: 인원 × 월 워크로그 건수 × 월 변경 횟수 × 보존 기간', cx, 6.0, cw, 0.5, { size: 9.5, color: T[700], bold: true, lh: 1.3 });
  }

  // 20. 개인정보·앱 제거·레지던시
  {
    const s = content('04', '이력·데이터 관리 · 개인정보 · 제거 · 레지던시', '계정 삭제·앱 제거·리전은 운영 절차로 정해 둡니다', '코덱스 검토가 지적한 대로 "무조건 보존"·"전량 해제"·"즉시 삭제" 같은 단정은 쓰지 않습니다.');
    const items = [
      ['FaUserShield', '개인정보 보고(report:personal-data)', ['Atlassian 보고 주기(기본 7일)로 삭제(closed)된 계정의 기능용 개인정보(서명 이미지·PIN·알림·위임·명부)만 삭제', '감사 기록의 계정 id 보존은 내부 방침(Q138) — 법무·Marketplace 확인 후 처리방침에 명시', '일반 퇴사(비활성)는 closed 가 오지 않음 → "삭제 말고 비활성화" 가이드']],
      ['FaTrashRestore', '앱 제거 절차', ['주 절차: 관리자가 설정 > 워크로그 통제에서 전체 해제 → 잔여 0 확인 → 제거', 'preUninstall 트리거는 45초 예산의 보조 수단, 실패해도 제거 진행(공식 문서)', '제거 후 저장소는 soft delete → 영구 삭제(문서). 제거 전 기록 내보내기 필수']],
      ['FaGlobeAsia', '레지던시 · 무결성', ['Forge 호스티드 저장소(SQL·KVS)는 레지던시 지원(문서). 미확인: 고객 사이트 리전 · 두 앱 PINNED · 다운로드/SAP 사본 범위', '결정이 진실·상태 파생, CAS rev+1, 결정적 이벤트 id, 통제 조치는 사유 필수·추가 전용', '증명서 PDF 는 서버의 결정 사실·대상 지문으로 생성']],
    ];
    const cw = (CW - 0.6) / 3;
    for (let i = 0; i < 3; i++) {
      const [ic, t, body] = items[i];
      await card(s, M + i * (cw + 0.3), TOP + 0.1, cw, 3.7, { iconName: ic, title: t, body: body.map((b) => '· ' + b), titleSize: 12.5, bodySize: 10 });
    }
    rect(s, M, 6.05, CW, 0.5, T[50]);
    txt(s, '고객 안내 두 줄: ① 퇴사자는 Jira 계정 삭제 말고 비활성화, 삭제 전 감사 기록 내려받기  ② 앱 제거·라이선스 해지 전에 통제 전체 해제 → 잔여 0 확인 → 기록 내보내기', M + 0.2, 6.05, CW - 0.4, 0.5, { size: 10, bold: true, color: T[900], valign: 'middle' });
    {
    }
  }

  // ═══ 05 SAP·사용자·기타 ═══
  section('05', 'SAP · 사용자 관리 · 기타', '워크포스가 담당하는 요구입니다.\n지금 되는 것과 만들어야 하는 것, 범위 밖을 가릅니다.',
    ['SAP 연동 — xlsx(1차) · core:apiRoute(2차) · webtrigger 는 부적합', '사용자 관리 — Jira 그룹·역할까지, Atlassian 조직·Teams 는 범위 밖', '기타 요구 6-1 ~ 6-5']);

  // 22. SAP
  {
    const s = content('05', 'SAP · 사용자 관리 · 기타 · SAP 연동', '월 1회 — 1차 xlsx 추출, 2차 OAuth 기반 JSON REST(Preview)', 'static webtrigger 는 고정 응답만 반환하므로 pull API 대안이 아닙니다. OData 는 제품 범위에서 제외합니다.');
    await imgFit(s, IMG('06-sap-options.png'), M, TOP + 0.05, 8.3, 4.75, { frame: true, alignLeft: true, alignTop: true });
    points(s, [
      ['2026-09-16 실측', 'apiRoute 모듈 사용만으로 메이저 버전 상승(공식 목록엔 없음) · Runs on Atlassian 배지 유지 · 게이트웨이가 토큰 없는 호출을 401 로 차단.'],
      ['가드가 전부 우회된다', 'apiRoute 는 resolver 와 별개 진입점. 신원→권한→스코프→원가 가시성→라이선스를 핸들러가 직접 통과. 급여·원가 기본 제외.'],
      ['SAP 쪽 책임', '3LO 동의·토큰 교환·저장·refresh 회전·재인증. 연동 계정 퇴사·동의 철회 시 배치 중단 → 서비스 계정·절차 필요.'],
      ['미검증 1건', '핸들러가 호출자 accountId 를 받는지(3LO 연동 1회 생성). 결과에 따라 권한 모델이 갈린다.'],
      ['커스텀 스코프', '환경당 20개 · 삭제·이름 변경 불가 → 이름 체계를 먼저 확정.'],
    ], 9.15, TOP + 0.1, W - M - 9.15, 0.95, { titleSize: 11, size: 9 });
  }

  // 23. 사용자 관리
  {
    const s = content('05', 'SAP · 사용자 관리 · 기타 · 사용자 관리', 'Jira 그룹·역할 동기화까지 제공, Atlassian 조직·Teams 는 범위 밖', '퇴사자 워크로그는 Jira 원본이라 보존됩니다. 다만 워크포스의 "퇴사 = 삭제"를 "비활성 전환"으로 바꿔 집계·원가도 유지합니다.');
    const rows = [
      ['항목', '현행(코드)', '제공 방안', '판정'],
      ['입·퇴사자 자동 반영', 'users 에 활성/비활성 열 없음 · 퇴사 = 삭제(팀장 참조·배정·일정·스킬·users 행)', 'Jira 사용자 상태(active)·그룹을 주기 스윕으로 읽어 inactive 표시(삭제 아님)', WARN('신규 기능')],
      ['조직 동기화', '그룹·역할 호출 코드 0건(getMyGroupApi 정의만)', '1단계 Jira 그룹·프로젝트 역할 → 팀 매핑. 어프로벌 연동용 rms.org 명부 게시와 같이 설계', WARN('신규 기능')],
      ['Atlassian 조직 · Teams', '—', 'Admin API(조직 API 키)·Teams REST 는 Forge/OAuth2 접근 불가(문서) → 범위 밖 명시', NO('범위 밖')],
      ['엑셀 Import', 'Email 열만 읽어 Jira 사용자 조회 후 큐 등록', '팀·팀장 여부·직급·입사일·퇴사일 열 추가(기존 업로드 확장)', OK('있음 · 확장')],
      ['퇴사자 워크로그 보존', 'Jira 원본이라 보존. users·projectusers 삭제 시 집계·원가에서 빠질 수 있음(미검증)', '퇴사 = 비활성 전환으로 집계 유지. 어프로벌: 감사 기록 계정 id 보존, 삭제 계정은 "탈퇴한 사용자 A/B" 표시', OK('보존')],
    ];
    table(s, rows, M, TOP + 0.1, CW, [1.7, 4.0, 5.0, CW - 10.7], { size: 9.5, headSize: 10, rowH: [0.32, 0.72, 0.72, 0.6, 0.6, 0.85], boldFirstCol: true });
    txt(s, '고객 안내: 퇴사자는 Jira 계정 삭제 말고 비활성화. 삭제가 필요하면 그 전에 감사 기록 내려받기. "조직 단위"가 Jira 그룹인지 관리자 콘솔 조직인지 확인 요청.', M, 6.2, CW, 0.5, { size: 10, color: T[700], bold: true, lh: 1.3 });
  }

  // 24. 기타
  {
    const s = content('05', 'SAP · 사용자 관리 · 기타 · 기타 요구', '기타 5건 — 경로 있음 1, 부분 1, 없음 3', '외부 통신이 필요한 항목(메신저·공휴일 API·Outlook)은 egress 추가 = Runs on Atlassian 배지 상실이라 별도 결정이 필요합니다.');
    const rows = [
      ['#', '요구', '워크포스 현행', '어프로벌 현행', '판정', '후속'],
      ['6-1', '프로젝트 미소속자 입력 제한', '내 작업 화면은 소속 프로젝트 이슈만 · RFC-220 에서 소속 확인', '가이드·문구(권한 스킴 → 프로젝트 역할) · NOT_MEMBER 수신 코드', OK('경로 있음'), '완전 차단은 고객 권한 스킴. 역할 동기화·rms.check 게시는 미구현'],
      ['6-2', '계획 초과 알림(PM, 별도 채널)', '초과 배지(100/130%)·가동률 밴드 화면 표시만', 'OVER_PLAN 수신·예외 단계 코드. 앱 내 알림함 + Jira 코멘트 @멘션(상태 변경 승인만). 메일·Slack 없음', WARN('부분'), 'rms.check 게시 + Jira @멘션(Jira 가 메일 발송). 외부 메신저는 egress'],
      ['6-3', 'OKR', '없음', '없음', NO('없음'), '요구 구체화 전 범위 밖'],
      ['6-4', '휴일 자동 Import', '공휴일 수동 등록(KVS holiday, workRatio)', '휴일 변경 시 환산 기준 재게시', WARN('수동만'), '외부 API = egress. 대안 연 1회 엑셀 Import'],
      ['6-5', 'Outlook 연동', '없음', '없음', NO('없음'), '용도 확인. Graph 는 외부 인증·egress → 범위 밖 권고'],
    ];
    table(s, rows, M, TOP + 0.1, CW, [0.45, 1.75, 2.9, 3.1, 0.9, CW - 9.1], { size: 9, headSize: 9.5, rowH: [0.32, 0.8, 0.9, 0.42, 0.6, 0.6], boldFirstCol: true });
  }

  // ═══ 06 수용 기준·후속 ═══
  section('06', '수용 기준과 후속', '고객 앞에서 터지지 않도록,\n괄호 안이 아니라 문장으로 올리는 기준입니다.',
    ['계약·제안서에 올릴 수용 기준 8항', '코덱스 독립 검토 25건과 반영', '후속 조치 — 약속 수정 → 검증 → 연동 → 고객 범위', '고객 회신 초안', '부록 — 공식 문서 근거']);

  // 26. 수용 기준 8항
  {
    const s = content('06', '수용 기준과 후속 · 수용 기준', '계약·제안서에 문장으로 올릴 여덟 가지', '워크포스 v2.1 교훈: 괄호 안에 숨기면 계약 때 터집니다.');
    const items = [
      ['Preview 의존 2건', 'jira:timeTrackingProvider 와 core:apiRoute 는 Atlassian Preview 기능. 변경·폐기 가능성 명시.'],
      ['제공자는 사이트당 하나', '어프로벌을 시간 추적 제공자로 선택하면 Tempo 를 제공자로 동시에 선택할 수 없다(기능별 전환 영향 확인).'],
      ['잠금의 범위', '우리 화면은 서버가 거부. Jira 경로의 승인·인증된 기존 건 수정·삭제는 숨김으로 차단(관문 후 활성화). 새 입력·미승인 기록·원래 제한 공개 기록은 사후 감지.'],
      ['다른 경로 입력의 정산', '현행 기본은 출처 경고 표시만, 인증을 막지 않음. 서버 자동 제외는 워크포스 출처 서명 가동 후.'],
      ['변경 이력의 범위', '수집 시작 이후 관측한 변경. 설치 이전·중간 수정·Jira 경로 삭제 행위자는 빠질 수 있음.'],
      ['원가 "인증분만"의 뜻', '인증 문서가 있는 사용자×월에 인증 시간 적용, 없는 범위는 기존 계산. 인증 필수 모드는 결정 필요.'],
      ['앱 제거 전 통제 해제', '관리자가 전체 해제 실행 → 잔여 0 확인이 주 절차. 제거 트리거는 45초 보조 수단.'],
      ['데이터 보관', '설치당 Forge SQL 한도(운영 1GiB) 안에서 보존 기간·내보내기 운영. 내보내기 ≠ 백업.'],
    ];
    const cw = (CW - 0.3) / 2, ch = 1.08;
    for (let i = 0; i < items.length; i++) {
      const x = M + (i % 2) * (cw + 0.3), y = TOP + 0.05 + Math.floor(i / 2) * (ch + 0.12);
      rect(s, x, y, cw, ch, i % 2 ? T[50] : WHITE, { line: LINE });
      txt(s, String(i + 1).padStart(2, '0'), x + 0.2, y + 0.18, 0.7, 0.5, { size: 22, bold: true, color: T[300] });
      txt(s, items[i][0], x + 0.9, y + 0.14, cw - 1.1, 0.3, { size: 12, bold: true, color: INK });
      txt(s, items[i][1], x + 0.9, y + 0.46, cw - 1.1, ch - 0.5, { size: 9.5, color: GRAY, lh: 1.3 });
    }
  }

  // 27. 코덱스 검토
  {
    const s = content('06', '수용 기준과 후속 · 독립 검토', '코덱스 독립 검토 25건 — 코드 대조 8건 직접 확인, 전부 적중', '총평: "코드 구현·개발 사이트 검증·고객 제공 가능 상태를 혼합해 회신 근거로 바로 쓰기 어렵다" → 2판에서 분리했습니다.');
    const cx = M, cw = 3.3;
    rect(s, cx, TOP + 0.1, cw, 1.5, T[900]);
    txt(s, '지적', cx + 0.25, TOP + 0.22, cw - 0.5, 0.3, { size: 10.5, color: T[300], bold: true, spacing: 1 });
    txt(s, '🔴 13  🟠 9  🟡 3', cx + 0.25, TOP + 0.5, cw - 0.5, 0.6, { size: 18, bold: true, color: WHITE, valign: 'middle' });
    txt(s, '전부 반영 · 코드 확인 8/8 적중', cx + 0.25, TOP + 1.12, cw - 0.5, 0.35, { size: 10, color: T[100] });
    points(s, [
      ['검토 방식', 'gpt-6.1-sol · 읽기 전용 · 두 리포 열람 · 문서 본문 stdin'],
      ['검증 불가로 남긴 것', '관문 결과 · apiRoute 신원 실측 · visibility 차단 · 고객 SAP 필드·인원 · 운영 키·레지던시'],
    ], cx, TOP + 1.85, cw, 1.3, { titleSize: 11, size: 9 });
    const rows = [
      ['#', '지적(🔴 발췌)', '확인한 코드', '반영'],
      ['2', 'FLAG 는 인증을 막지 않음 → "정산 제외" 자동 성립 안 함', 'WorklogControlHooks.js:17 FOREIGN_BLOCKS_CERTIFICATION=false', '수용 기준 4 · 회신 초안 수정'],
      ['3', '원가 "인증분만"은 코드와 다름', 'certification.js:327 legacySeconds', '수용 기준 6'],
      ['4', 'Phase B 는 확정분만, 마감만 된 기록 제외', 'rules.js:197 shouldRestrict', '수용 기준 3 · 잠금 4층 표'],
      ['6', 'preUninstall 은 45초 보조 수단', 'onPreUninstall.js:9 PRE_UNINSTALL_BUDGET_MS', '수용 기준 7 · 제거 절차'],
      ['7', 'static webtrigger 는 고정 응답, pull API 아님', 'Web trigger 공식 문서', 'SAP 방식 B 부적합'],
      ['11', '보존 표 오류(통제 선택지·설정 변경 자동 정리)', 'recordRetention.js:26 · ExpiryService.js:387', '보존 표 재작성'],
      ['13', 'SQL 한도는 환경별, 환경 변수는 표시만', 'StorageService.js:8 · Forge SQL 문서', '용량 슬라이드'],
      ['14', '서버 관문은 G_AGG·G_RECOVER 포함 5종', 'gates.js:47 CONFIRMED_ONLY', 'Phase·관문 표'],
    ];
    table(s, rows, cx + cw + 0.3, TOP + 0.1, CW - cw - 0.3, [0.35, 3.3, 3.0, CW - cw - 0.3 - 6.65], { size: 8.5, headSize: 9.5, rowH: 0.47, boldFirstCol: true });
  }

  // 28. 후속 조치
  {
    const s = content('06', '수용 기준과 후속 · 후속 조치', '약속 수정 → 실측 → 연동 구현 → 고객 범위 확정 순서입니다', '우선순위는 코덱스 권고대로 재배열했습니다. 고객 회신 전에 1번이 끝나야 합니다.');
    const rows = [
      ['우선', '항목', '구분', '담당'],
      ['1', '고객 약속 문구 수정 — 수용 기준 8항을 제안서·회신에 반영', '내부', '영업·PM'],
      ['2', '잠금·복구·집계 실측 관문(G_ROLE→G_PRESERVE→G_BLOCK→G_AGG→G_RECOVER→G_POST→G_HANDOFF) · timeTrackingProvider 비UI 경로 · 삭제 이벤트 행위자·H4', '내부 기술 검토', '어프로벌'],
      ['3', '정산 완전성 검증 — 합의 인원·건수에서 프로퍼티 잘림·300명·1,000건 상한 · legacySeconds 정책(인증 필수 모드 여부)', '내부', '양쪽'],
      ['4', '워크포스 RFC-220 master 병합·미커밋 정리 · rms.org 명부·rms.check 게시 · prd 서명 키·교체 절차 · 통제 알림(Q130)', '내부 구현', '양쪽'],
      ['5', 'Tempo 전환·이관 범위 합의(기준선 수집·과거 기간 인증·원가 대사·복귀) · 승인 단위·반려 흐름·재개방 권한자', '고객 확인', '영업'],
      ['6', 'SAP 데이터 항목·방식·호출 계정 확정 · 3LO 호출자 신원 실측 · 1차 xlsx 수동 추출', '고객 + 내부', '워크포스'],
      ['7', 'Jira 그룹·역할 동기화 실측 · 퇴사 = 비활성 설계 · 엑셀 양식 정의', '내부 + 고객', '워크포스'],
      ['8', '이력 용량 산정(인원×건수×보존) · 보존·내보내기·제거 전 해제 운영 절차 · 프로퍼티별 노출 필드 표 · 레지던시(리전·PINNED)', '내부 + 고객', '어프로벌'],
      ['9', '개인정보 보존 정책 법무·Marketplace 확인(Q138)', '내부', '디무브'],
      ['10', '6-1~6-5 범위 구체화(OKR·Outlook 범위 밖 권고, 알림 채널 확인)', '고객 확인', '영업'],
    ];
    table(s, rows, M, TOP + 0.1, CW, [0.5, 8.9, 1.5, CW - 10.9], { size: 9.5, headSize: 10, rowH: [0.32, 0.38, 0.55, 0.5, 0.5, 0.5, 0.38, 0.38, 0.5, 0.38, 0.38], boldFirstCol: true });
  }

  // 29. 고객 회신 초안
  {
    const s = content('06', '수용 기준과 후속 · 고객 회신 초안', '고객에게 보낼 한 단락', '과장·누락 없이, 제공하는 것과 조건을 같은 문단에 둡니다.');
    rect(s, M, TOP + 0.1, CW, 2.75, T[900]);
    txt(s, '워크로그 승인·기간 잠금·변경 이력은 Moves Workforce 와 함께 설치하는 Moves Approval 앱이 제공합니다. 월 단위 제출 → 팀장 승인(팀 일괄 승인 포함)과 승인자·일시·대상 기간 기록, 수집 시작 이후의 워크로그 생성·수정·삭제 이력이 포함됩니다. 승인된 기간의 기존 워크로그 수정·삭제는 앱이 차단하고(사이트별 검증 후 활성화), 다른 경로로 새로 입력된 건은 이벤트 기반으로 감지해 표시하고 재승인을 요구합니다 — Jira 플랫폼 제약상 새 입력의 사전 차단은 불가합니다. 이 앱을 시간 추적 제공자로 지정하면 Tempo 를 제공자로 함께 선택할 수 없으므로 전환 시점과 데이터 이관 범위를 함께 정해야 합니다. 두 기능은 Atlassian Preview 모듈에 의존합니다. SAP 연동은 1차로 월 1회 엑셀 추출, 2차로 Atlassian OAuth 기반 JSON REST API(Preview)를 제공하며 OData 는 범위에 포함되지 않습니다.', M + 0.4, TOP + 0.3, CW - 0.8, 2.4, { size: 12.5, color: WHITE, lh: 1.45 });
    const cols = [
      ['FaCheck', '말하는 것', ['월 제출 → 팀장 승인 · 일괄 승인', '승인자·일시·기간 기록', '수집 이후 생성·수정·삭제 이력', '승인된 기존 건 수정·삭제 차단(검증 후)']],
      ['FaExclamationTriangle', '조건으로 말하는 것', ['사이트별 실측 관문 통과 후 활성화', 'Preview 모듈 2건 의존', 'Tempo 와 제공자 동시 선택 불가', '전환 시점·이관 범위 합의']],
      ['FaTimes', '말하지 않는 것', ['"즉시 감지" · "승인 순간부터 수정 불가"', '"다른 경로 입력은 정산 제외"', '"모든 변경의 완전한 감사 로그"', '"OData 제공" · "Atlassian 조직 동기화"']],
    ];
    const cw = (CW - 0.6) / 3;
    for (let i = 0; i < 3; i++) {
      const [ic, t, body] = cols[i];
      await card(s, M + i * (cw + 0.3), TOP + 3.05, cw, 1.6, { title: t, body: body.map((b) => '· ' + b), titleSize: 11.5, bodySize: 9.5 });
    }
  }

  // 30. 부록 공식 문서
  {
    const s = content('A', '부록 · 공식 문서 근거', '판정의 근거가 된 Atlassian 공식 문서', '2026-10-13 URL 응답 확인. "문서" 등급 근거는 실측 전이며 계약 전 해당 항목을 재확인합니다.');
    const L = (t, u) => ({ text: t, url: u, color: BLUE });
    const rows = [
      ['주제', '문서', '우리 문서에서의 쓰임'],
      ['SAP · apiRoute', L('Forge app REST APIs (Preview)', 'https://developer.atlassian.com/platform/forge/app-rest-apis/'), '관리자 활성화 필수 · Runs on Atlassian 적격'],
      ['', L('API route 모듈 · Expose Forge app REST APIs', 'https://developer.atlassian.com/platform/forge/manifest-reference/modules/api-route/'), 'path·operation·scopes 계약 · custom-scopes 등록 절차'],
      ['', L('Access REST APIs exposed by a Forge app', 'https://developer.atlassian.com/platform/forge/access-rest-apis-exposed-by-a-forge-app/'), '호출 측 절차 · 조직 구성원 누구나 연동 생성'],
      ['', L('OAuth 2.0 (3LO) apps', 'https://developer.atlassian.com/cloud/jira/platform/oauth-2-3lo-apps/'), 'SAP 측 토큰 교환·refresh 회전 책임'],
      ['', L('Web trigger 모듈 (static/dynamic)', 'https://developer.atlassian.com/platform/forge/manifest-reference/modules/web-trigger/'), 'static 은 고정 응답 · dynamic 은 배지 실격'],
      ['잠금', L('jira:timeTrackingProvider (Preview)', 'https://developer.atlassian.com/platform/forge/manifest-reference/modules/jira-time-tracking-provider/'), 'Jira 기본 Log work 숨김 · 사이트당 하나'],
      ['', L('Issue worklogs REST (visibility 조건)', 'https://developer.atlassian.com/cloud/jira/platform/rest/v3/api-group-issue-worklogs/'), 'visibility 가 걸린 워크로그의 PUT/DELETE 권한 조건'],
      ['', L('Product events · Async events API', 'https://developer.atlassian.com/platform/forge/events-reference/product_events/'), '워크로그 이벤트 3종 · 비동기 사후 감지'],
      ['', L('Pre-uninstall trigger', 'https://developer.atlassian.com/platform/forge/manifest-reference/modules/pre-uninstall-trigger/'), '55초 · 실패해도 제거 진행'],
      ['데이터', L('Forge SQL', 'https://developer.atlassian.com/platform/forge/storage-reference/sql/'), '환경별 한도(prod 1GiB · stg 256MiB · dev 128MiB)'],
      ['', L('Hosted storage data lifecycle', 'https://developer.atlassian.com/platform/forge/storage-reference/hosted-storage-data-lifecycle/'), '제거 후 soft delete → 영구 삭제 · 레지던시'],
      ['', L('Jira entity properties', 'https://developer.atlassian.com/cloud/jira/platform/jira-entity-properties/'), '편집 권한자 누구나 쓸 수 있음 · 32KB'],
      ['', L('User privacy guidelines · report:personal-data', 'https://developer.atlassian.com/platform/forge/user-privacy-guidelines/'), '계정 삭제 보고 주기 · 개인정보 처리'],
      ['조직', L('Teams REST API', 'https://developer.atlassian.com/platform/teams/rest/v1/'), 'Forge/OAuth2 접근 불가 → 범위 밖'],
      ['배지', L('Build Runs on Atlassian apps', 'https://developer.atlassian.com/platform/forge/runs-on-atlassian-apps/'), 'remotes·dynamic webtrigger 실격 · apiRoute 적격'],
    ];
    table(s, rows, M, TOP + 0.1, CW, [1.2, 5.2, CW - 6.4], { size: 9, headSize: 9.5, rowH: 0.29, boldFirstCol: true });
  }

  // 31. 마무리
  {
    const s = pres.addSlide(); s.background = { color: T[900] };
    rect(s, 0, 0, 0.28, H, T[500]);
    txt(s, '워크포스 + 어프로벌, 두 앱으로', M + 0.25, 1.6, 11, 0.8, { size: 36, bold: true, color: WHITE });
    txt(s, '락킹·승인·이력은 코드가 준비돼 있습니다. 실측과 연동을 끝내고 수용 기준 8항으로 약속합니다.', M + 0.25, 2.5, 11.8, 0.8, { size: 18, color: T[100], lh: 1.35 });
    txt(s, 'NEXT STEP', M + 0.25, 3.7, 4, 0.3, { size: 11, color: T[300], bold: true, spacing: 3 });
    points(s, [
      ['1. 약속 문구 수정', '제안서·회신에 수용 기준 8항 반영'],
      ['2. 개발 사이트 실측', 'G_ROLE → G_PRESERVE → G_BLOCK → G_AGG → G_RECOVER, timeTrackingProvider 비UI 경로'],
      ['3. 연동 마무리', 'RFC-220 병합 · 명부/제한선 게시 · 운영 서명 키'],
      ['4. 고객 확인', 'Tempo 전환 시점·이관 범위 · SAP 필드 · 인원·보존 기간'],
    ], M + 0.25, 4.1, 11.5, 0.6, { dark: true, titleSize: 13, size: 10.5 });
    s.addImage({ path: ASSET('dmove_wordmark_white.png'), x: M + 0.25, y: 6.72, w: 1.3, h: 0.3 });
    txt(s, '내부 검토 · 2026-10-13', 9.5, 6.72, 3.35, 0.3, { size: 10, color: T[300], align: 'right', valign: 'middle', spacing: 2 });
    slides.push({ s, kind: 'cover' });
  }

  // 푸터·페이지 번호
  const total = slides.length;
  slides.forEach((o, i) => {
    if (o.kind !== 'content') return;
    o.s.addImage({ path: ASSET('dmove_wordmark_teal.png'), x: M, y: 7.02, w: 0.95, h: 0.22 });
    txt(o.s, '스트라드비전 요구사항 대응  ·  Workforce + Approval', M + 1.1, 7.0, 6, 0.26, { size: 8.5, color: MUTED, valign: 'middle' });
    txt(o.s, `${String(i + 1).padStart(2, '0')} / ${total}`, W - M - 1.5, 7.0, 1.5, 0.26, { size: 8.5, color: MUTED, align: 'right', valign: 'middle' });
  });

  await pres.writeFile({ fileName: OUT });
  console.log('written:', OUT, 'slides:', total);
}

build().catch((e) => { console.error(e); process.exit(1); });
