/* 스트라드비전 대응 문서용 다이어그램 — SVG 를 손으로 그리고 sharp 로 PNG(2x) 렌더링 */
const fs = require('fs');
const path = require('path');
const sharp = require('sharp');

const OUT = process.argv[2] || path.resolve('C:/CloudJira/moves-approval-jira/_workspace/stradvision-2026-10-13/images');
if (!fs.existsSync(OUT)) fs.mkdirSync(OUT, { recursive: true });

const T = { 900: '#103F3A', 700: '#14756E', 600: '#1A9A90', 500: '#21ADAD', 300: '#6FD3C6', 100: '#C9ECE6', 50: '#E9F7F4' };
const INK = '#10201E', GRAY = '#55625F', MUTED = '#8A9896', LINE = '#D9E4E2', BG = '#F4F8F7', WHITE = '#FFFFFF';
const AMBER = '#E39B2C', RED = '#D64545', GREEN = '#2E9E6B', BLUE = '#2F6FDE', AMBER_BG = '#FDF3E3', RED_BG = '#FBE9E9', BLUE_BG = '#EAF0FC', GREEN_BG = '#E6F4EC';
const FONT = "'Noto Sans KR','Malgun Gothic',sans-serif";

const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

class Svg {
  constructor(w, h, title) { this.w = w; this.h = h; this.parts = []; this.title = title; }
  add(s) { this.parts.push(s); return this; }
  text(x, y, s, o = {}) {
    const lines = Array.isArray(s) ? s : [s];
    const lh = o.lh || (o.size || 13) * 1.4;
    const t = lines.map((l, i) => `<tspan x="${x}" dy="${i === 0 ? 0 : lh}">${esc(l)}</tspan>`).join('');
    return this.add(`<text x="${x}" y="${y}" font-family="${FONT}" font-size="${o.size || 13}" font-weight="${o.bold ? 600 : 400}" fill="${o.color || INK}" text-anchor="${o.anchor || 'start'}"${o.italic ? ' font-style="italic"' : ''}>${t}</text>`);
  }
  rect(x, y, w, h, o = {}) {
    return this.add(`<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${o.r ?? 8}" fill="${o.fill || WHITE}" stroke="${o.stroke || LINE}" stroke-width="${o.sw ?? 1.2}"${o.dash ? ` stroke-dasharray="${o.dash}"` : ''}/>`);
  }
  // 박스: 제목 + 본문 줄
  box(x, y, w, h, title, lines = [], o = {}) {
    this.rect(x, y, w, h, { fill: o.fill || WHITE, stroke: o.stroke || LINE, sw: o.sw ?? 1.2, dash: o.dash, r: o.r });
    if (o.badge) {
      this.rect(x + w - 10 - o.badge.length * 7.5 - 14, y + 10, o.badge.length * 7.5 + 14, 20, { fill: o.badgeBg || T[50], stroke: o.badgeBg || T[50], r: 10 });
      this.text(x + w - 10 - (o.badge.length * 7.5 + 14) / 2, y + 24, o.badge, { size: 10.5, bold: true, color: o.badgeFg || T[700], anchor: 'middle' });
    }
    const cx = o.center ? x + w / 2 : x + 16;
    const anchor = o.center ? 'middle' : 'start';
    if (title) this.text(cx, y + 26, title, { size: o.titleSize || 14, bold: true, color: o.titleColor || INK, anchor });
    if (lines.length) this.text(cx, y + (title ? 48 : 24), lines, { size: o.size || 11.5, color: o.color || GRAY, anchor, lh: (o.size || 11.5) * 1.5 });
    return this;
  }
  group(x, y, w, h, label, o = {}) {
    this.rect(x, y, w, h, { fill: o.fill || BG, stroke: o.stroke || T[300], sw: 1.2, dash: o.dash ?? '6 4', r: 12 });
    if (label) this.text(x + 16, y + 24, label, { size: 12.5, bold: true, color: o.labelColor || T[700] });
    return this;
  }
  // 화살표(폴리라인). pts: [[x,y],...]
  arrow(pts, o = {}) {
    const d = pts.map((p, i) => (i ? 'L' : 'M') + p[0] + ' ' + p[1]).join(' ');
    const color = o.color || T[600];
    const id = 'm' + Math.random().toString(36).slice(2, 8);
    this.add(`<defs><marker id="${id}" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0L10 5L0 10z" fill="${color}"/></marker></defs>`);
    this.add(`<path d="${d}" fill="none" stroke="${color}" stroke-width="${o.sw || 1.6}"${o.dash ? ` stroke-dasharray="${o.dash}"` : ''} marker-end="url(#${id})"${o.start ? ` marker-start="url(#${id})"` : ''}/>`);
    if (o.label) {
      const [lx, ly] = o.at || pts[Math.floor(pts.length / 2)];
      const w = o.label.length * 6.6 + 12;
      this.rect(lx - w / 2, ly - 10, w, 20, { fill: o.labelBg || WHITE, stroke: o.labelBg || WHITE, r: 4 });
      this.text(lx, ly + 4, o.label, { size: 10.5, color: o.labelColor || GRAY, anchor: 'middle' });
    }
    return this;
  }
  pill(x, y, text, o = {}) {
    const w = text.length * (o.size || 10.5) * 0.72 + 18;
    this.rect(x, y, w, 22, { fill: o.bg || T[50], stroke: o.bg || T[50], r: 11 });
    this.text(x + w / 2, y + 15, text, { size: o.size || 10.5, bold: true, color: o.fg || T[700], anchor: 'middle' });
    return w;
  }
  diamond(cx, cy, w, h, lines, o = {}) {
    this.add(`<polygon points="${cx - w / 2},${cy} ${cx},${cy - h / 2} ${cx + w / 2},${cy} ${cx},${cy + h / 2}" fill="${o.fill || AMBER_BG}" stroke="${o.stroke || AMBER}" stroke-width="1.4"/>`);
    const arr = Array.isArray(lines) ? lines : [lines];
    this.text(cx, cy + 4 - (arr.length - 1) * 8, arr, { size: 11.5, bold: true, color: INK, anchor: 'middle', lh: 16 });
    return this;
  }
  toString() {
    return `<svg xmlns="http://www.w3.org/2000/svg" width="${this.w}" height="${this.h}" viewBox="0 0 ${this.w} ${this.h}"><rect width="${this.w}" height="${this.h}" fill="${WHITE}"/>` +
      (this.title ? `<text x="28" y="34" font-family="${FONT}" font-size="17" font-weight="600" fill="${INK}">${esc(this.title)}</text>` : '') + this.parts.join('') + '</svg>';
  }
}

const outputs = [];
async function emit(name, svg) {
  const s = svg.toString();
  fs.writeFileSync(path.join(OUT, name + '.svg'), s, 'utf8');
  await sharp(Buffer.from(s), { density: 192 }).png().toFile(path.join(OUT, name + '.png'));
  outputs.push(name);
}


// ───────────── 0. 전체 시스템 아키텍처(계층) ─────────────
function systemArch() {
  const v = new Svg(1200, 900, '전체 시스템 아키텍처 — 사용자 브라우저부터 저장소·외부 시스템까지 (두 앱 모두 Forge 안에서 실행)');
  // 1 클라이언트
  v.group(40, 60, 1120, 130, '① 사용자 브라우저 — Jira 화면 안의 Forge UI (iframe, Custom UI/CRA 멀티 엔트리, Atlaskit)');
  const ui = [
    ['어프로벌', 'globalPage 업무함 · adminPage 설정 · projectSettingsPage', 'issueAction Log work · issueActivity 작업 로그 탭 · issuePanel/issueContext 승인'],
    ['워크포스', 'globalPage(My Work·프로젝트·자원·대시보드·백오피스)', 'issueActivity/issueContext 워크로그 탭 · customField 6'],
    ['외부', 'SAP 배치(월 1회) → OAuth 2.0 3LO 토큰', 'Jira 모바일 · Automation · REST(API 토큰) = 다른 경로'],
  ];
  ui.forEach((u, i) => v.box(60 + i * 370, 95, 350, 80, u[0], [u[1], u[2]], { size: 10.5, fill: i === 2 ? AMBER_BG : WHITE, stroke: i === 2 ? AMBER : LINE }));
  // 2 Forge 플랫폼
  v.group(40, 215, 1120, 330, '② Atlassian Forge 플랫폼 — 함수 실행(25초/큐 900초) · 샌드박스 · 스코프 · 라이선스');
  v.box(60, 250, 540, 280, '어프로벌 앱 함수', [
    'resolver — guardedDefine + PermissionMap(deny-by-default) + PrincipalResolver',
    'trigger — worklog-changed(생성/수정/삭제) · issue-changed · on-install · preUninstall',
    'workflowValidator(함수형) — 상태 변경 승인 강제',
    'scheduledTrigger approval-sweep(일 1회) → consumer sweep-job(큐 fan-out)',
    'timeTrackingProvider — Jira 기본 Log work 숨김 · 우리 UI 로 대체',
    'queue — 인증 게시(45초 디바운스) · 통제 적용/해제 워커',
    '도메인(순수) — 상태 머신 · 기간 키 · 지문 · 제한선 · 통제 규칙/관문',
  ], { fill: T[50], stroke: T[500], size: 10.5 });
  v.box(620, 250, 520, 280, '워크포스 앱 함수', [
    'resolver — guardedDefine + PermissionMap + ResourceCatalog(권한 세트×리소스)',
    'scheduledTrigger 4 — 마이그레이션 · 포트폴리오 스냅샷 · 구독 스윕 · 삭제 스윕',
    'consumer/큐 6 — 사용자 일괄 등록 · 집계 · 구독 편입',
    'trigger — 설치/업그레이드 · avi:jira:created:issue',
    'integration/approval — 인증 문서 읽기 · 공개키 검증 · 출처 서명 · 능력 신호',
    'core:apiRoute(계획) — 별개 진입점, 가드 직접 구현',
    '도메인 — MD/MM 환산 · 가동률 · 진척 · 원가(인증분 적용)',
  ], { size: 10.5 });
  // 3 저장소
  v.group(40, 570, 560, 150, '③ 앱 저장소 (Atlassian 호스티드 · 설치당 분리 · 앱 간 공유 불가)');
  v.box(60, 605, 255, 100, '어프로벌 Forge SQL', ['결재·타임시트·인증·이력·통제·감사', 'DDL 29종 · 마이그레이션 v063', '한도 prod 1GiB'], { fill: T[50], stroke: T[500], size: 10 });
  v.box(330, 605, 255, 100, '워크포스 Forge SQL + KVS', ['users·projectusers·project_team(SQL)', 'team·role·holiday·settings(KVS)', '환경 변수: 서명 키(암호화)'], { size: 10 });
  // 4 Jira
  v.group(620, 570, 540, 150, '④ Jira Cloud 데이터 · REST API v3 (asUser 기본 · asApp 은 사유 명시)');
  v.box(640, 605, 245, 100, '원본 데이터', ['워크로그 · 이슈 · 프로젝트 · 사용자', '권한 스킴 · 프로젝트 역할', '워크로그 visibility(역할 제한)'], { size: 10 });
  v.box(900, 605, 240, 100, '엔티티 프로퍼티 (교환 채널)', ['사용자·이슈·프로젝트 프로퍼티', 'Ed25519 서명 문서 · 32KB/건', '서명 검증 후에만 신뢰'], { fill: BG, size: 10 });
  // 5 외부
  v.group(40, 745, 1120, 130, '⑤ 테넌트 밖 (앱이 외부 서버로 보내는 경로 없음 → Runs on Atlassian 배지 유지)');
  v.box(60, 780, 350, 80, 'SAP', ['api.atlassian.com 게이트웨이 → 워크포스 apiRoute(JSON)', '또는 xlsx 수동 전달(1차)'], { size: 10.5, fill: BG });
  v.box(430, 780, 350, 80, '고객 다운로드 파일', ['xlsx(워크로그·감사 내보내기) · PDF(증명서)', '보관 책임 고객 · 복원 Import 없음'], { size: 10.5, fill: BG });
  v.box(800, 780, 340, 80, '없음(범위 밖)', ['메일/Slack/Teams 직접 발송 · 외부 공휴일 API · Outlook', '→ egress 추가 = 배지 상실 · 별도 결정'], { size: 10.5, fill: RED_BG, stroke: RED });
  // 화살표
  v.arrow([[235, 175], [235, 250]], { label: 'invoke(resolver)', at: [300, 215] });
  v.arrow([[605, 175], [700, 250]], { label: 'invoke', at: [690, 215] });
  v.arrow([[975, 175], [975, 250]], { label: 'REST·이벤트 (다른 경로)', at: [1055, 215], color: AMBER });
  v.arrow([[200, 530], [200, 605]], { label: 'SQL', at: [230, 570] });
  v.arrow([[450, 530], [450, 605]], { label: 'SQL·KVS', at: [490, 570] });
  v.arrow([[400, 530], [400, 560], [760, 560], [760, 605]], { label: 'asUser/asApp 읽기·쓰기 · 이벤트 수신', at: [640, 560] });
  v.arrow([[1010, 530], [1010, 605]], { label: '프로퍼티 게시·읽기', at: [1075, 570] });
  v.arrow([[330, 530], [330, 560], [20, 560], [20, 820], [60, 820]], { color: MUTED, dash: '5 4', label: 'apiRoute/xlsx', at: [120, 740] });
  return v;
}

// ───────────── 1. 전체 아키텍처 ─────────────
function archDiagram() {
  const v = new Svg(1200, 720, '두 앱은 Jira 엔티티 프로퍼티로만 대화하고, 잠금·승인·이력은 어프로벌이 쥔다');
  // 사용자
  v.box(40, 70, 520, 70, '작성자 · 팀장 · 관리자', ['Jira 이슈 화면(Log work 대체 UI) · 워크포스 워크로그 탭 · 승인 업무함 · 설정'], { fill: BG });
  v.box(900, 70, 260, 70, 'SAP (외부)', ['월 1회 · Atlassian OAuth 2.0 3LO(계획)'], { fill: BG });
  // 두 앱
  v.box(40, 190, 540, 250, '어프로벌 앱  moves-approval-jira', [
    '타임시트 제출 → 팀장 1단계 승인 · 팀 일괄 승인(50건/PIN 1회)',
    '기간 잠금 · 워크로그 통제(수정·삭제 판정 후 asApp 실행) · 인증(RFC-220)',
    '워크로그 변경 이력 · 결재/인증/통제/설정 감사 · 증명서 PDF',
    'jira:timeTrackingProvider 로 Jira 기본 Log work 를 우리 화면으로 대체',
    '저장소: Forge SQL(운영 1GiB) · 마이그레이션 v063',
  ], { fill: T[50], stroke: T[500], sw: 2, badge: '잠금·승인·이력', badgeBg: T[700], badgeFg: WHITE });
  v.box(620, 190, 540, 250, '워크포스 앱  moves-workforce', [
    '팀 · 팀장 · 프로젝트 인력 배정 · 계획 · 가동률 · 간트',
    '원가·정산: 인증 문서 범위에 인증 시간 적용(없는 범위는 기존 계산)',
    '현황은 전부 표시 + 주장/인증 배지',
    '외부 API(core:apiRoute, 계획) · 엑셀 사용자 업로드 · 워크로그 xlsx 추출',
    '저장소: Forge SQL + KVS · 연동으로 새 테이블 없음(DB 무증가)',
  ], { badge: '인력·계획·원가·API' });
  // Jira
  v.group(40, 500, 1120, 190, 'Jira Cloud (고객 테넌트)');
  v.box(60, 540, 330, 130, '워크로그 원본', ['시간·일자·이슈·설명. 앱을 지워도 남는다', '권한 스킴: Work on work items'], { size: 11 });
  v.box(410, 540, 400, 130, '엔티티 프로퍼티 = 앱 간 유일한 교환 채널', ['사용자: movesApproval.{YYYY} · .cert.{YYYY-MM} · movesRms.org', '이슈·프로젝트: movesApproval.ctl · rms.policy', 'Ed25519 서명 — 위조 방지(기밀성 아님), cloudId·엔티티 id 포함'], { size: 11 });
  v.box(830, 540, 310, 130, '이벤트 · 권한', ['avi:jira:{created,updated,deleted}:worklog', 'avi:jira:updated:issue · 설치/제거 트리거', '워크로그 visibility(역할 제한)'], { size: 11 });
  // 화살표
  v.arrow([[200, 140], [200, 190]], { label: '제출·승인·입력', at: [280, 165] });
  v.arrow([[480, 140], [480, 190]]);
  v.arrow([[760, 140], [760, 190]], { label: '워크로그 탭·팀 설정', at: [860, 165] });
  v.arrow([[1030, 140], [1030, 190]], { label: '3LO 토큰', at: [1090, 165], dash: '5 4' });
  v.arrow([[250, 440], [250, 540]], { label: '서명 인증 문서 게시 · visibility 숨김', at: [250, 490] });
  v.arrow([[560, 540], [560, 440]], { label: '이벤트 구독 · asUser/asApp 읽기', at: [560, 470] });
  v.arrow([[700, 440], [700, 540]], { label: '공개키 검증 후 읽기', at: [700, 490] });
  v.arrow([[960, 540], [960, 440]], { label: '출처 서명 · 능력 신호 게시', at: [960, 470] });
  v.arrow([[580, 300], [620, 300]], { start: true, color: RED, dash: '3 3' });
  v.text(600, 330, '직접 호출 불가', { size: 10, color: RED, anchor: 'middle' });
  return v;
}

// ───────────── 2. 잠금 4층 플로우차트 ─────────────
function lockFlow() {
  const v = new Svg(1200, 760, '워크로그 쓰기는 들어오는 경로마다 다른 층이 막고, 막지 못하는 것은 감지한다');
  v.box(460, 60, 280, 56, '워크로그 생성 · 수정 · 삭제 시도', [], { fill: T[50], stroke: T[500], center: true });
  v.diamond(600, 180, 300, 70, ['어느 경로로 들어왔나?']);
  v.arrow([[600, 116], [600, 145]]);
  // 세 경로
  const cols = [
    { x: 40, title: '① 우리 화면', sub: '어프로벌 Log work · 워크포스 탭', color: T[700] },
    { x: 440, title: '② Jira 화면', sub: 'Jira 기본 Log work (제공자 지정 후 숨김)', color: T[700] },
    { x: 840, title: '③ REST · 자동화 · 모바일', sub: 'API 토큰 · Automation · 모바일 앱', color: AMBER },
  ];
  cols.forEach((c, i) => {
    const cx = c.x + 160;
    v.arrow([[600, 215], [cx, 250]]);
    v.box(c.x, 250, 320, 60, c.title, [c.sub], { fill: BG, center: true, size: 11 });
  });
  // 층
  v.box(40, 340, 320, 110, '2층 · 서버 판정(쓰기 직전)', ['PERIOD_CLOSED / SUBMITTED / APPROVED', '인증 잠금 · 기간 창 · 정책 → 거부', '작성은 asUser(작성자 보존)'], { size: 11 });
  v.box(40, 480, 320, 70, '4층 · 확정분은 앱이 asApp 으로 실행', ['숨긴 워크로그의 수정·삭제만 앱 계정'], { size: 11 });
  v.arrow([[200, 310], [200, 340]]);
  v.arrow([[200, 450], [200, 480]]);
  v.box(40, 590, 320, 80, '결과 · 거부 또는 실행', ['마감·승인 기간 입력은 서버가 거부', '통과한 쓰기는 이력에 APP 출처로 기록'], { fill: GREEN_BG, stroke: GREEN, size: 11 });
  v.arrow([[200, 550], [200, 590]]);

  v.box(440, 340, 320, 110, '2층 · jira:timeTrackingProvider', ['관리자가 제공자로 지정 → Jira 기본', 'Log work 버튼·작업 로그 탭 숨김', '→ 우리 화면(①)으로 유도'], { size: 11 });
  v.box(440, 480, 320, 70, '4층 · visibility 숨김(Phase B)', ['승인·인증된 건은 역할 제한 → 사람은 수정·삭제 불가'], { size: 11 });
  v.arrow([[600, 310], [600, 340]]);
  v.arrow([[600, 450], [600, 480]]);
  v.box(440, 590, 320, 80, '결과 · 화면 차단 + 확정분 보호', ['신규 입력은 ① 로, 확정분은 손댈 수 없음', 'Tempo 와 제공자 동시 선택 불가'], { fill: GREEN_BG, stroke: GREEN, size: 11 });
  v.arrow([[600, 550], [600, 590]]);

  v.box(840, 340, 320, 110, '4층 · visibility 숨김(Phase B)', ['확정분(APPROVED·CERTIFIED/MISMATCH)은', 'API 토큰 REST 로도 PUT/DELETE 불가', '(G_BLOCK 실측 관문)'], { size: 11 });
  v.box(840, 480, 320, 70, '3층 · 이벤트 감지 + 일일 스윕', ['새 입력·미승인 기록 변경은 사전 차단 불가'], { fill: AMBER_BG, stroke: AMBER, size: 11 });
  v.arrow([[1000, 310], [1000, 340]]);
  v.arrow([[1000, 450], [1000, 480]]);
  v.box(840, 590, 320, 80, '결과 · FLAG 표시 · 재승인 요구', ['비동기 사후 감지(수 초~수 분, 누락 시 하루)', '인증자가 판단 · 자동 삭제는 쓰지 않음'], { fill: AMBER_BG, stroke: AMBER, size: 11 });
  v.arrow([[1000, 550], [1000, 590]]);
  // 1층
  v.group(40, 690, 1120, 50, '', { fill: T[50], dash: '' });
  v.text(60, 721, '1층 · 누가 쓰나 — Jira 권한 스킴 "Work on work items" 를 프로젝트 역할에만 부여(고객 관리자 작업, 모든 경로에 적용, 기간 조건 없음)', { size: 11.5, color: T[900], bold: true });
  return v;
}

// ───────────── 3. 타임시트 승인 흐름 ─────────────
function approvalFlow() {
  const v = new Svg(1200, 620, '사용자×월 단위로 제출하고 팀장이 결재한다 — 결정이 진실, 상태는 파생');
  v.box(40, 70, 230, 90, '1. 기간 워크로그', ['periodKey = 2026-10 (정책 approvalUnit)', 'scopeKey TIMESHEET:{accountId}:{period}'], { fill: BG, size: 10.5 });
  v.box(320, 70, 230, 90, '2. 제출(SUBMITTED)', ['워크로그 묶음 스냅샷 고정', 'id·초·시작일·이슈 → contentHash'], { size: 10.5 });
  v.box(600, 70, 230, 90, '3. 팀장 결재(PENDING)', ['팀 × 기간 매트릭스', 'decideTimesheets 최대 50건 · PIN 1회'], { size: 10.5 });
  v.box(880, 70, 280, 90, '4. APPROVED', ['approval_approver 행 = 결정의 원천', 'approval_event(결정적 id) · 서명/PIN · 증명서'], { fill: GREEN_BG, stroke: GREEN, size: 10.5 });
  v.arrow([[270, 115], [320, 115]]);
  v.arrow([[550, 115], [600, 115]]);
  v.arrow([[830, 115], [880, 115]], { label: '승인', at: [855, 95] });
  // 반려
  v.box(600, 220, 230, 70, 'REJECTED', ['반려 사유 → 작성자 알림 → 재제출'], { fill: RED_BG, stroke: RED, size: 10.5 });
  v.arrow([[715, 160], [715, 220]], { label: '반려', at: [760, 190] });
  v.arrow([[600, 255], [435, 255], [435, 160]], { color: MUTED, dash: '4 3' });
  // 승인 후 변경
  v.box(880, 220, 280, 90, '승인 후 워크로그 변경 감지', ['이벤트 → 스냅샷 hash 불일치', '→ CHANGED_AFTER_APPROVAL (drift_detected_at)', '요청은 APPROVED 유지 + 재제출 요구'], { fill: AMBER_BG, stroke: AMBER, size: 10.5 });
  v.arrow([[1020, 160], [1020, 220]], { label: '워크로그 이벤트', at: [1095, 190] });
  v.arrow([[880, 290], [435, 290], [435, 160]], { color: AMBER, dash: '4 3', label: '재제출', at: [660, 290] });
  // 결재 중 변경
  v.box(320, 220, 230, 70, 'EXPIRED(CONTENT_CHANGED)', ['결재 대기 중 워크로그가 바뀌면 만료'], { fill: AMBER_BG, stroke: AMBER, size: 10.5 });
  v.arrow([[435, 160], [435, 220]], { color: AMBER });
  // 마감
  v.group(40, 360, 1120, 220, '기간 마감 · 재개방 (관리자)');
  v.box(60, 400, 330, 150, 'closePeriod → CLOSED', ['우리 화면 입력 거부(PERIOD_CLOSED)', '자동 마감 timesheetAutoCloseDays(기본 꺼짐)', '마감 후 다른 경로 변경은 timesheet_close_drift 표시'], { size: 10.5 });
  v.box(420, 400, 340, 150, 'reopenPeriod · 두 단계', ['(a) 새 입력 허용 — 마감 잠금만 해제', '(b) 수정까지 허용 — 승인·인증 해제 + 숨김 해제', '    + 재승인·재인증 필요, 사유 필수, 감사 기록'], { size: 10.5 });
  v.box(790, 400, 350, 150, '결재 공통 기능(Confluence 판 이식)', ['위임 · 참조(CC) · 결재 그룹 · 독촉(기본 OFF)', '서명/PIN · 앱 내 알림함 · 업무함 범용 bulkApprove', '증명서 PDF(getApprovalCertificate)'], { fill: BG, size: 10.5 });
  v.arrow([[390, 475], [420, 475]]);
  return v;
}

// ───────────── 4. 인증 모델 ─────────────
function certFlow() {
  const v = new Svg(1200, 560, '인증된 시간의 원본은 어프로벌 DB — Jira 에서 바뀌어도 인증값은 바뀌지 않는다');
  v.box(40, 80, 250, 110, '팀장 인증(certifyWorklogs)', ['상위자 인증 원칙 · PIN 묶음당 1회', '상위자 없는 팀장만 본인 인증(self_certified)', '팀원 본인 인증 거부'], { size: 10.5 });
  v.box(340, 80, 250, 110, 'worklog_cert (현재 인증본)', ['이슈·작성자·시작·초 → 지문 고정', 'worklog_cert_batch(누가·누구·월·PIN)', 'worklog_cert_log(재인증 전 판 보관)'], { fill: T[50], stroke: T[500], size: 10.5 });
  v.box(640, 80, 250, 110, '게시 큐 (45초 디바운스)', ['인증 직후 이벤트 기반 게시', '일일 스윕이 누락 보정', '인증 없는 날 비용 0'], { size: 10.5 });
  v.box(940, 80, 220, 110, '사용자 프로퍼티', ['movesApproval.cert.{YYYY-MM}', 'typ approval.cert v2', 'kid · iat · sig(Ed25519)'], { fill: BG, size: 10.5 });
  v.arrow([[290, 135], [340, 135]]);
  v.arrow([[590, 135], [640, 135]]);
  v.arrow([[890, 135], [940, 135]]);
  // 문서 내용
  v.box(40, 240, 540, 120, '문서 본문(30,000B 예산)', ['cs 인증 합계(원가의 단일 입력) · cn/mn/dn 건수 · sc/sn 본인 서명분', 'w [worklogId, 초, flag] 최대 1,000건 — 초과 시 잘림 wt=true', 'di 삭제된 건의 원래 이슈(원가 유지 옵션용)'], { size: 10.5 });
  v.arrow([[1050, 190], [1050, 240], [580, 300]], { color: T[300] });
  // 변경 후
  v.box(640, 240, 520, 120, 'Jira 에서 이후에 바뀌면', ['수정 → MISMATCH 표시(인증 시간 유지) · 삭제 → DELETED', 'deletedCertifiedHandling = KEEP(기본) | ZERO', '다른 경로 입력(FLAG)은 인증을 막지 않는다 — 인증자가 판단'], { fill: AMBER_BG, stroke: AMBER, size: 10.5 });
  // 워크포스
  v.group(40, 400, 1120, 140, '워크포스 (moves-workforce · RFC-220)');
  v.box(60, 440, 340, 80, 'asApp 읽기 → 공개키 검증(keyring)', ['서명 실패 = 문서 없음으로 처리 · 원문 미노출'], { size: 10.5 });
  v.box(430, 440, 340, 80, '원가 계산(certifyCostRows)', ['문서 있는 사용자×월: 인증 시간 적용', '문서 없는 범위: 기존 계산(legacySeconds)'], { size: 10.5 });
  v.box(800, 440, 340, 80, '화면', ['확정 원가(인증분) / 예상 원가(미인증 포함) 나란히', '현황은 전부 표시 + 주장/인증 배지'], { size: 10.5 });
  v.arrow([[400, 480], [430, 480]]);
  v.arrow([[770, 480], [800, 480]]);
  v.arrow([[1050, 190], [1150, 190], [1150, 410]], { color: T[300], dash: '5 4' });
  return v;
}

// ───────────── 5. 변경 이력 파이프라인 ─────────────
function historyFlow() {
  const v = new Svg(1200, 540, '워크로그 변경은 이벤트로 받아 미러·이력에 쌓고, 만료분은 내보낸 뒤에만 지운다');
  v.box(40, 80, 250, 100, '수집', ['avi:jira:created:worklog', 'avi:jira:updated:worklog', 'avi:jira:deleted:worklog'], { fill: BG, size: 10.5 });
  v.box(40, 210, 250, 90, '보정 (일일 스윕)', ['/rest/api/3/worklog/updated?since', '/rest/api/3/worklog/deleted?since', '놓친 이벤트 흡수'], { fill: BG, size: 10.5 });
  v.box(340, 80, 300, 220, 'worklog_mirror + worklog_history', ['미러: 마지막 관측값(CAS rev=rev+1)', '이력 PK (worklog_id, seq) 결정적 — 중복 없음', '생성·수정·삭제 전/후 값 · 행위자 · 출처(APP/JIRA/SWEEP)', '워크포스 연결 여부(wf_linked)', '설명은 지문 + 앞 40자(원문 보관 옵션)', '삭제 이벤트에 본문이 없어도 미러에서 복원'], { fill: T[50], stroke: T[500], size: 10.5 });
  v.arrow([[290, 130], [340, 130]]);
  v.arrow([[290, 255], [340, 255]]);
  v.box(690, 80, 230, 100, '감사 화면', ['설정 > 기록 > 감사', '결재·인증·워크로그 변경·설정 변경 탭', '엑셀 내보내기(관리자)'], { size: 10.5 });
  v.box(690, 210, 230, 90, '이슈 작업 로그 탭', ['한 줄 표 + 상세 모달', '변경 이력 탭 · 잠금/인증/통제 배지'], { size: 10.5 });
  v.arrow([[640, 130], [690, 130]]);
  v.arrow([[640, 255], [690, 255]]);
  v.box(970, 80, 190, 220, '보존 기간', ['일반 12개월', '워크포스 연결분 36개월', '결재 3년 · 인증 무기한', '통제 무기한', '(관리자 변경 가능)'], { fill: BG, size: 10.5 });
  // 라이프사이클
  v.group(40, 340, 1120, 170, '만료 처리 — 자동 삭제 없음 (Q132)');
  v.box(60, 380, 250, 100, 'exportExpiredRecords', ['만료 범위 엑셀 생성(25건 배치·20초 예산)'], { size: 10.5 });
  v.box(350, 380, 250, 100, 'confirmRecordExport', ['관리자가 파일 보관 확인 → 범위 확정'], { size: 10.5 });
  v.box(640, 380, 250, 100, 'purgeExportedRecords', ['확정 범위만 삭제 · remaining 0 까지 반복'], { size: 10.5 });
  v.box(930, 380, 210, 100, '예외', ['설정 변경 365일 · 알림 180일은', '스윕이 자동 정리'], { fill: AMBER_BG, stroke: AMBER, size: 10.5 });
  v.arrow([[310, 430], [350, 430]]);
  v.arrow([[600, 430], [640, 430]]);
  v.text(60, 500, '※ 내보내기는 기록 추출이지 복원 가능한 백업이 아니다. 라이선스 INACTIVE 면 내보내기도 막히므로 해지 전에 내려받는다.', { size: 10.5, color: RED });
  return v;
}

// ───────────── 6. SAP 연동 옵션 ─────────────
function sapFlow() {
  const v = new Svg(1200, 520, 'SAP 연동은 월 1회 — 1차 xlsx 수동 추출, 2차 core:apiRoute(JSON REST, Preview)');
  const cols = [
    { x: 40, title: '방식 C · 파일 전달 (지금 가능)', badge: '정식', bb: GREEN_BG, bf: GREEN, lines: ['워크포스 /worklog-export', '이슈키·작성자·accountId·started·초·시간·코멘트', 'Jira 로그인 사용자가 xlsx 내려받아 SAP 에 적재', '배포 영향 없음 · 배지 영향 없음'] },
    { x: 420, title: '방식 A · core:apiRoute (권장 2차)', badge: 'Preview', bb: AMBER_BG, bf: AMBER, lines: ['앱이 자체 REST 엔드포인트 선언 → 동적 JSON', 'Atlassian OAuth 2.0 3LO 토큰으로 호출', '관리자가 설치본 단위로 "앱 REST API" 켬', '모듈 사용만으로 메이저 버전(실측) · 배지 유지(실측)', '커스텀 스코프 환경당 20개 · 삭제 불가'] },
    { x: 800, title: '방식 B · static webtrigger', badge: '부적합', bb: RED_BG, bf: RED, lines: ['manifest 에 선언한 고정 응답만 반환', '함수 미실행 → 데이터 pull API 불가', '동적 응답은 dynamic → Runs on Atlassian 실격', '용도: SAP 가 "작업 완료" 를 알리는 수신 신호'] },
  ];
  cols.forEach((c) => v.box(c.x, 70, 360, 190, c.title, c.lines, { size: 10.5, badge: c.badge, badgeBg: c.bb, badgeFg: c.bf }));
  // apiRoute 호출 흐름
  v.group(40, 300, 1120, 200, '방식 A 호출 흐름과 책임 경계');
  v.box(60, 340, 200, 130, 'SAP / 중계 서비스', ['3LO 동의 → code → 토큰 교환', 'refresh token 회전(offline_access)', '만료·재인증 · 서비스 계정'], { fill: BG, size: 10 });
  v.box(310, 340, 230, 130, 'Atlassian 게이트웨이', ['api.atlassian.com/svc/jira/{cloudId}/apps/…', '토큰 없음·잘못된 토큰·미선언 경로 → 401', '우리 함수 실행 전에 차단(실측)'], { size: 10 });
  v.box(590, 340, 260, 130, '워크포스 apiRoute 핸들러', ['resolver 가드 전부 우회 → 직접 판정:', '신원 → 권한 → 스코프 → 원가 가시성 → 라이선스', '급여·원가 기본 제외 · 25초 안 페이징'], { fill: AMBER_BG, stroke: AMBER, size: 10 });
  v.box(900, 340, 240, 130, '응답', ['월별 워크로그·집계(JSON)', '+ 승인/인증 상태 열(어프로벌 프로퍼티)', 'OData 는 제품 범위 제외'], { fill: GREEN_BG, stroke: GREEN, size: 10 });
  v.arrow([[260, 405], [310, 405]], { label: 'Bearer', at: [285, 385] });
  v.arrow([[540, 405], [590, 405]]);
  v.arrow([[850, 405], [900, 405]]);
  v.text(60, 492, '미검증: 핸들러가 호출자 accountId 를 받는지(3LO 연동 1회 생성으로 확인) — 결과에 따라 기존 권한 모델 재사용 vs 스코프=권한 설계로 갈린다', { size: 10.5, color: RED });
  return v;
}

// ───────────── 7. 통제 Phase 로드맵 ─────────────
function phaseRoadmap() {
  const v = new Svg(1200, 520, '통제는 단계별로 켠다 — 위험 모드는 기본 OFF, 사이트별 실측 관문 PASS 기록 없이는 서버가 저장을 거부');
  const ph = [
    { t: 'Phase A', s: '기본 ON', lines: ['진단 도구', '쓰기 경로 재설계(승인·인증 잠금)', '기간 창(이슈 Start~Due, 기본 OFF)', '다른 경로 입력 FLAG'], gate: '기간 창만 G_FIELD', fill: GREEN_BG, stroke: GREEN },
    { t: 'Phase B', s: '1차 목표', lines: ['확정분만 visibility 숨김', '(APPROVED · CERTIFIED/MISMATCH)', '사람 전원 수정·삭제 불가', '대시보드 합계는 그대로 보임'], gate: 'G_ROLE · G_BLOCK · G_PRESERVE · G_AGG · G_RECOVER', fill: T[50], stroke: T[500] },
    { t: 'Phase C', s: '선택', lines: ['워크포스 연동 이슈 전체', '작성 즉시 숨김', '워크포스 출처 서명 전제'], gate: 'B 관문 + G_POST · G_WF · G_LINK', fill: BG, stroke: LINE },
    { t: 'Phase D', s: '쓰지 않음', lines: ['출처 증명 없는 다른 경로 입력', '자동 삭제', '사용자 결정(Q136): 표시·경고·정산 제외만'], gate: '통제 알림 준비 전 무조건 거부', fill: RED_BG, stroke: RED },
  ];
  ph.forEach((p, i) => {
    const x = 40 + i * 285;
    v.box(x, 70, 265, 200, p.t + '  ·  ' + p.s, p.lines, { fill: p.fill, stroke: p.stroke, size: 10.5 });
    v.rect(x, 290, 265, 60, { fill: WHITE, stroke: p.stroke, r: 8 });
    v.text(x + 12, 310, '켜는 조건(서버 강제)', { size: 10, bold: true, color: T[700] });
    v.text(x + 12, 330, p.gate, { size: 9.5, color: INK });
    if (i < 3) v.arrow([[x + 265, 170], [x + 285, 170]]);
  });
  v.group(40, 380, 1120, 120, '실측 관문 순서 (개발 사이트 · 시험 계정 5종 · 통과 기준 = 실제 기록 불변)');
  const gates = ['G_ROLE 앱 계정이 제한 역할 멤버', 'G_PRESERVE visibility 만 PUT·null 해제', 'G_BLOCK 작성자·관리자·토큰 차단', 'G_AGG timespent·JQL 집계 보존', 'G_RECOVER 해제·제거 복구', 'G_POST · G_HANDOFF · G_TEAM_MANAGED'];
  gates.forEach((g, i) => {
    const x = 60 + i * 183;
    v.rect(x, 420, 170, 60, { fill: i < 5 ? T[50] : WHITE, stroke: i < 5 ? T[500] : LINE, r: 8 });
    const [k, ...rest] = g.split(' ');
    v.text(x + 85, 444, k, { size: 11, bold: true, color: T[900], anchor: 'middle' });
    v.text(x + 85, 464, rest.join(' '), { size: 9.5, color: GRAY, anchor: 'middle' });
    if (i < 5) v.arrow([[x + 170, 450], [x + 183, 450]], { sw: 1.2 });
  });
  return v;
}

// ───────────── 8. 데이터 지도 ─────────────
function dataMap() {
  const v = new Svg(1200, 600, '원본은 Jira 에, 앱 데이터는 Atlassian 인프라 안에 — 테넌트 밖으로 나가는 경로는 다운로드와 SAP 뿐');
  v.group(40, 70, 1120, 360, 'Atlassian 인프라 (Runs on Atlassian — 외부 egress 없음)');
  v.box(60, 110, 340, 300, 'Jira Cloud (원본)', ['워크로그 시간·일자·이슈·설명', '권한 스킴 · 사용자 · 프로젝트', '', '엔티티 프로퍼티(교환물)', '  movesApproval.{YYYY} 결재 요약', '  movesApproval.cert.{YYYY-MM} 인증 문서', '  movesRms.org · rms.policy · movesApproval.ctl', '  → 편집 권한자 누구나 쓸 수 있어 서명 검증 후에만 신뢰', '  → 읽기 범위는 Jira 엔티티 열람 권한(기밀성 없음)'], { fill: WHITE, size: 10.5 });
  v.box(430, 110, 350, 300, '어프로벌 Forge SQL (설치당)', ['approval_request/approver/event — 결재(3년)', 'timesheet_* · period_close/reopen — 기간', 'worklog_cert* — 인증(무기한)', 'worklog_mirror/history — 변경 이력(12/36개월)', 'worklog_control/_log — 통제(무기한)', 'approval_settings_audit — 설정(365일)', 'approval_notification — 알림(180일)', '', '한도 prod 1GiB · stg 256MiB · dev 128MiB'], { fill: T[50], stroke: T[500], size: 10.5 });
  v.box(810, 110, 330, 300, '워크포스 Forge SQL + KVS', ['users · projectusers · project_team', 'team · role · level · holiday(KVS)', '급여 정책 · 계획 · 스냅샷', '', '연동으로 새 테이블 없음(DB 무증가)', '인증 문서는 읽어서 계산에만 사용', '', 'Forge 환경 변수: 연동 서명 개인키', '(forge variables set --encrypt)'], { size: 10.5 });
  // 밖으로
  v.box(60, 470, 340, 100, '사용자 다운로드 (고객 책임)', ['xlsx: 워크로그 추출 · 감사 내보내기', 'PDF: 증명서', '보관 책임은 고객 · 앱 통제 밖'], { fill: BG, size: 10.5 });
  v.box(430, 470, 350, 100, 'SAP (고객이 켜는 스위치)', ['관리자 "앱 REST API" 활성화 후에만', '3LO 토큰 · 조직 구성원 누구나 연동 생성 가능', '응답 범위 축소는 우리 코드 책임'], { fill: BG, size: 10.5 });
  v.box(810, 470, 330, 100, '미확인 · 결정 필요', ['레지던시: 플랫폼 지원(문서), 리전·PINNED 미확인', '감사 계정 id 보존 정책 — 법무·Marketplace 확인', '제거 후 저장소는 soft delete → 영구 삭제'], { fill: AMBER_BG, stroke: AMBER, size: 10.5 });
  v.arrow([[230, 410], [230, 470]], { color: MUTED });
  v.arrow([[600, 410], [600, 470]], { color: MUTED });
  return v;
}

(async () => {
  await emit('00-system-architecture', systemArch());
  await emit('01-architecture', archDiagram());
  await emit('02-lock-layers', lockFlow());
  await emit('03-approval-flow', approvalFlow());
  await emit('04-certification', certFlow());
  await emit('05-history-pipeline', historyFlow());
  await emit('06-sap-options', sapFlow());
  await emit('07-control-phases', phaseRoadmap());
  await emit('08-data-map', dataMap());
  console.log('written', outputs.length, 'diagrams to', OUT);
})().catch((e) => { console.error(e); process.exit(1); });
