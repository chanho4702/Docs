import sys, copy
from pptx import Presentation
from pptx.util import Pt, Emu
from PIL import Image

SRC, DST = sys.argv[1], sys.argv[2]
EV = r'C:\CloudJira\moves-approval-jira\_workspace\workforce-channel-rest\evidence'
HERE = r'C:\CloudJira\moves-approval-jira\_workspace\stradvision-2026-10-20'
p = Presentation(SRC)

def shape(slide_no, sid):
    for sh in p.slides[slide_no - 1].shapes:
        if sh.shape_id == sid: return sh
    raise KeyError((slide_no, sid))

def set_paras(slide_no, sid, texts):
    """문단별 첫 run 서식을 유지한 채 글자만 바꾼다. 문단 수가 같아야 한다."""
    tf = shape(slide_no, sid).text_frame
    paras = [para for para in tf.paragraphs if para.runs]
    assert len(paras) == len(texts), (slide_no, sid, [x.text for x in paras], texts)
    for para, text in zip(paras, texts):
        para.runs[0].text = text
        for r in para.runs[1:]: r.text = ''

def fill_row(slide_no, sid, values, size=8):
    tbl = shape(slide_no, sid).table
    row = tbl.rows[1]
    assert len(row.cells) == len(values), (slide_no, len(row.cells), values)
    for cell, v in zip(row.cells, values):
        tf = cell.text_frame
        tf.text = v
        for para in tf.paragraphs:
            for r in para.runs: r.font.size = Pt(size)

def put_image(slide_no, box_sid, path):
    box = shape(slide_no, box_sid)
    w, h = Image.open(path).size
    bw, bh = box.width, box.height
    scale = min(bw / w, bh / h)
    iw, ih = int(w * scale), int(h * scale)
    left = box.left + (bw - iw) // 2; top = box.top + (bh - ih) // 2
    pic = p.slides[slide_no - 1].shapes.add_picture(path, left, top, iw, ih)
    return pic

# 1 표지 날짜
set_paras(1, 7, ['2026.10.20'])
# 2 제안 범위
set_paras(2, 12, ['앱 간은 서명된 webtrigger, 외부 시스템은 Forge app REST API(OAuth 2.0)로 필요한 정보를 제공합니다.'])
set_paras(2, 11, ['앱 간 연동 · 외부 REST API'])
# 3 아키텍처
set_paras(3, 11, ['서명 webtrigger ⇄'])
set_paras(3, 18, ['Forge app REST API + OAuth 2.0 · 사용자 동의 토큰의 권한 범위 안에서 조회'])
# 4 DB 역할
set_paras(4, 7, ['상대 앱 DB에 직접 접근하지 않고, 필요한 업무 정보만 서명된 앱 간 요청(webtrigger)으로 주고받습니다.'])
# 7 외부 API
set_paras(7, 7, ['Forge app REST API', 'OAuth 2.0 동의 토큰'])
set_paras(7, 12, ['1차: 조직 정보 — 사용자·소속 팀·팀장, 팀 구성(GET /v1/organization/users·teams). 승인 상태·인정 시간 API는 다음 단계로 개발합니다.'])
set_paras(7, 14, ['사이트 관리자가 앱 REST API를 켜고, 고객 OAuth 앱에 권한을 연결해 사용자 동의 토큰으로 호출합니다. 응답은 토큰 주인의 Workforce 권한 범위로 제한됩니다.'])
set_paras(7, 15, ['Forge app REST API는 Preview(Jira·Confluence 전용)입니다. 2026-10-20 개발 사이트에서 개설·동의·호출을 실측했습니다.'])
# 8 외부 API 검증
put_image(8, 12, HERE + r'\ev-api-calls.png')
put_image(8, 14, EV + r'\apiroute\29-workforce-users-screen.jpg')
fill_row(8, 15, ['2026-10-20 / 개발 사이트', 'users·teams API / Tom Kim(Admin) 3LO', '토큰 없음 401 · scope 누락 403 · 정상 200(5명, 화면 일치) · 잘못된 요청 400', '통과 — 권한 없는 사용자 403은 운영 전 확인'])
# 9 변경 통제
set_paras(9, 14, ['승인·마감된 기록을 앱 전용 공개 범위로 숨겨 Jira 화면·REST에서 지정할 수 없게 합니다.'])
set_paras(9, 15, ['직접 경로의 쓰기 요청 실측과 계정·권한별 적용 범위는 운영 전 확정합니다. 외부 신규 생성의 전면 사전 차단은 별도입니다.'])
# 10 앱 내 차단
set_paras(10, 13, ['Approval 화면(같은 기록)'])
put_image(10, 12, EV + r'\functional\F06-issue-control-approved-locked.jpg')
put_image(10, 14, EV + r'\functional\F07c-approval-sees-wf-worklog-pending.jpg')
fill_row(10, 15, ['2026-10-20 / 개발 사이트', 'VODF-2 승인된 기록 / Tom Kim(작성자)', 'Workforce 수정 창 "승인됨·수정 불가"(입력 잠김) · Approval 표 "승인됨 수정 불가"', '잠금 확인 — 수정 요청 거부 응답은 추가 실측'])
# 11 Jira 직접 경로
put_image(11, 12, HERE + r'\ev-jira-direct.png')
put_image(11, 14, EV + r'\functional\F05-cert-query-mywork-calendar.jpg')
set_paras(11, 13, ['원본 유지 증거(앱 화면)'])
fill_row(11, 15, ['2026-10-20 / 개발 사이트', 'worklog 24595(승인됨) / Tom Kim(작성자)', 'Jira REST 조회 404(볼 권한 없음)·목록에도 없음 · 앱에는 잠금 상태로 유지', '조회 차단 확인 — 수정·삭제 요청은 운영 전 실측'])
# 14 적용 순서
set_paras(14, 8, ['자동 테스트 Approval 2,762개 · Workforce 2,603개 통과, 개발 사이트 기능·보안 실측'])
set_paras(14, 9, ['2026-10-20 개발 사이트: 앱 간 채널 기능 11종 통과·위조 요청 26종 거부, 외부 API 개설·호출 실측. 결재 결과 반영·운영 환경 확인은 다음 단계입니다.'])
p.save(DST)
print('saved', DST)
