from pathlib import Path
for lang in ['ko','en']:
 p=Path(f'docs/guide/{lang}/11-data-security-privacy.md')
 s=p.read_text(encoding='utf-8')
 if lang=='ko':
  s=s.replace('워크로그·필드·댓글은 행위자의 권한으로 처리합니다.', '워크로그·필드·댓글은 기본적으로 행위자의 권한으로 처리합니다. 관리자가 필드 변경 앱 대체 적용을 켜면 승인된 필드의 사용자 권한·화면 거절 뒤 앱 권한으로 적용을 시도하며, Jira 변경 이력에는 앱이 표시됩니다. 앱의 결재 기록에는 실제 승인자를 보존합니다.')
  s=s.replace('업무함 소유분', '해당 계정이 소유하거나 요청·대상자로 포함된 업무함 사본')
 else:
  s=s.replace("Worklogs, fields and comments use the acting user's permissions.", "Worklogs, fields and comments normally use the acting user's permissions. If an administrator enables app fallback for approved field changes, the app attempts the write after an explicit user permission or screen rejection. Jira history records the app, while the approval record retains the actual approver.")
  s=s.replace('owned inbox entries', 'inbox copies owned by the account or referring to it as requester or subject')
 p.write_text(s,encoding='utf-8')
ko='''\n\n## 기간 재개방과 필드 앱 적용\n\n기간 관리의 **새 입력 허용**은 마감 잠금만 풀며 기존 승인·인증은 유지합니다. **수정까지 허용**은 승인·인증·숨김 해제 건수를 미리 보여 주고 사유를 받은 뒤 실행합니다. 기존 결정과 인증 기록은 보존하고 재승인·재인증이 필요한 상태로 전환합니다. 작업이 나뉘면 이어하기로 완료하세요. 숨김 해제는 통제 작업 큐에서 처리하므로 기간 처리 완료 뒤에도 잠시 시간이 걸릴 수 있습니다.\n\n필드 변경의 앱 대체 적용은 기본 꺼짐입니다. 켜면 사용자 PUT의 명확한 권한 또는 화면 거절 뒤 앱 권한으로 한 번 더 시도합니다. Jira 이력의 수정자는 앱이 되며 결재 승인자는 유지합니다. 앱에 편집 권한이 없거나 화면 제약이 해소되지 않으면 적용되지 않습니다. 결과 불명(UNKNOWN)은 중복 변경을 막기 위해 자동 재전송하지 않습니다.\n'''
en='''\n\n## Reopening periods and app field application\n\n**Allow new input** removes the period closure lock while retaining existing approval and certification. **Allow editing too** previews approval, certification and hidden-worklog counts and requires a reason. Existing decisions and certification records remain, but reapproval and recertification become necessary. Resume a partial operation until it finishes. Visibility restoration runs in the control queue and may finish shortly after the period operation.\n\nApp fallback for field changes is off by default. When enabled, an explicit permission or screen rejection of the user PUT permits one app attempt. Jira records the app as the editor; the approval record retains the human approver. Application can still fail if the app lacks permission or the screen restriction remains. An unknown result is not automatically resent, to avoid duplicate writes.\n'''
for lang,extra in [('ko',ko),('en',en)]:
 p=Path(f'docs/guide/{lang}/09-admin-guide.md'); p.write_text(p.read_text(encoding='utf-8')+extra,encoding='utf-8')
p=Path('src/resolver/approval/__test__/ApprovalService.test.js')
s=p.read_text(encoding='utf-8')+'''\n\ndescribe('삭제된 계정의 새 결재 참여 방지', () => {\n  it('과거 결정은 유지하되 삭제된 승인자를 새 요청에 넣지 못한다', async () => {\n    const privacy = { assertOpen: jest.fn(async () => { throw new Error('INVALID_TARGET'); }) };\n    const app = service({ privacy });\n    await expect(app.assertApproversAllowed([{ approverKeys: ['closed'] }], { adapter: {}, target: {}, principal: {} })).rejects.toThrow('INVALID_TARGET');\n    expect(privacy.assertOpen).toHaveBeenCalledWith(['closed']);\n    expect(app.repository.createRequest).not.toHaveBeenCalled();\n  });\n});\n'''
p.write_text(s,encoding='utf-8')