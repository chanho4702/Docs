from pathlib import Path
p=Path('src/resolver/approval/ApprovalService.js')
s=p.read_text(encoding='utf-8')
s="import personalDataState from '../personalData/PersonalDataState';\n"+s
s=s.replace('  return { users, groups };','  return { users: (await personalDataState.overlay(users)).filter((user) => user.accountStatus !== \'closed\'), groups };')
s=s.replace('    projectEnabled = (projectId) => isProjectEnabled(projectId),\n    clock = Date.now,','    projectEnabled = (projectId) => isProjectEnabled(projectId),\n    privacy = null,\n    clock = Date.now,')
s=s.replace('    this.projectEnabled = projectEnabled;','    this.projectEnabled = projectEnabled;\n    this.privacy = privacy;')
s=s.replace('    const registry = skipRegistry ? [] : await this.registryLoader().catch(() => []);','    if (this.privacy) await this.privacy.assertOpen(keys);\n    const registry = skipRegistry ? [] : await this.registryLoader().catch(() => []);')
s=s.replace('    const supersedes = fixedSupersedes !== undefined ? fixedSupersedes : payload.supersedes;', '    if (this.privacy) await this.privacy.assertOpen([principal.accountId, target.accountId, target.subjectAccount, ...cc]);\n    const supersedes = fixedSupersedes !== undefined ? fixedSupersedes : payload.supersedes;')
s=s.replace('export const approvalService = new ApprovalService();','export const approvalService = new ApprovalService({ privacy: personalDataState });')
p.write_text(s,encoding='utf-8')