from pathlib import Path
p=Path('src/resolver/fieldChange/FieldChangeApplier.js')
s=p.read_text(encoding='utf-8')
def replace(old,new):
    global s
    assert old in s, old[:120]
    s=s.replace(old,new)
replace('ApplyStatus, outcomeOf, planApply,','ApplyStatus, outcomeOf, planApply, shouldFallbackToApp,')
replace("import issueFieldReader from './IssueFieldReader';", "import issueFieldReader from './IssueFieldReader';\nimport fieldChangeAppGateway from './FieldChangeAppGateway';\nimport settingsRepository from '../settings/SettingsRepository';")
replace('appliedBy = null, attempts = 0,', "appliedBy = null, attempts = 0, applyMode = 'USER',")
replace('  status, already, code, current, appliedAt, appliedBy, attempts,','  status, already, code, current, appliedAt, appliedBy, attempts,\n  ...(applyMode === \'APP\' ? { applyMode } : {}),')
replace('attempts: row.applyAttempts,', 'attempts: row.applyAttempts, applyMode: row.applyMode,')
replace('    approvals = approvalRepository,', "    approvals = approvalRepository,\n    appWriter = fieldChangeAppGateway,\n    policyLoader = () => settingsRepository.getPolicy(),")
replace('    this.approvals = approvals;', '    this.approvals = approvals;\n    this.appWriter = appWriter;\n    this.policyLoader = policyLoader;')
replace('''    let current = { known: false, value: null, display: null };
    try {
      const issue = await this.reader.issueWithFields(row.issueId, [row.fieldId], { fresh: true });
      if (issue && Object.prototype.hasOwnProperty.call(issue.fields ?? {}, row.fieldId)) {
        current = fromIssueField(row.fieldType, issue.fields[row.fieldId]);
      }
    } catch {
      // 못 읽으면 쓰지 않는다(UNREADABLE → FAILED VALUE_UNREADABLE)
    }

    const plan = planApply({ from: row.fromValue, to: row.toValue, current });
    let put = null;''', '''    let current = await this.currentValue(row);
    let plan = planApply({ from: row.fromValue, to: row.toValue, current });
    let put = null;
    let applyMode = 'USER';''')
replace('    const outcome = outcomeOf(plan, put);', '''    if (shouldFallbackToApp({ fieldChangeApplyFallback: 'APP' }, put)) {
      const policy = await this.policyLoader().catch(() => null);
      const withinBudget = !budget || this.clock() - budget.startedAt + 3_000 < budget.limitMs;
      if (withinBudget && shouldFallbackToApp(policy, put)) {
        // 권한 거절 뒤에도 다른 편집이 들어올 수 있어 앱 PUT 직전에 호출자 권한으로 값을 다시 확인한다.
        current = await this.currentValue(row);
        plan = planApply({ from: row.fromValue, to: row.toValue, current });
        if (plan === ApplyPlan.WRITE) {
          if (!(await this.repository.markAppSending(row.requestId, token))) return this.afterLostClaim(row.requestId, retry);
          applyMode = 'APP';
          try {
            put = await this.appWriter.updateField(row.issueId, row.fieldId, toJiraField(row.fieldType, row.toValue));
          } catch {
            put = { ok: false, timedOut: true };
          }
        }
      }
    }
    const outcome = outcomeOf(plan, put);''')
replace('appliedBy: applied ? by : null,', "appliedBy: applied ? (applyMode === 'APP' ? 'APP' : by) : null,")
replace('      conflictValue: conflict ? current.value : null,', '      mode: applyMode,\n      conflictValue: conflict ? current.value : null,')
replace('outcome, attempts, actorKey: by, now, notify:', 'outcome, attempts, actorKey: by, applyMode, now, notify:')
replace('      attempts,\n    });\n  }', '      attempts,\n      applyMode,\n    });\n  }')
replace('  /** claim 실패', '''  async currentValue(row) {
    try {
      const issue = await this.reader.issueWithFields(row.issueId, [row.fieldId], { fresh: true });
      if (issue && Object.prototype.hasOwnProperty.call(issue.fields ?? {}, row.fieldId)) {
        return fromIssueField(row.fieldType, issue.fields[row.fieldId]);
      }
    } catch {
      // 조회 불가는 앱 권한 쓰기의 근거가 될 수 없다.
    }
    return { known: false, value: null, display: null };
  }

  /** claim 실패''')
replace('outcome, attempts, actorKey, now, notify = null,', "outcome, attempts, actorKey, now, notify = null, applyMode = 'USER',")
replace('      reason = outcome.code;', "      reason = applyMode === 'APP' ? 'APP_FALLBACK' : outcome.code;")
replace("      reason = applyMode === 'APP' ? 'APP_FALLBACK' : outcome.code;\n    } else {", "      reason = applyMode === 'APP' ? `APP_FALLBACK:${outcome.code}` : outcome.code;\n    } else {")
replace('      contentVersion: 0,', "      contentVersion: 0,\n      ...(outcome.status === ApplyStatus.APPLIED && applyMode === 'APP' ? { appliedBy: 'APP' } : {}),")
p.write_text(s,encoding='utf-8')
p=Path('src/resolver/fieldChange/FieldChangeRepository.js'); s=p.read_text(encoding='utf-8')
replace("SET apply_status = '${ApplyStatus.APPLYING}', apply_token = ?", "SET apply_status = '${ApplyStatus.APPLYING}', apply_mode = 'USER', apply_token = ?")
replace('  async markStaleUnknown(requestId, before) {', '''  async markAppSending(requestId, token) {
    const result = await this.query(`UPDATE ${REQ} SET apply_mode='APP',rev=rev+1
      WHERE request_id=UUID_TO_BIN(?) AND apply_status='UNKNOWN' AND apply_token=? AND apply_mode='USER'`, [requestId, token]);
    return result.rowsAffected === 1;
  }

  async markStaleUnknown(requestId, before) {''')
p.write_text(s,encoding='utf-8')
p=Path('src/resolver/fieldChange/FieldChangeService.js'); s=p.read_text(encoding='utf-8')
replace('  appliedBy: row.appliedBy,', "  appliedBy: row.appliedBy,\n  ...(row.applyMode === 'APP' ? { applyMode: 'APP' } : {}),")
p.write_text(s,encoding='utf-8')
p=Path('src/resolver/fieldChange/__test__/memoryFieldChangeRepo.js'); s=p.read_text(encoding='utf-8')
replace("    applyCode: null, appliedAt:", "    applyMode: 'USER', applyCode: null, appliedAt:")
replace("        applyStatus: 'APPLYING', applyToken:", "        applyStatus: 'APPLYING', applyMode: 'USER', applyToken:")
replace('applyCode, appliedAt, appliedBy, conflictValue, conflictDisplay,\n    })', "applyCode, appliedAt, appliedBy, conflictValue, conflictDisplay, mode = 'USER',\n    })")
replace('        applyStatus, applyCode, appliedAt, appliedBy, conflictValue, conflictDisplay, rev:', '        applyStatus, applyCode, appliedAt, appliedBy, applyMode: mode, conflictValue, conflictDisplay, rev:')
replace('    markStaleUnknown: jest.fn', '''    markAppSending: jest.fn(async (requestId, token) => {
      const row = rows.get(requestId);
      if (!row || row.applyStatus !== 'UNKNOWN' || row.applyToken !== token || row.applyMode !== 'USER') return false;
      Object.assign(row, { applyMode: 'APP', rev: row.rev + 1 });
      return true;
    }),
    markStaleUnknown: jest.fn''')
p.write_text(s,encoding='utf-8')