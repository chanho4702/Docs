from pathlib import Path
p=Path('src/resolver/approval/target/FieldChangeTargetAdapter.js')
s=p.read_text(encoding='utf-8').replace('appliedBy: row.appliedBy,','appliedBy: row.appliedBy,\n    ...(row.applyMode === \'APP\' ? { applyMode: \'APP\' } : {}),')
p.write_text(s,encoding='utf-8')