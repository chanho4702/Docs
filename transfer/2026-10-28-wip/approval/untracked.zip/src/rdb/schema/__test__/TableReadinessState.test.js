import * as commonQuery from '../../query/CommonQuery';
import {
  isTableReady, resetTableReadinessCache, tableState, TableState,
} from '../TableReadiness';

/** 2026-10-28 전수 점검 R10 — 테이블 부재(MISSING)와 확인 실패(UNAVAILABLE)를 한 false 로 접지 않는다. */
describe('TableReadiness.tableState — READY · MISSING · UNAVAILABLE', () => {
  beforeEach(() => {
    resetTableReadinessCache();
    jest.spyOn(console, 'error').mockImplementation(() => {});
  });
  afterEach(() => { jest.restoreAllMocks(); resetTableReadinessCache(); });

  it('있으면 READY 이고 캐시된다(두 번째 호출은 SQL 0)', async () => {
    const spy = jest.spyOn(commonQuery, 'executeQuery').mockResolvedValue({ rows: [{ cnt: 1 }] });
    expect(await tableState('approval_request')).toBe(TableState.READY);
    expect(await tableState('approval_request')).toBe(TableState.READY);
    expect(await isTableReady('approval_request')).toBe(true);
    expect(spy).toHaveBeenCalledTimes(1);
  });

  it('information_schema 에 없으면 MISSING — 캐시하지 않아 다음 호출이 다시 묻는다', async () => {
    const spy = jest.spyOn(commonQuery, 'executeQuery').mockResolvedValue({ rows: [{ cnt: 0 }] });
    expect(await tableState('approval_request')).toBe(TableState.MISSING);
    expect(await isTableReady('approval_request')).toBe(false);
    expect(spy).toHaveBeenCalledTimes(2);
  });

  it('프로브 자체가 실패(SQL 장애)하면 UNAVAILABLE — boolean 계약(isTableReady)은 여전히 false', async () => {
    jest.spyOn(commonQuery, 'executeQuery').mockRejectedValue(new Error('SIMULATED_SQL_UNAVAILABLE'));
    expect(await tableState('approval_request')).toBe(TableState.UNAVAILABLE);
    expect(await isTableReady('approval_request')).toBe(false);
  });

  it('같은 테이블의 동시 호출은 프로브 1회를 공유한다', async () => {
    const spy = jest.spyOn(commonQuery, 'executeQuery').mockRejectedValue(new Error('SIMULATED_SQL_UNAVAILABLE'));
    const [a, b] = await Promise.all([tableState('approval_request'), tableState('approval_request')]);
    expect([a, b]).toEqual([TableState.UNAVAILABLE, TableState.UNAVAILABLE]);
    expect(spy).toHaveBeenCalledTimes(1);
  });

  it('이름이 없으면 MISSING', async () => {
    expect(await tableState('')).toBe(TableState.MISSING);
    expect(await tableState(undefined)).toBe(TableState.MISSING);
  });
});
