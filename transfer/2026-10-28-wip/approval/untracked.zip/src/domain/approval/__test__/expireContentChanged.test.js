import { expireByContentChange, expireByTargetChange } from '../transitions';
import { ExpiryReason } from '../constants';

/**
 * 2026-10-28 전수 점검 R05 — 워크로그 인증 어댑터(beforeDecide)·자동 요청(submit AUTO)은 공통 `expireForTarget(state, 'CONTENT_CHANGED')`
 * 로 낡은 PENDING 을 닫는데, `expireByTargetChange` 가 그 사유를 몰라 `bad reason` 으로 거절했다 → 낡은 요청이 남아 새 자동 요청을
 * ALREADY_OPEN 으로 막았다. 이 테스트는 "거절되지 않는다"와 "전용 전이(expireByContentChange)와 같은 결과"를 고정한다.
 */
const ID = '11111111-1111-4111-8111-111111111111';
const NOW = 1_700_000_000_000;
const pending = () => ({
  requestId: ID, targetKind: 'WORKLOG_CERTIFICATION', status: 'PENDING', rev: 1,
  steps: [{ stepOrder: 1, approverKeys: ['a', 'b'], requiredApprovals: 1 }],
  decisions: new Map(), events: [], createdAt: NOW, updatedAt: NOW,
  contentVersion: 1, currentStepOrder: 1, expiresAt: null, requesterKey: 'owner',
});

describe('expireByTargetChange — CONTENT_CHANGED(워크로그 내용 변경) 허용', () => {
  it('CONTENT_CHANGED 를 받아 EXPIRED 로 닫는다(bad reason 아님)', () => {
    const out = expireByTargetChange(pending(), { reason: ExpiryReason.CONTENT_CHANGED, now: NOW + 1 });
    expect(out.ok).toBe(true);
    expect(out.next.status).toBe('EXPIRED');
    expect(out.changes.event.eventType).toBe('EXPIRED');
  });

  it('전용 전이 expireByContentChange 와 같은 결과 — 버전 그대로, 이벤트 id 동일(겹쳐 만료돼도 1건)', () => {
    const viaTarget = expireByTargetChange(pending(), { reason: ExpiryReason.CONTENT_CHANGED, now: NOW + 1 });
    const direct = expireByContentChange(pending(), { now: NOW + 1 });
    expect(viaTarget).toEqual(direct);
    expect(viaTarget.changes.event.eventId).toBe(direct.changes.event.eventId);
  });

  it('PENDING 이 아니면 닫지 않는다 / 모르는 사유는 여전히 bad reason', () => {
    expect(expireByTargetChange({ ...pending(), status: 'APPROVED' }, { reason: ExpiryReason.CONTENT_CHANGED, now: NOW + 1 }))
      .toEqual({ ok: false, reason: 'not pending' });
    expect(expireByTargetChange(pending(), { reason: 'SOMETHING_ELSE', now: NOW + 1 })).toEqual({ ok: false, reason: 'bad reason' });
  });
});
