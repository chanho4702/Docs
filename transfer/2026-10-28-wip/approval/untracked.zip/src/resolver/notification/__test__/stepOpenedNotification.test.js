import {
  buildNotificationRows, notificationTemplate, selectNotificationRecipients, STEP_OPENED_KIND,
} from '../NotificationService';

/**
 * 2026-10-28 전수 점검 R06 — 1단계가 끝나 2단계가 열렸을 때 새 차례 결재자에게 앱 내 알림이 없었다(중간 APPROVED 의 수신자가 빈 목록).
 * STEP_OPENED 종류: 현재 단계의 미결 결재자에게 `myTurn` 문구, id 는 (요청, 종류, 수신자, 승인 이벤트) 로 결정적.
 */
const approvers = [
  { accountId: 'a', stepOrder: 1, decisionType: 'APPROVE' },
  { accountId: 'b', stepOrder: 2, decisionType: 'PENDING' },
  { accountId: 'c', stepOrder: 2, decisionType: 'PENDING' },
  { accountId: 'd', stepOrder: 3, decisionType: 'PENDING' },
];

describe('STEP_OPENED 수신자', () => {
  it('진행 중 + 현재 단계 2 → 2단계 미결 결재자만(1단계 결정자·3단계·요청자·행위자 제외)', () => {
    expect(selectNotificationRecipients({
      kind: STEP_OPENED_KIND, request: { status: 'PENDING', currentStepOrder: 2 },
      requesterAccountId: 'owner', actorAccountId: 'a', approvers, ccAccountIds: ['cc1'],
    })).toEqual(['b', 'c']);
  });

  it('요청이 종료됐거나 단계가 없으면 아무에게도 보내지 않는다', () => {
    expect(selectNotificationRecipients({ kind: STEP_OPENED_KIND, request: { status: 'APPROVED', currentStepOrder: 3 }, approvers })).toEqual([]);
    expect(selectNotificationRecipients({ kind: STEP_OPENED_KIND, request: { status: 'PENDING' }, approvers })).toEqual([]);
  });

  it('중간 APPROVED 자체는 여전히 빈 목록(요청자에게는 최종 승인만)', () => {
    expect(selectNotificationRecipients({
      kind: 'APPROVED', request: { status: 'PENDING', currentStepOrder: 2 }, requesterAccountId: 'owner', actorAccountId: 'a', approvers,
    })).toEqual([]);
  });

  it('문구는 myTurn, 행 id 는 수신자·승인 이벤트별로 결정적(같은 단계 개방은 1건)', () => {
    expect(notificationTemplate({ kind: STEP_OPENED_KIND })).toBe('notification.template.myTurn');
    const input = {
      kind: STEP_OPENED_KIND, requestId: '11111111-1111-4111-8111-111111111111',
      request: { status: 'PENDING', currentStepOrder: 2, requesterKey: 'owner' },
      event: { eventId: 'evt-approved-a', occurredAt: 1_700_000_000_000 }, actorAccountId: 'a', approvers,
    };
    const first = buildNotificationRows(input);
    const again = buildNotificationRows(input);
    expect(first.map((row) => row.recipientKey)).toEqual(['b', 'c']);
    expect(first.map((row) => row.notificationId)).toEqual(again.map((row) => row.notificationId));
    expect(first[0]).toMatchObject({ kind: STEP_OPENED_KIND, templateKey: 'notification.template.myTurn', eventKey: 'evt-approved-a' });
  });
});
