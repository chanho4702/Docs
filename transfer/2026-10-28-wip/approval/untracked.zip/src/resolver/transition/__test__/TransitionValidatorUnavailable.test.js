import { TransitionValidatorService } from '../TransitionValidatorService';
import { TransitionRuleRepository } from '../TransitionRuleRepository';
import { createMemoryPlainStore, createMemoryRuleStore } from './memoryRuleStore';
import { isTableReady, resetTableReadinessCache, TableState } from '../../../rdb/schema/TableReadiness';
import * as commonQuery from '../../../rdb/query/CommonQuery';
import { ValidatorCode } from '../../../domain/transition/judge';

/**
 * 2026-10-28 전수 점검 R10 — 활성 규칙이 있는데 테이블 확인·후보 조회가 SQL 장애이면 validator 가 PASS_NOT_READY 로 **통과**했다.
 * 테이블 부재(마이그레이션 전 유예)와 DB 장애는 다른 사실이다: 장애는 REJECT_UNAVAILABLE(fail-closed).
 */
const RULE_ID = '22222222-2222-4222-8222-222222222222';
const FLOW_ID = '11111111-1111-4111-8111-111111111111';
const NOW = 1_700_000_000_000;

const buildRules = async () => {
  const rules = new TransitionRuleRepository({ store: createMemoryRuleStore(), plain: createMemoryPlainStore(), uuid: () => RULE_ID });
  await rules.insert({
    projectId: '10000', projectKey: 'OPS', issueTypeId: '*', toStatusId: '5', enabled: true, flowId: FLOW_ID, now: NOW,
  });
  return rules;
};

const buildService = async ({ tableReady, tableState, findCandidates }) => new TransitionValidatorService({
  rules: await buildRules(),
  tableReady,
  tableState,
  transitions: { findCandidates, arm: async () => true },
  globalEnabled: async () => true,
  featureEnabled: async () => true,
  projectEnabled: async () => true,
  licenseBlocked: async () => false,
  reader: {
    issueForValidator: async () => ({
      issueId: '100', issueKey: 'OPS-1', projectId: '10000', issueTypeId: '10001', currentStatusId: '3',
    }),
  },
  autoRequest: null,
  logger: { log: jest.fn(), error: jest.fn() },
});

const payload = { issue: { id: '100', key: 'OPS-1' }, transition: { from: { id: '3' }, to: { id: '5' } } };
const lastCode = (service) => service.logger.log.mock.calls.filter(([tag]) => tag === '[VALIDATOR]').pop()?.[1];

describe('TransitionValidatorService — 테이블 확인 불가(SQL 장애)는 거부', () => {
  beforeEach(() => { resetTableReadinessCache(); jest.spyOn(console, 'error').mockImplementation(() => {}); });
  afterEach(() => { jest.restoreAllMocks(); resetTableReadinessCache(); });

  it('실제 프로브 + SQL 장애(테이블 확인·후보 조회 모두 실패) → result:false, REJECT_UNAVAILABLE', async () => {
    jest.spyOn(commonQuery, 'executeQuery').mockRejectedValue(new Error('SIMULATED_SQL_UNAVAILABLE'));
    const service = await buildService({
      tableReady: isTableReady,
      findCandidates: async () => { throw new Error('SIMULATED_SQL_UNAVAILABLE'); },
    });
    const result = await service.validate(payload, {});
    expect(commonQuery.executeQuery).toHaveBeenCalled();
    expect(result.result).toBe(false);
    expect(typeof result.errorMessage).toBe('string');
    expect(lastCode(service)).toBe(ValidatorCode.REJECT_UNAVAILABLE);
  });

  it('테이블이 정말 없으면(MISSING) 기존 유예 그대로 — PASS_NOT_READY 통과, 후보 조회 오류는 버린다', async () => {
    jest.spyOn(commonQuery, 'executeQuery').mockResolvedValue({ rows: [{ cnt: 0 }] });
    const service = await buildService({
      tableReady: isTableReady,
      findCandidates: async () => { throw new Error('TABLE_DOES_NOT_EXIST'); },
    });
    expect(await service.validate(payload, {})).toEqual({ result: true });
    expect(lastCode(service)).toBe(ValidatorCode.PASS_NOT_READY);
  });

  it('주입한 tableState 가 하나라도 UNAVAILABLE 이면 거부(다른 테이블이 READY 라도)', async () => {
    const service = await buildService({
      tableState: async (table) => (table === 'approval_request' ? TableState.UNAVAILABLE : TableState.READY),
      findCandidates: async () => [],
    });
    expect((await service.validate(payload, {})).result).toBe(false);
    expect(lastCode(service)).toBe(ValidatorCode.REJECT_UNAVAILABLE);
  });

  it('boolean tableReady 만 주입한 기존 호출 계약 — false 는 MISSING(통과), true 는 READY(판정 진행)', async () => {
    const missing = await buildService({ tableReady: async () => false, findCandidates: async () => [] });
    expect(await missing.validate(payload, {})).toEqual({ result: true });
    expect(lastCode(missing)).toBe(ValidatorCode.PASS_NOT_READY);

    const ready = await buildService({ tableReady: async () => true, findCandidates: async () => [] });
    expect((await ready.validate(payload, {})).result).toBe(false);
    expect(lastCode(ready)).toBe(ValidatorCode.REJECT_NO_REQUEST);
  });
});
