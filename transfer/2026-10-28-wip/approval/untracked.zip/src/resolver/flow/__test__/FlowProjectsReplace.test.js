import { FlowRepository, flowReviewKey } from '../FlowRepository';

/**
 * 2026-10-28 전수 점검 R08 — 적용 프로젝트를 통째로 DELETE 한 뒤 INSERT 하다 실패하면 매핑이 비어 "모든 프로젝트 공용"으로 넓어졌다.
 * 지금은 넣고 나서 지운다: 어느 단계에서 끊겨도 매핑이 비는(=전체) 경로가 없다. 단계 교체는 지우기 전에 검토 표식을 세운다.
 */
const ID = '11111111-1111-4111-8111-111111111111';

/** 결재선 rev 를 흉내 내는 하네스 — rev 조건이 있는 문장은 현재 rev 와 같을 때만 효과를 낸다. */
const harness = ({ failInsertAt = null, flowRev = 5 } = {}) => {
  let projects = new Set(['10001']);
  let inserts = 0;
  const compact = (sql) => sql.replace(/\s+/g, ' ').trim();
  const revOk = (sql, params) => {
    if (!/f\.rev = \?/.test(sql)) return true;
    return Number(params[params.length - 1]) === flowRev;
  };
  const query = jest.fn(async (rawSql, params) => {
    const sql = compact(rawSql);
    if (sql.startsWith('INSERT INTO approval_flow_project')) {
      inserts += 1;
      if (failInsertAt === inserts) throw new Error('SIMULATED_INSERT_FAILURE');
      if (revOk(sql, params)) projects.add(params[1]);
      return { rowsAffected: 1 };
    }
    if (sql.startsWith('DELETE FROM approval_flow_project') && sql.includes('NOT IN')) {
      if (!revOk(sql, params)) return { rowsAffected: 0 };
      const count = (sql.match(/NOT IN \(([^)]*)\)/)[1].match(/\?/g) || []).length;
      const keep = new Set(params.slice(1, 1 + count));
      projects = new Set([...projects].filter((p) => keep.has(p)));
      return { rowsAffected: 1 };
    }
    if (sql.startsWith('DELETE FROM approval_flow_project')) {
      if (revOk(sql, params)) projects = new Set();
      return { rowsAffected: 1 };
    }
    return { rowsAffected: 1, rows: [] };
  });
  const repo = new FlowRepository({ query, tableReady: async () => true });
  return { repo, query, projectsOf: () => [...projects].sort(), compact };
};

describe('replaceFlowProjects — 넣고 나서 지운다', () => {
  it('정상 교체: 새 매핑 INSERT(멱등) → 남을 것 밖만 DELETE', async () => {
    const h = harness();
    expect(await h.repo.replaceFlowProjects(ID, ['10002', '10003'])).toEqual(['10002', '10003']);
    expect(h.projectsOf()).toEqual(['10002', '10003']);
    const sqls = h.query.mock.calls.map(([sql]) => h.compact(sql));
    expect(sqls[0]).toMatch(/^INSERT INTO approval_flow_project \(flow_id, project_id\) SELECT UUID_TO_BIN\(\?\), \? FROM approval_flow f WHERE f\.flow_id = UUID_TO_BIN\(\?\) ON DUPLICATE KEY UPDATE project_id = project_id$/);
    expect(sqls[2]).toMatch(/^DELETE FROM approval_flow_project WHERE flow_id=UUID_TO_BIN\(\?\) AND project_id NOT IN \(\?, \?\)$/);
    expect(h.query.mock.calls[2][1]).toEqual([ID, '10002', '10003']);
  });

  it('rev 결속: 내 세대일 때만 넣고 지운다 — 엇갈린 두 저장(B 넣기 → C 넣기 → B 만 남기기 → C 만 남기기)이 매핑을 비우지 않는다', async () => {
    const h = harness({ flowRev: 6 }); // 두 번째 저장이 만든 세대가 6
    // 첫 저장(세대 5)의 INSERT 는 세대가 지나 효과 없음, DELETE 는 0행. 두 번째 저장(세대 6)만 반영 → {C}
    await h.repo.replaceFlowProjects(ID, ['B'], { rev: 5 });
    expect(h.projectsOf()).toEqual(['10001']);
    await h.repo.replaceFlowProjects(ID, ['C'], { rev: 6 });
    expect(h.projectsOf()).toEqual(['C']);
    const [insertSql, insertParams] = h.query.mock.calls[0];
    expect(h.compact(insertSql)).toMatch(/FROM approval_flow f WHERE f\.flow_id = UUID_TO_BIN\(\?\) AND f\.rev = \? ON DUPLICATE KEY/);
    expect(insertParams).toEqual([ID, 'B', ID, 5]);
    const [deleteSql, deleteParams] = h.query.mock.calls[1];
    expect(h.compact(deleteSql)).toMatch(/AND EXISTS \(SELECT 1 FROM approval_flow f WHERE f\.flow_id = UUID_TO_BIN\(\?\) AND f\.rev = \?\)$/);
    expect(deleteParams).toEqual([ID, 'B', ID, 5]);
  });

  it('첫 INSERT 실패 — 옛 매핑이 그대로 남는다(전체 적용으로 넓어지지 않는다)', async () => {
    const h = harness({ failInsertAt: 1 });
    await expect(h.repo.replaceFlowProjects(ID, ['10002'])).rejects.toThrow('SIMULATED_INSERT_FAILURE');
    expect(h.projectsOf()).toEqual(['10001']);
  });

  it('두 번째 INSERT 실패 — 옛 ∪ 일부 새 매핑이 남고 DELETE 는 가지 않는다(비는 순간 없음)', async () => {
    const h = harness({ failInsertAt: 2 });
    await expect(h.repo.replaceFlowProjects(ID, ['10002', '10003'])).rejects.toThrow('SIMULATED_INSERT_FAILURE');
    expect(h.projectsOf()).toEqual(['10001', '10002']);
    expect(h.query.mock.calls.some(([sql]) => sql.startsWith('DELETE'))).toBe(false);
  });

  it('빈 목록(= 전체 적용 선택)은 DELETE 하나 — 실패하면 옛 제한이 남는다(좁은 쪽 실패)', async () => {
    const h = harness();
    expect(await h.repo.replaceFlowProjects(ID, [])).toEqual([]);
    expect(h.projectsOf()).toEqual([]);
    expect(h.query).toHaveBeenCalledTimes(1);
  });
});

describe('updateFlow 단계 교체 — 지우기 전에 검토 표식', () => {
  const build = ({ failInsertSteps = false } = {}) => {
    const values = new Map();
    const store = {
      get: jest.fn(async (key) => values.get(key)),
      set: jest.fn(async (key, value) => { values.set(key, value); }),
      delete: jest.fn(async (key) => values.delete(key)),
    };
    const order = [];
    const query = jest.fn(async (sql) => {
      const head = sql.replace(/\s+/g, ' ').trim().slice(0, 40);
      order.push(head);
      if (failInsertSteps && sql.includes('INSERT INTO approval_flow_step')) throw new Error('SQL_FAILED');
      return { rowsAffected: 1, rows: sql.includes('SELECT BIN_TO_UUID') ? [{ flow_id: ID, name: 'flow', enabled: 1, rev: 3 }] : [] };
    });
    const repo = new FlowRepository({ query, store, tableReady: async () => true });
    return { repo, store, values, order, query };
  };
  const steps = [{ stepOrder: 1, requiredApprovals: 1, principals: [{ principalType: 'USER', principalKey: 'u1' }] }];

  it('표식 set → DELETE → INSERT → 표식 delete 순서', async () => {
    const h = build();
    await h.repo.updateFlow({ flowId: ID, name: 'flow', rev: 2, now: '2026-10-28 00:00:00', steps });
    expect(h.store.set).toHaveBeenCalledWith(flowReviewKey(ID), { needsReview: true, reason: 'STEPS_REPLACING' });
    const setAt = h.store.set.mock.invocationCallOrder[0];
    const deleteStepsAt = h.query.mock.invocationCallOrder[h.order.findIndex((s) => s.startsWith('DELETE FROM approval_flow_step'))];
    expect(setAt).toBeLessThan(deleteStepsAt);
    expect(h.store.delete).toHaveBeenCalledWith(flowReviewKey(ID));
    expect(h.values.has(flowReviewKey(ID))).toBe(false);
  });

  it('INSERT 실패 — 표식이 남아 요청 후보에서 빠진다', async () => {
    const h = build({ failInsertSteps: true });
    await expect(h.repo.updateFlow({ flowId: ID, name: 'flow', rev: 2, now: '2026-10-28 00:00:00', steps })).rejects.toThrow('SQL_FAILED');
    expect(h.values.get(flowReviewKey(ID))).toEqual({ needsReview: true, reason: 'STEPS_REPLACING' });
    expect(h.store.delete).not.toHaveBeenCalled();
  });
});
