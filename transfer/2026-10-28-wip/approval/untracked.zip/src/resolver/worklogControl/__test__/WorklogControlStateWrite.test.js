import { createWorklogControlState } from '../WorklogControlState';

/**
 * 2026-10-28 전수 점검 D03 — 상태 읽기-수정-쓰기가 겹치면 늦은 구세대가 신세대를 덮고, 워커가 실행 도중 세워진 표식을 지울 수 있었다.
 * 완전한 CAS 는 엔티티 전환(상용 뒤) 과제. 지금은 ① 쓴 뒤 다시 읽어 세대가 뒤로 갔으면 한 번 더 쓰고 ② 표식은 실행 시작에 읽은 것과 같을 때만 지운다.
 */
const build = (initial = {}) => {
  const values = new Map(Object.entries(initial));
  const store = {
    get: jest.fn(async (key) => values.get(key)),
    set: jest.fn(async (key, value) => { values.set(key, value); }),
    delete: jest.fn(async (key) => { values.delete(key); }),
  };
  const api = createWorklogControlState({ store, logger: { error: jest.fn(), log: jest.fn() } });
  return { api, store, values };
};

describe('update — 세대 역행 재쓰기', () => {
  it('정상: 한 번 쓰고 다시 읽어 확인(쓰기 1·읽기 2)', async () => {
    const { api, store } = build({ 'approval:worklogControl:state': { generation: 3 } });
    const out = await api.update(() => ({ generation: 4 }));
    expect(out.generation).toBe(4);
    expect(store.set).toHaveBeenCalledTimes(1);
  });

  it('쓴 직후 다른 쓰기가 구세대로 덮었으면 한 번 더 쓴다', async () => {
    const { api, store, values } = build({ 'approval:worklogControl:state': { generation: 3 } });
    store.set.mockImplementationOnce(async (key, value) => { values.set(key, { ...value, generation: 2 }); }); // 경쟁자가 2 로 덮은 것처럼
    const out = await api.update(() => ({ generation: 4 }));
    expect(out.generation).toBe(4);
    expect(store.set).toHaveBeenCalledTimes(2);
    expect(values.get('approval:worklogControl:state').generation).toBe(4);
  });
});

describe('clearPending — 시작에 읽은 표식과 같을 때만', () => {
  it('같으면 지운다', async () => {
    const { api, values } = build({ 'approval:worklogControl:pending': { at: 100 } });
    expect(await api.clearPending({ at: 100 })).toBe(true);
    expect(values.has('approval:worklogControl:pending')).toBe(false);
  });
  it('도중에 새 표식이 세워졌으면(at 다름) 남겨 둔다', async () => {
    const { api, values } = build({ 'approval:worklogControl:pending': { at: 200 } });
    expect(await api.clearPending({ at: 100 })).toBe(false);
    expect(values.get('approval:worklogControl:pending')).toEqual({ at: 200 });
  });
  it('시작엔 없었는데 생겼으면 남겨 둔다', async () => {
    const { api, values } = build({ 'approval:worklogControl:pending': { at: 200 } });
    expect(await api.clearPending(null)).toBe(false);
    expect(values.has('approval:worklogControl:pending')).toBe(true);
  });
  it('expected 를 안 주면 옛 동작(무조건 삭제)', async () => {
    const { api, values } = build({ 'approval:worklogControl:pending': { at: 200 } });
    expect(await api.clearPending()).toBe(true);
    expect(values.has('approval:worklogControl:pending')).toBe(false);
  });
});
