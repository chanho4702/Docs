import { WorklogControlWorker } from '../WorklogControlWorker';
import { WorklogControlRepository } from '../WorklogControlRepository';

/**
 * 2026-10-28 전수 점검 R07 — 확정 변경 증분 스캔이 200건 경계에서 같은 첫 묶음만 반복하고 커서를 전진시키지 않았다.
 * 지금은 keyset 커서 + 고정 상한(until) 으로 페이지를 잇고, 끝까지 돌았을 때만 confirmScanAt 을 올린다.
 */
const NOW = 1_700_000_000_000;
const ids = (from, count) => Array.from({ length: count }, (_, i) => String(from + i));

const workerWith = ({ pages, state = { confirmScanAt: NOW - 60_000 } }) => {
  const calls = [];
  const updates = [];
  let current = { ...state };
  const repository = {
    listConfirmChangesPage: jest.fn(async (args) => { calls.push(args); return pages.shift(); }),
  };
  const reevaluate = jest.fn(async () => {});
  const stateApi = {
    update: jest.fn(async (fn) => { const patch = fn(current); updates.push(patch); current = { ...current, ...patch }; return current; }),
  };
  const worker = { repository, reevaluate, state: stateApi };
  const run = (budget) => WorklogControlWorker.prototype.scanConfirmChanges.call(worker, { now: NOW, state: current }, budget);
  return { run, calls, updates, reevaluate, stateOf: () => current };
};

describe('scanConfirmChanges — keyset 페이지', () => {
  it('199건(한 페이지 미만) — 한 번 읽고 끝, confirmScanAt 을 until(now) 로 올리고 커서는 지운다', async () => {
    const h = workerWith({ pages: [{ ids: ids(1, 199), certCursor: false, sheetCursor: false }] });
    expect(await h.run()).toEqual({ scanned: 199, full: false });
    expect(h.calls).toEqual([{ since: NOW - 60_000, until: NOW, certCursor: null, sheetCursor: null, limit: 200 }]);
    expect(h.updates).toEqual([{ confirmScanAt: NOW, confirmScan: null }]);
  });

  it('한 페이지가 두 원천 합쳐 200 을 넘으면 reevaluate 에 200개씩 나눠 넘긴다(잘린 뒤쪽 영구 누락 방지)', async () => {
    const h = workerWith({ pages: [{ ids: ids(1, 201), certCursor: false, sheetCursor: false }] });
    expect(await h.run()).toEqual({ scanned: 201, full: false });
    expect(h.reevaluate.mock.calls.map(([list]) => list.length)).toEqual([200, 1]);
  });

  it('201건 — 1페이지(200) 뒤 커서를 저장하고 2페이지(1) 로 끝낸다. 두 번째 호출은 저장한 커서·같은 until 로 간다', async () => {
    const cursor = { at: NOW - 1000, id: '200' };
    const h = workerWith({ pages: [
      { ids: ids(1, 200), certCursor: cursor, sheetCursor: false },
      { ids: ['201'], certCursor: false, sheetCursor: false },
    ] });
    expect(await h.run()).toEqual({ scanned: 201, full: false });
    expect(h.calls[1]).toEqual({ since: NOW - 60_000, until: NOW, certCursor: cursor, sheetCursor: false, limit: 200 });
    expect(h.updates[0]).toEqual({ confirmScan: { since: NOW - 60_000, until: NOW, certCursor: cursor, sheetCursor: false } });
    expect(h.updates[1]).toEqual({ confirmScanAt: NOW, confirmScan: null });
    expect(h.reevaluate.mock.calls.map(([list]) => list.length)).toEqual([200, 1]);
  });

  it('정확히 200건 — 가득 찬 페이지는 커서를 남기고, 다음 빈 페이지가 끝을 확정한다(건너뛰는 행 없음)', async () => {
    const cursor = { at: NOW - 1000, id: '200' };
    const h = workerWith({ pages: [
      { ids: ids(1, 200), certCursor: cursor, sheetCursor: false },
      { ids: [], certCursor: false, sheetCursor: false },
    ] });
    expect(await h.run()).toEqual({ scanned: 200, full: false });
    expect(h.calls).toHaveLength(2);
    expect(h.stateOf().confirmScanAt).toBe(NOW);
  });

  it('예산이 다하면 진행 위치를 남기고 full:true — confirmScanAt 은 그대로, 다음 실행은 저장된 until·커서부터(새 변경은 다음 스캔)', async () => {
    const cursor = { at: NOW - 1000, id: '200' };
    let over = false;
    const h = workerWith({ pages: [
      { ids: ids(1, 200), certCursor: cursor, sheetCursor: { at: NOW - 900, requestId: 'r', id: '7' } },
      { ids: ['201'], certCursor: false, sheetCursor: false },
    ] });
    const budget = { over: () => over };
    const first = (async () => { const out = await h.run(budget); return out; });
    // 첫 페이지 뒤 예산 소진
    h.reevaluate.mockImplementationOnce(async () => { over = true; });
    expect(await first()).toEqual({ scanned: 200, full: true });
    expect(h.stateOf().confirmScanAt).toBe(NOW - 60_000);
    expect(h.stateOf().confirmScan).toEqual({ since: NOW - 60_000, until: NOW, certCursor: cursor, sheetCursor: { at: NOW - 900, requestId: 'r', id: '7' } });
    over = false;
    // 이어달리기 — 저장된 since·until(now 가 아니라 첫 스캔 시각)·커서로. 다음 날(ctx.now 가 하루 뒤)이라도 since 를 다시 계산하지 않는다.
    const resumed = workerWith({ pages: [{ ids: ['201'], certCursor: false, sheetCursor: false }], state: h.stateOf() });
    const dayLater = WorklogControlWorker.prototype.scanConfirmChanges.call(
      { repository: { listConfirmChangesPage: jest.fn(async (args) => { resumed.calls.push(args); return { ids: ['201'], certCursor: false, sheetCursor: false }; }) },
        reevaluate: jest.fn(async () => {}), state: { update: jest.fn(async (fn) => fn(resumed.stateOf())) } },
      { now: NOW + 2 * 86_400_000, state: h.stateOf() },
    );
    expect(await dayLater).toEqual({ scanned: 1, full: false });
    expect(resumed.calls[0]).toMatchObject({ since: NOW - 60_000, until: NOW, certCursor: cursor });
  });

  it('페이지 상한(10)에 닿으면 full:true 로 돌려 큐가 잇게 한다', async () => {
    const pages = Array.from({ length: 11 }, (_, i) => ({ ids: ids(i * 200 + 1, 200), certCursor: { at: NOW - 1, id: String((i + 1) * 200) }, sheetCursor: false }));
    const h = workerWith({ pages });
    expect(await h.run()).toEqual({ scanned: 2000, full: true });
    expect(h.calls).toHaveLength(10);
  });
});

describe('WorklogControlRepository.listConfirmChangesPage — SQL 모양', () => {
  const build = (rowsByQuery) => {
    const query = jest.fn(async (sql, params) => rowsByQuery(sql, params));
    const repo = new WorklogControlRepository({ query, tableReady: async () => true });
    return { repo, query };
  };

  it('첫 페이지 — 두 원천 모두 since ≤ updated_at < until, 안정 정렬, LIMIT', async () => {
    const { repo, query } = build(() => ({ rows: [] }));
    const out = await repo.listConfirmChangesPage({ since: NOW - 60_000, until: NOW, limit: 200 });
    expect(out).toEqual({ ids: [], certCursor: false, sheetCursor: false });
    const [certSql, certParams] = query.mock.calls[0];
    const [sheetSql] = query.mock.calls[1];
    expect(certSql.replace(/\s+/g, ' ')).toMatch(/WHERE updated_at >= \? AND updated_at < \? ORDER BY updated_at, worklog_id LIMIT 200/);
    expect(certParams).toHaveLength(2);
    expect(sheetSql.replace(/\s+/g, ' ')).toMatch(/ORDER BY q\.updated_at, q\.request_id, r\.worklog_id LIMIT 200/);
    expect(sheetSql).not.toMatch(/q\.request_id > UUID_TO_BIN/);
  });

  it('가득 찬 페이지는 마지막 행으로 커서를 만들고, 다음 호출은 keyset 조건을 붙인다(같은 timestamp 는 id 로 가른다)', async () => {
    const certRows = Array.from({ length: 2 }, (_, i) => ({ worklog_id: String(10 + i), updated_at: '2026-10-28 00:00:00' }));
    const { repo, query } = build((sql) => (sql.includes('worklog_cert') ? { rows: certRows } : { rows: [] }));
    const first = await repo.listConfirmChangesPage({ since: NOW - 60_000, until: NOW, limit: 2 });
    expect(first.ids).toEqual(['10', '11']);
    expect(first.certCursor).toEqual({ at: expect.any(Number), id: '11' });
    expect(first.sheetCursor).toBe(false);

    query.mockClear();
    await repo.listConfirmChangesPage({ since: NOW - 60_000, until: NOW, certCursor: first.certCursor, sheetCursor: false, limit: 2 });
    expect(query).toHaveBeenCalledTimes(1); // 끝난 원천(false)은 SQL 0
    const [sql, params] = query.mock.calls[0];
    expect(sql.replace(/\s+/g, ' ')).toMatch(/AND \(updated_at > \? OR \(updated_at = \? AND worklog_id > \?\)\)/);
    expect(params.slice(-1)).toEqual(['11']);
  });

  it('타임시트 커서는 (updated_at, request_id, worklog_id) 세 키', async () => {
    const { repo, query } = build(() => ({ rows: [] }));
    await repo.listConfirmChangesPage({
      since: NOW - 60_000, until: NOW, certCursor: false, sheetCursor: { at: NOW - 500, requestId: '11111111-1111-4111-8111-111111111111', id: '42' }, limit: 200,
    });
    const [sql, params] = query.mock.calls[0];
    expect(sql.replace(/\s+/g, ' ')).toMatch(/q\.request_id > UUID_TO_BIN\(\?\) OR \(q\.request_id = UUID_TO_BIN\(\?\) AND r\.worklog_id > \?\)/);
    expect(params.slice(-3)).toEqual(['11111111-1111-4111-8111-111111111111', '11111111-1111-4111-8111-111111111111', '42']);
  });
});
