import { InboxService } from '../InboxService';
import { visibilityKeyOf } from '../../approval/target/filterVisibleRows';

/**
 * 2026-10-28 전수 점검 R11 — 권한 판정 장애를 "정상적인 빈 업무함"으로 보여 주고 커서까지 전진시켰다.
 * 지금은 fail-close 를 유지하면서 `incomplete:true` 로 표시한다. 판정이 던지면 그 창부터 멈추고 커서를 창 시작에 둔다(건너뛰는 행 없음).
 * 종류별 부분 실패(permission.incomplete)는 보이는 행을 내보내고 표시만 한다(기존 계약).
 */
const ID = '11111111-1111-4111-8111-111111111111';
const ID2 = '22222222-2222-4222-8222-222222222222';
const row = (id, at = '2026-10-28 00:00:00', targetKey = '100') => ({
  request_id: id, target_kind: 'ISSUE', target_key: targetKey, updated_at: at, status: 'PENDING', actor_key: 'viewer',
});

const build = ({ pages, permissionFilter }) => new InboxService({
  repository: { page: jest.fn(async () => pages.shift() ?? []), updateSnapshot: jest.fn(async () => ({})) },
  permissionFilter,
  delegations: { activeDelegatorsOf: async () => [] },
  worklogSnapshots: async () => new Map(),
});
const request = (payload = {}) => ({ principal: { accountId: 'viewer' }, payload: { tab: 'myturn', ...payload } });

describe('listInbox — 권한 판정 미완료', () => {
  it('판정 예외 → items 빈 채로 incomplete:true, hasMore:true(끝에 닿지 않음), nextCursor 는 멈춘 자리', async () => {
    const service = build({ pages: [[row(ID)]], permissionFilter: async () => { throw new Error('SIMULATED_PERMISSION_OUTAGE'); } });
    const out = await service.listInbox(request());
    expect(out).toMatchObject({ items: [], hasMore: true, incomplete: true, limit: 20 });
  });

  it('두 번째 창에서 예외 — 첫 창의 보이는 행은 돌려주고, 커서는 두 번째 창 시작(첫 창 끝)에 멈춘다', async () => {
    // 기본 limit 20 → 첫 창 30. 첫 창을 30행으로 가득 채워(끝 아님) 두 번째 창에서 던지게 한다.
    const first = Array.from({ length: 30 }, (_, i) => row(
      ID.replace('1111-1111-4111', `1111-${String(1000 + i)}-4111`), `2026-10-28 00:00:${String(i).padStart(2, '0')}`, String(100 + i),
    ));
    let calls = 0;
    const service = build({
      pages: [first, [row(ID2, '2026-10-28 00:01:00', '900')]],
      permissionFilter: async (rows) => {
        calls += 1;
        if (calls === 2) throw new Error('SIMULATED_PERMISSION_OUTAGE');
        // 첫 창은 앞 3행만 보이게
        return { visible: new Set(rows.slice(0, 3).map(visibilityKeyOf)), meta: new Map(), incomplete: false };
      },
    });
    const out = await service.listInbox(request());
    expect(out.incomplete).toBe(true);
    expect(out.hasMore).toBe(true);
    expect(out.items).toHaveLength(3);
    // 커서 = 첫 창 마지막 행(두 번째 창의 시작) — 두 번째 창의 행은 건너뛰지 않고 다음 요청이 다시 본다.
    const cursor = JSON.parse(Buffer.from(out.nextCursor, 'base64url').toString('utf8'));
    expect(cursor).toMatchObject({ r: first.at(-1).request_id });
  });

  it('종류별 부분 실패(permission.incomplete) — 보이는 행은 내보내고 incomplete 만 표시, 스캔은 그대로 끝까지', async () => {
    const rows = [row(ID), row(ID2, '2026-10-28 00:00:01', '101')];
    const service = build({
      pages: [rows],
      permissionFilter: async () => ({ visible: new Set([visibilityKeyOf(rows[0])]), meta: new Map(), incomplete: true }),
    });
    const out = await service.listInbox(request());
    expect(out.items.map((item) => item.request_id)).toEqual([ID]);
    expect(out).toMatchObject({ incomplete: true, hasMore: false, nextCursor: null });
  });

  it('정상 판정이면 incomplete 키가 없다(기존 계약 그대로)', async () => {
    const service = build({ pages: [[]], permissionFilter: async () => ({ visible: new Set(), meta: new Map(), incomplete: false }) });
    expect(await service.listInbox(request())).toEqual({ items: [], nextCursor: null, hasMore: false, limit: 20 });
  });
});
