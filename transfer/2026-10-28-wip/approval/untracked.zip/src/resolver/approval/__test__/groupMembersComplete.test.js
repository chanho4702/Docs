import * as requestJira from '../../../api/jira/RequestJira';
import { ApprovalService, loadGroupMembersByName } from '../ApprovalService';
import { ErrorCodes } from '../../../utils/errors/ErrorCodes';

/**
 * 2026-10-28 전수 점검 R12 — Jira 그룹 조회가 두 번째 페이지에서 403 을 받으면 첫 페이지 인원만으로 명부를 만들고,
 * 전원 승인(requireAll) 그룹의 requiredApprovals 가 그 길이로 정해졌다. 명부는 끝까지 읽었을 때만 쓴다.
 */
const page = (ids, isLast) => ({ status: 200, body: { values: ids.map((id) => ({ accountId: id, active: true, accountType: 'atlassian' })), isLast } });

describe('loadGroupMembersByName — 끝까지 읽은 명부만', () => {
  afterEach(() => jest.restoreAllMocks());

  it('두 페이지를 끝까지 읽으면 합쳐서(중복 제거) 돌려준다', async () => {
    jest.spyOn(requestJira, 'asUser')
      .mockResolvedValueOnce(page(['a', 'b'], false))
      .mockResolvedValueOnce(page(['b', 'c'], true));
    expect(await loadGroupMembersByName('reviewers')).toEqual(['a', 'b', 'c']);
    expect(requestJira.asUser).toHaveBeenCalledTimes(2);
  });

  it('첫 페이지부터 403(조회 권한 없음)·404(없는 그룹)는 기존 계약대로 빈 명부', async () => {
    jest.spyOn(requestJira, 'asUser').mockResolvedValueOnce({ status: 403, body: {} });
    expect(await loadGroupMembersByName('reviewers')).toEqual([]);
    jest.spyOn(requestJira, 'asUser').mockResolvedValueOnce({ status: 404, body: {} });
    expect(await loadGroupMembersByName('missing')).toEqual([]);
  });

  it('두 번째 페이지가 403 이면 일부 명부를 돌려주지 않고 INVALID_APPROVER_CONFIGURATION(GROUP_MEMBERS_INCOMPLETE)', async () => {
    jest.spyOn(requestJira, 'asUser')
      .mockResolvedValueOnce(page(['first-member'], false))
      .mockResolvedValueOnce({ status: 403, body: {} });
    await expect(loadGroupMembersByName('all-reviewers')).rejects.toMatchObject({
      code: ErrorCodes.INVALID_APPROVER_CONFIGURATION,
      cause: { reason: 'GROUP_MEMBERS_INCOMPLETE', group: 'all-reviewers', status: 403, page: 1 },
    });
  });

  it('페이지 상한(20)에 닿아도 isLast 가 아니면 미확정 — 던진다', async () => {
    const spy = jest.spyOn(requestJira, 'asUser');
    for (let i = 0; i < 20; i += 1) spy.mockResolvedValueOnce(page([`u${i}`], false));
    await expect(loadGroupMembersByName('huge')).rejects.toMatchObject({
      code: ErrorCodes.INVALID_APPROVER_CONFIGURATION, cause: { reason: 'GROUP_MEMBERS_INCOMPLETE', page: 20, limit: 1000 },
    });
    expect(spy).toHaveBeenCalledTimes(20);
  });

  it('마지막이 아니라는데 빈 페이지(isLast:false, values:[])는 미확정 — 앞 페이지만으로 확정하지 않는다(Codex P2)', async () => {
    jest.spyOn(requestJira, 'asUser')
      .mockResolvedValueOnce(page(['a'], false))
      .mockResolvedValueOnce(page([], false));
    await expect(loadGroupMembersByName('gap')).rejects.toMatchObject({ cause: { reason: 'GROUP_MEMBERS_INCOMPLETE', shape: 'empty-page', page: 1 } });
    // 마지막 페이지가 비어 있는 것(isLast:true)은 정상 끝
    jest.spyOn(requestJira, 'asUser')
      .mockResolvedValueOnce(page(['a'], false))
      .mockResolvedValueOnce(page([], true));
    expect(await loadGroupMembersByName('tail')).toEqual(['a']);
  });

  it('응답 모양이 다르면(values 배열 아님) 미확정', async () => {
    jest.spyOn(requestJira, 'asUser')
      .mockResolvedValueOnce(page(['a'], false))
      .mockResolvedValueOnce({ status: 200, body: { unexpected: true } });
    await expect(loadGroupMembersByName('odd')).rejects.toMatchObject({ cause: { reason: 'GROUP_MEMBERS_INCOMPLETE', shape: 'values' } });
  });
});

describe('ApprovalService.expandApprovalGroup — 전원 승인 그룹은 완전한 명부로만', () => {
  afterEach(() => jest.restoreAllMocks());
  const service = () => new ApprovalService({
    groupMemberByNameLoader: loadGroupMembersByName,
    approvalGroups: { findByKey: async () => ({ enabled: true, type: 'JIRA', groupKey: 'all-reviewers', requireAll: true }) },
  });

  it('두 번째 페이지 403 → 단계가 만들어지지 않는다(이전: 첫 페이지 인원만으로 requiredApprovals 1)', async () => {
    jest.spyOn(requestJira, 'asUser')
      .mockResolvedValueOnce(page(['first-member'], false))
      .mockResolvedValueOnce({ status: 403, body: {} });
    await expect(service().expandApprovalGroup('all-reviewers')).rejects.toMatchObject({ code: ErrorCodes.INVALID_APPROVER_CONFIGURATION });
  });

  it('끝까지 읽으면 전원 수 = requiredApprovals', async () => {
    jest.spyOn(requestJira, 'asUser')
      .mockResolvedValueOnce(page(['a', 'b'], false))
      .mockResolvedValueOnce(page(['c'], true));
    expect(await service().expandApprovalGroup('all-reviewers')).toMatchObject({ approverKeys: ['a', 'b', 'c'], requiredApprovals: 3 });
  });

  it('참조(CC) 확장은 best-effort — 미확정 명부는 빈 목록으로 삼키고 요청을 막지 않는다', async () => {
    jest.spyOn(requestJira, 'asUser')
      .mockResolvedValueOnce(page(['a'], false))
      .mockResolvedValueOnce({ status: 500, body: {} });
    const cc = new ApprovalService({
      groupMemberByNameLoader: loadGroupMembersByName,
      approvalGroups: { findByKey: async () => ({ enabled: true, type: 'JIRA', groupKey: 'watchers', requireAll: false }) },
    });
    expect(await cc.expandCc(['agroup:watchers', 'direct-user'])).toEqual(['direct-user']);
  });
});
