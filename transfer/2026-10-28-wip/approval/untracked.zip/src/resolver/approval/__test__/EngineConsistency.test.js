/**
 * 승인 엔진 결정 저장 경로의 동시 실행·중간 실패 정합성(full-audit-2026-10-28 R01~R04).
 * 실제 ApprovalRepository(load 포함) + 상태를 가진 SQL 모의(조건부 UPDATE 의 WHERE 를 흉내 낸다).
 * 설계 `_workspace/full-audit-2026-10-28/engine-fix-design.md` §5.
 */
import { ApprovalRepository } from '../ApprovalRepository';
import { InboxRepository } from '../../inbox/InboxRepository';
import { deriveStatus } from '../../../domain/approval/derive';
import { approve as approveTransition } from '../../../domain/approval/transitions';
import { fromSqlTimestamp, toSqlTimestamp as ts } from '../../../rdb/query/SqlTime';
import { deterministicEventId } from '../../../domain/approval/eventId';

const ID = '11111111-1111-4111-8111-111111111111';
const NOW = 1_700_000_000_000; // 초 경계 — decided_at 은 초 단위로 저장된다.

const compact = (sql) => sql.replace(/\s+/g, ' ').trim();

const deferred = () => {
  let resolve;
  const promise = new Promise((done) => { resolve = done; });
  return { promise, resolve };
};

/**
 * @param steps [{ approvers: ['a','b'], required: 1 }]
 * @param decided { actorKey: 'APPROVE' } — 미리 결정된 행(앞 단계 등)
 */
const makeHarness = ({
  steps = [{ approvers: ['a', 'b'], required: 1 }],
  decided = {},
  currentStepOrder = 1,
  expiresAt = null,
  ignoreParentGuard = false,
  ignoreCount = false,
  hooks = {},
  failures = {},
} = {}) => {
  const db = {
    request: {
      status: 'PENDING', rev: 2, current_step_order: currentStepOrder, commit_state: 'LIVE',
      created_at: ts(NOW), updated_at: ts(NOW), current_step_opened_at: ts(NOW),
      expires_at: expiresAt ? ts(expiresAt) : null, current_step_name: null,
    },
    approvers: [],
    events: [],
    inbox: [],
  };
  steps.forEach((step, index) => step.approvers.forEach((actor) => {
    db.approvers.push({
      step_order: index + 1, actor_key: actor, step_required: step.required,
      decision_type: decided[actor] ?? 'PENDING', decided_at: decided[actor] ? ts(NOW) : null,
      via_group: null, step_name: null,
    });
    db.inbox.push({
      actor_key: actor, role: 'APPROVER', step_order: index + 1,
      my_turn: index + 1 === currentStepOrder ? 1 : 0, my_decided: decided[actor] ? 1 : 0,
      req_rev: 2, status: 'PENDING', is_open: 1, current_step_order: currentStepOrder,
    });
  }));
  db.inbox.push({
    actor_key: 'owner', role: 'REQUESTER', step_order: null, my_turn: 0, my_decided: 0,
    req_rev: 2, status: 'PENDING', is_open: 1, current_step_order: currentStepOrder,
  });

  const log = [];
  const casAttempts = [];
  const remaining = { ...failures };
  const failOnce = (key) => {
    if (remaining[key] > 0) {
      remaining[key] -= 1;
      throw new Error(`SIMULATED_${key.toUpperCase()}_FAILURE`);
    }
  };
  const decidedCount = () => db.approvers.filter((row) => row.decision_type !== 'PENDING').length;

  const execute = jest.fn(async (sql, values = []) => {
    const q = compact(sql);
    log.push({ q, values });
    if (q.startsWith('SELECT BIN_TO_UUID(request_id) AS request_id, target_kind')) {
      if (db.request.commit_state !== 'LIVE') return { rows: [] };
      return {
        rows: [{
          request_id: ID, target_kind: 'WORKLOG_CERTIFICATION', target_key: 'w-1', status: db.request.status,
          content_version: 1, revision: 1, step_count: steps.length,
          current_step_order: db.request.current_step_order,
          current_step_opened_at: db.request.current_step_opened_at,
          created_at: db.request.created_at, updated_at: db.request.updated_at,
          expires_at: db.request.expires_at, requester_key: 'owner', rev: db.request.rev,
          current_step_name: db.request.current_step_name,
        }],
      };
    }
    if (q.startsWith('SELECT step_order, actor_key')) {
      const rows = db.approvers.map((row) => ({ ...row }));
      await hooks.onApproverSelect?.(rows);
      return { rows };
    }
    if (q.startsWith('SELECT BIN_TO_UUID(event_id)')) return { rows: db.events.map((row) => ({ ...row })) };
    if (q.startsWith('SELECT my_decided, req_rev FROM approval_inbox')) {
      const [, actor] = values;
      const row = db.inbox.find((item) => item.actor_key === actor && item.role === 'APPROVER');
      return { rows: row ? [{ my_decided: row.my_decided, req_rev: row.req_rev }] : [] };
    }
    if (q.startsWith('UPDATE approval_approver SET decision_type=?, decided_at=?')) {
      const [decisionType, decidedAt, , stepOrder, actor] = values;
      await hooks.beforeClaim?.(actor, db);
      const row = db.approvers.find((item) => item.actor_key === actor && item.step_order === stepOrder);
      const parentOpen = ignoreParentGuard || (db.request.status === 'PENDING' && db.request.commit_state === 'LIVE');
      if (!row || row.decision_type !== 'PENDING' || !parentOpen) return { rowsAffected: 0 };
      Object.assign(row, { decision_type: decisionType, decided_at: decidedAt });
      await hooks.afterClaim?.(actor, db);
      return { rowsAffected: 1 };
    }
    if (q.startsWith("UPDATE approval_approver SET decision_type='PENDING', decided_at=NULL")) {
      const [, stepOrder, actor, decisionType, decidedAt] = values;
      const row = db.approvers.find((item) => item.actor_key === actor && item.step_order === stepOrder);
      if (!row || row.decision_type !== decisionType || row.decided_at !== decidedAt) return { rowsAffected: 0 };
      Object.assign(row, { decision_type: 'PENDING', decided_at: null });
      return { rowsAffected: 1 };
    }
    if (q.startsWith('INSERT INTO approval_event')) {
      failOnce('event');
      const [, eventId, eventType, actorKey, delegateKey, occurredAt, reason, contentVersion] = values;
      await hooks.afterEvent?.(actorKey, db);
      if (db.events.some((row) => row.event_id === eventId)) return { rowsAffected: 0 };
      db.events.push({
        event_id: eventId, event_type: eventType, actor_key: actorKey, delegate_key: delegateKey,
        occurred_at: occurredAt, reason, content_version: contentVersion,
      });
      return { rowsAffected: 1 };
    }
    if (q.startsWith('DELETE FROM approval_event')) {
      const [, eventId] = values;
      await hooks.beforeDelete?.(eventId, db);
      if (q.includes("r.status='PENDING'") && db.request.status !== 'PENDING') return { rowsAffected: 0 };
      const before = db.events.length;
      db.events = db.events.filter((row) => row.event_id !== eventId);
      return { rowsAffected: before - db.events.length };
    }
    if (q.startsWith('UPDATE approval_request')) {
      const [status, isOpen, stepOrder, openedAt, , updatedAt, stepName, , expectedRev, countBinding] = values;
      await hooks.beforeCas?.(status, db);
      failOnce('cas');
      const attempt = { status, ok: false, reason: null, count: countBinding };
      casAttempts.push(attempt);
      if (db.request.rev !== expectedRev) { attempt.reason = 'rev'; return { rowsAffected: 0 }; }
      if (db.request.status !== 'PENDING') { attempt.reason = 'status'; return { rowsAffected: 0 }; }
      if (q.includes('SELECT COUNT(*) FROM approval_approver') && !ignoreCount && decidedCount() !== countBinding) {
        attempt.reason = 'count';
        return { rowsAffected: 0 };
      }
      Object.assign(db.request, {
        status, current_step_order: stepOrder, current_step_opened_at: openedAt, updated_at: updatedAt,
        current_step_name: stepName, rev: db.request.rev + 1,
      });
      attempt.ok = true;
      await hooks.afterCas?.(status, db);
      return { rowsAffected: 1 };
    }
    if (q.startsWith('UPDATE approval_inbox SET my_decided=1')) {
      failOnce('projection');
      const [, actor] = values;
      const rows = db.inbox.filter((item) => item.actor_key === actor && item.role === 'APPROVER');
      rows.forEach((row) => { row.my_decided = 1; row.my_turn = 0; });
      return { rowsAffected: rows.length };
    }
    if (q.startsWith('UPDATE approval_inbox SET status=?')) {
      failOnce('projection');
      const [status, isOpen, stepOrder, , , reqRev, turnOpen, turnStep, , revGuard] = values;
      const rows = db.inbox.filter((row) => row.req_rev <= revGuard);
      rows.forEach((row) => {
        Object.assign(row, {
          status, is_open: isOpen, current_step_order: stepOrder, req_rev: reqRev,
          my_turn: turnOpen === 1 && row.role === 'APPROVER' && row.step_order === turnStep && row.my_decided === 0 ? 1 : 0,
        });
      });
      return { rowsAffected: rows.length };
    }
    throw new Error(`UNEXPECTED_QUERY ${q}`);
  });

  const repo = new ApprovalRepository({
    execute, tableReady: async () => true, columnReady: async () => true,
    sleep: async () => {}, jitter: () => 0,
  });
  const decisionsMap = () => new Map(db.approvers.map((row) => [row.actor_key, {
    decisionType: row.decision_type, decidedAt: fromSqlTimestamp(row.decided_at),
  }]));
  const restoredSteps = () => steps.map((step, index) => ({
    stepOrder: index + 1, approverKeys: step.approvers, requiredApprovals: step.required,
  }));
  const writes = (from = 0) => log.slice(from).filter(({ q }) => /^(UPDATE|INSERT|DELETE)/.test(q));
  return {
    repo, db, log, casAttempts, execute, writes, decisionsMap, restoredSteps,
  };
};

const approveInput = (actorKey, now = NOW + 1000) => ({ requestId: ID, actorKey, now });
const rejectInput = (actorKey, now = NOW + 1000) => ({
  requestId: ID, actorKey, now, reason: '반려 사유', reasonRequired: true,
});

const expectConsistent = (h) => {
  expect(h.db.request.status).toBe(deriveStatus(h.restoredSteps(), h.decisionsMap()));
};

describe('R01 결정 수락과 최종 확정의 결속', () => {
  it('① a APPROVE·b REJECT 동시(1명 통과) — a 의 APPROVED CAS 는 결정 수 조건으로 지고, 최종은 결정 전체의 파생 REJECTED 다', async () => {
    const initialLoads = deferred();
    const aReloaded = deferred();
    const bClaimed = deferred();
    let approverSelects = 0;
    const h = makeHarness({
      hooks: {
        onApproverSelect: async () => {
          approverSelects += 1;
          if (approverSelects === 2) initialLoads.resolve();
          if (approverSelects === 3) aReloaded.resolve();
        },
        beforeClaim: async (actor) => {
          if (actor === 'a') await initialLoads.promise;
          if (actor === 'b') await aReloaded.promise;
        },
        afterClaim: async (actor) => { if (actor === 'b') bClaimed.resolve(); },
        beforeCas: async (status) => { if (status === 'APPROVED') await bClaimed.promise; },
      },
    });

    const [a, b] = await Promise.all([
      h.repo.approve(approveInput('a')),
      h.repo.reject(rejectInput('b')),
    ]);

    expect(h.db.request.status).toBe('REJECTED');
    expectConsistent(h);
    // a 는 b 의 클레임 전 스냅숏(결정 1)으로 APPROVED 를 계산했지만 실제 결정 수 2 와 달라 졌다.
    expect(h.casAttempts).toContainEqual(expect.objectContaining({ status: 'APPROVED', ok: false, reason: 'count', count: 1 }));
    // APPROVED 가 저장되는 순간이 없고, 종료 CAS 는 정확히 1회 성공한다.
    expect(h.casAttempts.filter((item) => item.ok)).toEqual([expect.objectContaining({ status: 'REJECTED' })]);
    expect(a.status).toBe('REJECTED');
    expect(b.status).toBe('REJECTED');
    // 둘 다 반영된 결정이라 두 이벤트가 남는다(반려 사유 포함).
    expect(h.db.events.map((row) => [row.actor_key, row.event_type, row.reason]).sort()).toEqual([
      ['a', 'APPROVED', null], ['b', 'REJECTED', '반려 사유'],
    ]);
    expect(h.db.inbox.filter((row) => row.role === 'APPROVER').map((row) => [row.actor_key, row.my_decided, row.my_turn, row.status]))
      .toEqual([['a', 1, 0, 'REJECTED'], ['b', 1, 0, 'REJECTED']]);
  });

  it('② 종료 뒤 늦은 클레임이 통과한 척(부모 PENDING 조건 우회) — REJECT 는 클레임을 되돌리고 ALREADY_DECIDED', async () => {
    const h = makeHarness({
      ignoreParentGuard: true,
      hooks: {
        beforeClaim: async (actor, db) => {
          if (actor !== 'b') return;
          // b 가 PENDING 을 읽은 뒤 a 의 승인이 먼저 확정됐다.
          Object.assign(db.approvers.find((row) => row.actor_key === 'a'), { decision_type: 'APPROVE', decided_at: ts(NOW) });
          Object.assign(db.request, { status: 'APPROVED', current_step_order: 2, rev: db.request.rev + 1 });
        },
      },
    });

    await expect(h.repo.reject(rejectInput('b'))).rejects.toMatchObject({ code: 'ALREADY_DECIDED' });

    expect(h.db.approvers.find((row) => row.actor_key === 'b')).toMatchObject({ decision_type: 'PENDING', decided_at: null });
    expect(h.writes().filter(({ q }) => q.startsWith("UPDATE approval_approver SET decision_type='PENDING'"))).toHaveLength(1);
    // 이번 호출은 이벤트를 쓰기 전에 종료를 봤다 — 거둘 이벤트가 없다.
    expect(h.writes().some(({ q }) => q.startsWith('DELETE FROM approval_event'))).toBe(false);
    expect(h.db.events).toEqual([]);
    expect(h.db.request.status).toBe('APPROVED');
    expectConsistent(h);
  });

  it('② 좁은 창 시뮬레이션(결정 수 조건까지 우회) — 이벤트까지 쓴 늦은 반려는 클레임 되돌림 + 이벤트 DELETE + ALREADY_DECIDED', async () => {
    const initialLoads = deferred();
    const aReloaded = deferred();
    const bEventWritten = deferred();
    const aCasDone = deferred();
    let approverSelects = 0;
    const h = makeHarness({
      ignoreCount: true,
      hooks: {
        onApproverSelect: async () => {
          approverSelects += 1;
          if (approverSelects === 2) initialLoads.resolve();
          if (approverSelects === 3) aReloaded.resolve();
        },
        beforeClaim: async (actor) => {
          if (actor === 'a') await initialLoads.promise;
          if (actor === 'b') await aReloaded.promise;
        },
        afterEvent: async (actor) => { if (actor === 'b') bEventWritten.resolve(); },
        beforeCas: async (status) => {
          if (status === 'APPROVED') await bEventWritten.promise;
          if (status === 'REJECTED') await aCasDone.promise;
        },
        afterCas: async (status) => { if (status === 'APPROVED') aCasDone.resolve(); },
      },
    });

    const [a, b] = await Promise.allSettled([
      h.repo.approve(approveInput('a')),
      h.repo.reject(rejectInput('b')),
    ]);

    expect(a).toMatchObject({ status: 'fulfilled', value: expect.objectContaining({ status: 'APPROVED' }) });
    expect(b).toMatchObject({ status: 'rejected', reason: expect.objectContaining({ code: 'ALREADY_DECIDED' }) });
    expect(h.db.approvers.find((row) => row.actor_key === 'b').decision_type).toBe('PENDING');
    expect(h.writes().filter(({ q }) => q.startsWith('DELETE FROM approval_event'))).toHaveLength(1);
    expect(h.db.events.map((row) => row.event_type)).toEqual(['APPROVED']);
    expectConsistent(h);
  });

  it('③ 2명 전원 승인 단계(requiredApprovals 2)에서 a·b 동시 APPROVE — 둘 다 성공, 최종 APPROVED·currentStepOrder 3', async () => {
    const bothClaimed = deferred();
    let claims = 0;
    const h = makeHarness({
      steps: [{ approvers: ['x'], required: 1 }, { approvers: ['a', 'b'], required: 2 }],
      decided: { x: 'APPROVE' },
      currentStepOrder: 2,
      hooks: {
        afterClaim: async () => {
          claims += 1;
          if (claims === 2) bothClaimed.resolve();
          await bothClaimed.promise;
        },
      },
    });

    const [a, b] = await Promise.all([h.repo.approve(approveInput('a')), h.repo.approve(approveInput('b'))]);

    expect(a).toMatchObject({ status: 'APPROVED', currentStepOrder: 3 });
    expect(b).toMatchObject({ status: 'APPROVED', currentStepOrder: 3 });
    expect(h.db.request).toMatchObject({ status: 'APPROVED', current_step_order: 3 });
    expectConsistent(h);
    expect(h.casAttempts.filter((item) => item.ok)).toHaveLength(1);
    expect(h.db.events.map((row) => row.actor_key).sort()).toEqual(['a', 'b']);
    expect(h.db.inbox.filter((row) => ['a', 'b'].includes(row.actor_key)).map((row) => [row.my_decided, row.my_turn]))
      .toEqual([[1, 0], [1, 0]]);
  });

  it('④ 클레임 SQL 에 부모 PENDING·LIVE EXISTS, 결정 CAS SQL 에 결정 수 조건과 그 바인딩이 있다', async () => {
    const h = makeHarness();

    await h.repo.approve(approveInput('a'));

    const claim = h.log.find(({ q }) => q.startsWith('UPDATE approval_approver SET decision_type=?'));
    expect(claim.q).toContain("AND EXISTS (SELECT 1 FROM approval_request r WHERE r.request_id=approval_approver.request_id AND r.status='PENDING' AND r.commit_state='LIVE')");
    expect(claim.q).toContain("AND decision_type='PENDING'");
    const cas = h.log.find(({ q }) => q.startsWith('UPDATE approval_request'));
    expect(cas.q).toContain("AND (SELECT COUNT(*) FROM approval_approver p WHERE p.request_id=approval_request.request_id AND p.decision_type <> 'PENDING') = ?");
    expect(cas.q).toMatch(/rev = rev \+ 1/);
    expect(cas.values.at(-2)).toBe(2); // expected rev
    expect(cas.values.at(-1)).toBe(1); // 스냅숏 결정 수(a 의 클레임)
  });

  it('④ 회수·만료 CAS 에는 결정 수 조건을 걸지 않는다', async () => {
    const h = makeHarness({ expiresAt: NOW + 500 });

    await h.repo.cancel({ requestId: ID, actorKey: 'owner', now: NOW + 1000 });

    const cas = h.log.find(({ q }) => q.startsWith('UPDATE approval_request'));
    expect(cas.q).not.toContain('COUNT(*)');
    expect(cas.values).toHaveLength(9);
  });

  it('재계산한 aggregate 는 도메인 전이의 next 와 같다(다단계 중간 승인)', async () => {
    const h = makeHarness({ steps: [{ approvers: ['a'], required: 1 }, { approvers: ['c'], required: 1 }] });
    const before = await h.repo.load(ID);
    const domainNext = approveTransition(before, { actorKey: 'a', now: NOW + 1000 }).next;

    const state = await h.repo.approve(approveInput('a'));

    const cas = h.log.find(({ q }) => q.startsWith('UPDATE approval_request'));
    expect(cas.values.slice(0, 4)).toEqual([domainNext.status, 1, domainNext.currentStepOrder, ts(domainNext.currentStepOpenedAt)]);
    expect(state).toMatchObject({ status: 'PENDING', currentStepOrder: 2, rev: 3 });
    expect(h.db.inbox.find((row) => row.actor_key === 'c')).toMatchObject({ my_turn: 1, req_rev: 3 });
    expect(h.db.inbox.find((row) => row.actor_key === 'a')).toMatchObject({ my_turn: 0, my_decided: 1 });
  });
});

describe('R02 재시도 수렴', () => {
  it('① 클레임 뒤 이벤트 INSERT 실패 → 같은 사용자 재시도가 이벤트·aggregate·투영을 마저 채운다', async () => {
    const h = makeHarness({ failures: { event: 1 } });

    await expect(h.repo.approve(approveInput('a'))).rejects.toThrow('SIMULATED_EVENT_FAILURE');
    expect(h.db.request.status).toBe('PENDING');

    const retry = await h.repo.approve(approveInput('a', NOW + 5000));

    expect(retry.status).toBe('APPROVED');
    expect(h.db.request.status).toBe('APPROVED');
    expectConsistent(h);
    expect(h.db.events.map((row) => [row.actor_key, row.event_type])).toEqual([['a', 'APPROVED']]);
    // 발생 시각은 결재자 행의 결정 시각(재시도 시각이 아니다).
    expect(h.db.events[0].occurred_at).toBe(ts(NOW + 1000));
    expect(h.db.inbox.find((row) => row.actor_key === 'a')).toMatchObject({ my_decided: 1, status: 'APPROVED', is_open: 0, req_rev: 3 });
    // 클레임은 다시 발행하지 않는다.
    expect(h.writes().filter(({ q }) => q.startsWith('UPDATE approval_approver'))).toHaveLength(1);
  });

  it('② 이벤트까지 쓰고 CAS 전에 끊김 → 재시도 수렴(이벤트 1건)', async () => {
    const h = makeHarness({ failures: { cas: 1 } });

    await expect(h.repo.approve(approveInput('a'))).rejects.toThrow('SIMULATED_CAS_FAILURE');
    expect(h.db.events).toHaveLength(1);

    const retry = await h.repo.approve(approveInput('a', NOW + 5000));

    expect(retry).toMatchObject({ status: 'APPROVED', currentStepOrder: 2 });
    expectConsistent(h);
    expect(h.db.events).toHaveLength(1);
    expect(h.db.inbox.find((row) => row.actor_key === 'a')).toMatchObject({ my_decided: 1, status: 'APPROVED' });
  });

  it('③ CAS 까지 성공하고 투영에서 끊김 → 재시도는 업무함 투영만 다시 쓴다(같은 세대 재투영)', async () => {
    const h = makeHarness({ failures: { projection: 1 } });

    await expect(h.repo.approve(approveInput('a'))).rejects.toThrow('SIMULATED_PROJECTION_FAILURE');
    expect(h.db.request.status).toBe('APPROVED');
    expect(h.db.inbox.find((row) => row.actor_key === 'a')).toMatchObject({ my_decided: 0, status: 'PENDING' });
    const mark = h.log.length;

    const retry = await h.repo.approve(approveInput('a', NOW + 5000));

    expect(retry.status).toBe('APPROVED');
    const retryWrites = h.writes(mark).map(({ q }) => q);
    expect(retryWrites).toEqual([
      expect.stringMatching(/^UPDATE approval_inbox SET my_decided=1, my_turn=0 /),
      expect.stringMatching(/^UPDATE approval_inbox SET status=\?, is_open=\?/),
    ]);
    expect(h.log.slice(mark).some(({ q }) => q.startsWith('SELECT my_decided, req_rev FROM approval_inbox'))).toBe(true);
    expect(h.db.inbox.find((row) => row.actor_key === 'a')).toMatchObject({ my_decided: 1, status: 'APPROVED', is_open: 0, req_rev: 3 });
    expect(h.db.events).toHaveLength(1);
  });

  it('④ 진짜 멱등(아무것도 빠지지 않음) → 쓰기 0(load 3 + 업무함 확인 SELECT 1)', async () => {
    const h = makeHarness();
    await h.repo.approve(approveInput('a'));
    const mark = h.log.length;

    const retry = await h.repo.approve(approveInput('a', NOW + 5000));

    expect(retry.status).toBe('APPROVED');
    expect(h.writes(mark)).toEqual([]);
    expect(h.log.slice(mark)).toHaveLength(4);
  });

  it('⑤ 반려도 같다 — 클레임 뒤 이벤트 실패 → 같은 입력의 재시도가 사유를 담은 이벤트와 REJECTED 를 확정한다', async () => {
    const h = makeHarness({ failures: { event: 1 } });

    await expect(h.repo.reject(rejectInput('b'))).rejects.toThrow('SIMULATED_EVENT_FAILURE');
    const retry = await h.repo.reject(rejectInput('b', NOW + 5000));

    expect(retry.status).toBe('REJECTED');
    expectConsistent(h);
    expect(h.db.events.map((row) => [row.event_type, row.reason])).toEqual([['REJECTED', '반려 사유']]);
  });

});

describe('R03 투영 세대 가드·내 차례', () => {
  it('① 투영은 my_decided 문장이 먼저이고 aggregate 문장에 req_rev <= ? 와 my_decided = 0 이 있다', async () => {
    const h = makeHarness();

    await h.repo.updateProjection({
      requestId: ID, status: 'PENDING', isOpen: 1, currentStepOrder: 1, updatedAt: NOW, reqRev: 3, actorKey: 'a',
    });

    expect(h.log.map(({ q }) => q)).toEqual([
      "UPDATE approval_inbox SET my_decided=1, my_turn=0 WHERE request_id=UUID_TO_BIN(?) AND actor_key=? AND role='APPROVER'",
      "UPDATE approval_inbox SET status=?, is_open=?, current_step_order=?, current_step_name=?, updated_at=?, req_rev=?, my_turn = CASE WHEN ? = 1 AND role='APPROVER' AND step_order = ? AND my_decided = 0 THEN 1 ELSE 0 END WHERE request_id=UUID_TO_BIN(?) AND req_rev <= ?",
    ]);
    expect(h.log[1].values.at(-1)).toBe(3);
  });

  it('① 행위자가 없는 시스템 투영은 my_decided 문장을 보내지 않는다', async () => {
    const h = makeHarness();

    await h.repo.updateProjection({
      requestId: ID, status: 'EXPIRED', isOpen: 0, currentStepOrder: 1, updatedAt: NOW, reqRev: 3, actorKey: null,
    });

    expect(h.log).toHaveLength(1);
    expect(h.log[0].q).toMatch(/^UPDATE approval_inbox SET status=\?/);
  });

  it('② rev 3 종료 투영 뒤 지연된 rev 2 투영은 0행 — 다시 열리지 않는다', async () => {
    const h = makeHarness();

    await h.repo.updateProjection({
      requestId: ID, status: 'APPROVED', isOpen: 0, currentStepOrder: 2, updatedAt: NOW, reqRev: 3, actorKey: 'a',
    });
    const [, late] = await h.repo.updateProjection({
      requestId: ID, status: 'PENDING', isOpen: 1, currentStepOrder: 1, updatedAt: NOW, reqRev: 2, actorKey: 'a',
    });

    expect(late.rowsAffected).toBe(0);
    h.db.inbox.forEach((row) => expect(row).toMatchObject({ status: 'APPROVED', is_open: 0, req_rev: 3, my_turn: 0 }));
  });

  it('② 전원 승인 단계의 중간 결정자는 my_turn 이 꺼지고 남은 사람만 켜져 있다', async () => {
    const h = makeHarness({ steps: [{ approvers: ['a', 'b'], required: 2 }] });

    await h.repo.approve(approveInput('a'));

    expect(h.db.request).toMatchObject({ status: 'PENDING', current_step_order: 1 });
    expect(h.db.inbox.find((row) => row.actor_key === 'a')).toMatchObject({ my_decided: 1, my_turn: 0 });
    expect(h.db.inbox.find((row) => row.actor_key === 'b')).toMatchObject({ my_decided: 0, my_turn: 1 });
  });

  it('③ 업무함 myturn 탭 목록·상태 count·배지 count SQL 에 my_decided = 0 이 있다', async () => {
    const query = jest.fn(async () => ({ rows: [] }));
    const inbox = new InboxRepository({ query, tableReady: async () => true });

    await inbox.page({ actorKey: 'me', tab: 'myturn', cursor: null, window: 10 });
    await inbox.statusCounts({ actorKey: 'me', tab: 'myturn' });
    await inbox.myTurnCount({ actorKey: 'me' });
    await inbox.page({ actorKey: 'me', tab: 'waiting', cursor: null, window: 10 });

    const [page, counts, badge, waiting] = query.mock.calls.map(([sql]) => sql);
    [page, counts, badge].forEach((sql) => {
      expect(sql).toContain('my_decided = 0');
      expect(sql).toContain('my_turn = ?');
    });
    expect(waiting).not.toContain('my_decided = 0');
  });
});

describe('R04 진 회수·만료 이벤트 거두기', () => {
  it('① 회수 CAS 패배(다른 승인이 APPROVED 로 종료) → CANCELLED 이벤트 DELETE, 반환 status APPROVED, events 에 CANCELLED 없음', async () => {
    const h = makeHarness({
      hooks: {
        beforeCas: async (status, db) => {
          if (status !== 'CANCELLED') return;
          Object.assign(db.approvers.find((row) => row.actor_key === 'a'), { decision_type: 'APPROVE', decided_at: ts(NOW) });
          Object.assign(db.request, { status: 'APPROVED', current_step_order: 2, rev: db.request.rev + 1 });
        },
      },
    });

    const result = await h.repo.cancel({ requestId: ID, actorKey: 'owner', now: NOW + 1000 });

    expect(result.status).toBe('APPROVED');
    expect(result.events.map((event) => event.eventType)).not.toContain('CANCELLED');
    expect(h.writes().filter(({ q }) => q.startsWith('DELETE FROM approval_event'))).toHaveLength(1);
    expect(h.db.events).toEqual([]);
  });

  it('② 같은 전이가 다른 호출로 성공(상태 CANCELLED) → 이벤트를 거두지 않는다', async () => {
    const h = makeHarness({
      hooks: {
        beforeCas: async (status, db) => {
          if (status === 'CANCELLED') Object.assign(db.request, { status: 'CANCELLED', current_step_order: 2, rev: db.request.rev + 1 });
        },
      },
    });

    const result = await h.repo.cancel({ requestId: ID, actorKey: 'owner', now: NOW + 1000 });

    expect(result.status).toBe('CANCELLED');
    expect(h.writes().some(({ q }) => q.startsWith('DELETE FROM approval_event'))).toBe(false);
    expect(h.db.events.map((row) => row.event_type)).toEqual(['CANCELLED']);
  });

  it('③ closeBySystem(만료) 시도 소진 → 확정되지 못한 EXPIRED 이벤트를 거두고 reason cas', async () => {
    const h = makeHarness({
      expiresAt: NOW + 500,
      hooks: { beforeCas: async (status, db) => { db.request.rev += 1; } },
    });

    const result = await h.repo.expireByDeadline(ID, NOW + 1000);

    expect(result).toMatchObject({ closed: false, reason: 'cas' });
    expect(h.casAttempts).toHaveLength(3);
    expect(h.writes().filter(({ q }) => q.startsWith('DELETE FROM approval_event'))).toHaveLength(1);
    expect(h.db.events).toEqual([]);
    expect(result.state.events).toEqual([]);
  });

  it('③ closeBySystem 중 다른 전이로 종료(APPROVED) → 만료 이벤트를 거두고 not pending', async () => {
    const h = makeHarness({
      expiresAt: NOW + 500,
      hooks: {
        beforeCas: async (status, db) => {
          if (status === 'EXPIRED') Object.assign(db.request, { status: 'APPROVED', rev: db.request.rev + 1 });
        },
      },
    });

    const result = await h.repo.expireByDeadline(ID, NOW + 1000);

    expect(result).toMatchObject({ closed: false, reason: 'not pending' });
    expect(h.db.events).toEqual([]);
  });

  it('③ 회수 시도 소진 → 마지막 재조회가 PENDING 이면 이벤트를 거두고 CONCURRENT_MODIFICATION', async () => {
    const h = makeHarness({ hooks: { beforeCas: async (status, db) => { db.request.rev += 1; } } });

    await expect(h.repo.cancel({ requestId: ID, actorKey: 'owner', now: NOW + 1000 }))
      .rejects.toMatchObject({ code: 'CONCURRENT_MODIFICATION' });

    expect(h.casAttempts).toHaveLength(3);
    expect(h.db.events).toEqual([]);
  });

  it('성공한 회수·만료는 이벤트를 그대로 남긴다', async () => {
    const h = makeHarness({ expiresAt: NOW + 500 });

    const result = await h.repo.expireByDeadline(ID, NOW + 1000);

    expect(result).toMatchObject({ closed: true });
    expect(h.db.request.status).toBe('EXPIRED');
    expect(h.db.events.map((row) => row.event_type)).toEqual(['EXPIRED']);
    expect(h.writes().some(({ q }) => q.startsWith('DELETE'))).toBe(false);
  });
});

const eventRow = (eventType, actorKey, extra = {}) => ({
  event_id: deterministicEventId({
    requestId: ID, eventType, actorKey, ...(extra.discriminator ? { discriminator: extra.discriminator } : {}),
  }),
  event_type: eventType,
  actor_key: actorKey,
  delegate_key: null,
  occurred_at: ts(NOW),
  reason: extra.reason ?? null,
  content_version: 1,
});

describe('검토 반영(Codex 2026-10-28)', () => {
  it('P1-1 3명 중 2명 승인 — b 의 APPROVED 확정 뒤 c 의 늦은 반려가 붙어도 a 는 자기 승인을 되돌리지 않고 c 만 되돌린다', async () => {
    const initialLoads = deferred();
    const aClaimed = deferred();
    const bDone = deferred();
    const cClaimed = deferred();
    let approverSelects = 0;
    const h = makeHarness({
      steps: [{ approvers: ['a', 'b', 'c'], required: 2 }],
      ignoreParentGuard: true, // 종료 CAS 와 겹친 늦은 클레임
      hooks: {
        onApproverSelect: async () => {
          approverSelects += 1;
          if (approverSelects === 3) initialLoads.resolve();
        },
        beforeClaim: async (actor) => {
          await initialLoads.promise;
          if (actor === 'b') await aClaimed.promise;
          if (actor === 'c') await bDone.promise;
        },
        afterClaim: async (actor) => {
          if (actor === 'a') { aClaimed.resolve(); await cClaimed.promise; }
          if (actor === 'c') cClaimed.resolve();
        },
        afterCas: async (status) => { if (status === 'APPROVED') bDone.resolve(); },
      },
    });

    const [a, b, c] = await Promise.allSettled([
      h.repo.approve(approveInput('a')),
      h.repo.approve(approveInput('b')),
      h.repo.reject(rejectInput('c')),
    ]);

    expect(a).toMatchObject({ status: 'fulfilled', value: expect.objectContaining({ status: 'APPROVED' }) });
    expect(b).toMatchObject({ status: 'fulfilled', value: expect.objectContaining({ status: 'APPROVED' }) });
    expect(c).toMatchObject({ status: 'rejected', reason: expect.objectContaining({ code: 'ALREADY_DECIDED' }) });
    expect(h.db.approvers.map((row) => [row.actor_key, row.decision_type]))
      .toEqual([['a', 'APPROVE'], ['b', 'APPROVE'], ['c', 'PENDING']]);
    expect(h.writes().filter(({ q }) => q.startsWith("UPDATE approval_approver SET decision_type='PENDING'"))
      .map(({ values }) => values[2])).toEqual(['c']);
    expect(h.db.request.status).toBe('APPROVED');
    expectConsistent(h);
    expect(h.db.events.map((row) => row.actor_key).sort()).toEqual(['a', 'b']);
  });

  it('P1-2 늦은 반려 되돌림이 끊긴 뒤 같은 입력의 재시도 — 되돌림을 다시 하고 ALREADY_DECIDED', async () => {
    const h = makeHarness({
      steps: [{ approvers: ['a', 'b', 'c'], required: 1 }], decided: { a: 'APPROVE', c: 'REJECT' },
    });
    Object.assign(h.db.request, { status: 'APPROVED', current_step_order: 2, rev: 3 });
    h.db.events.push(eventRow('APPROVED', 'a'), eventRow('REJECTED', 'c', { reason: '반려 사유' }));

    await expect(h.repo.reject(rejectInput('c'))).rejects.toMatchObject({ code: 'ALREADY_DECIDED' });

    expect(h.db.approvers.find((row) => row.actor_key === 'c')).toMatchObject({ decision_type: 'PENDING', decided_at: null });
    expect(h.db.events.map((row) => row.actor_key)).toEqual(['a']);
    expectConsistent(h);
  });

  it('P2-3 ① 회수 시도 소진 뒤 거두기 DELETE 는 요청이 PENDING 일 때만 — 그 사이 같은 id 의 다른 회수가 성공했으면 남긴다', async () => {
    const h = makeHarness({
      hooks: {
        beforeCas: async (status, db) => { db.request.rev += 1; },
        beforeDelete: async (eventId, db) => {
          // 같은 요청자의 다른 회수 B 가 같은 id 이벤트로 성공했다.
          Object.assign(db.request, { status: 'CANCELLED', rev: db.request.rev + 1 });
        },
      },
    });

    await expect(h.repo.cancel({ requestId: ID, actorKey: 'owner', now: NOW + 1000 }))
      .rejects.toMatchObject({ code: 'CONCURRENT_MODIFICATION' });

    const del = h.log.find(({ q }) => q.startsWith('DELETE FROM approval_event'));
    expect(del.q).toContain("AND EXISTS (SELECT 1 FROM approval_request r WHERE r.request_id=approval_event.request_id AND r.status='PENDING')");
    expect(h.db.events.map((row) => row.event_type)).toEqual(['CANCELLED']);
  });

  it.each([
    ['회수', (h) => h.repo.cancel({ requestId: ID, actorKey: 'owner', now: NOW + 1000 }), NOW + 500],
    ['만료', (h) => h.repo.expireByDeadline(ID, NOW + 1000), NOW + 500],
    ['결정', (h) => h.repo.approve(approveInput('a')), null],
  ])('P2-3 ② 성공한 %s 는 CAS 직후 이벤트를 다시 쓴다 — INSERT 와 CAS 사이에 지워졌어도 복원된다', async (_name, run, expiresAt) => {
    const h = makeHarness({ expiresAt, hooks: { beforeCas: async (status, db) => { db.events = []; } } });

    await run(h);

    expect(h.casAttempts.filter((item) => item.ok)).toHaveLength(1);
    expect(h.db.events).toHaveLength(1);
  });

  it('P2-6 투영 my_decided 문장은 my_turn=0 도 쓴다 — aggregate 가 세대 조건에 막혀도 my_turn=1·my_decided=1 이 남지 않는다', async () => {
    const h = makeHarness({ steps: [{ approvers: ['a', 'b'], required: 2 }] });
    h.db.inbox.forEach((row) => { row.req_rev = 5; });

    const [, aggregate] = await h.repo.updateProjection({
      requestId: ID, status: 'PENDING', isOpen: 1, currentStepOrder: 1, updatedAt: NOW, reqRev: 3, actorKey: 'a',
    });

    expect(aggregate.rowsAffected).toBe(0);
    expect(h.db.inbox.find((row) => row.actor_key === 'a')).toMatchObject({ my_decided: 1, my_turn: 0 });
    expect(h.db.inbox.find((row) => row.actor_key === 'b')).toMatchObject({ my_decided: 0, my_turn: 1 });
  });
});

describe('검토 반영 2차 — 되돌림은 모순이 확실할 때만, 이벤트 삭제는 상태가 다를 때만', () => {
  it('규칙1 회수·만료로 닫힌 요청에 붙은 클레임은 되돌리지 않는다 — APPROVE·REJECT 모두 종료 상태를 idempotent 로 반환', async () => {
    for (const [run, actor, type] of [
      [(h) => h.repo.approve(approveInput('a')), 'a', 'APPROVE'],
      [(h) => h.repo.reject(rejectInput('b')), 'b', 'REJECT'],
    ]) {
      for (const closed of ['CANCELLED', 'EXPIRED']) {
        const h = makeHarness({
          ignoreParentGuard: true,
          hooks: { beforeClaim: async (who, db) => { Object.assign(db.request, { status: closed, rev: db.request.rev + 1 }); } },
        });

        const state = await run(h);

        expect(state).toMatchObject({ status: closed, idempotent: true, ownEvent: null });
        expect(h.db.approvers.find((row) => row.actor_key === actor).decision_type).toBe(type);
        expect(h.writes().some(({ q }) => q.startsWith("UPDATE approval_approver SET decision_type='PENDING'") || q.startsWith('DELETE'))).toBe(false);
      }
    }
  });

  it('규칙1 회수 뒤 재시도(앞 단계의 정상 승인)도 아무것도 되돌리지 않는다', async () => {
    const h = makeHarness({ steps: [{ approvers: ['a'], required: 1 }, { approvers: ['c'], required: 1 }], decided: { a: 'APPROVE' }, currentStepOrder: 2 });
    h.db.events.push(eventRow('APPROVED', 'a'));
    Object.assign(h.db.request, { status: 'CANCELLED', current_step_order: 3 });
    const mark = h.log.length;

    const state = await h.repo.approve(approveInput('a'));

    expect(state).toMatchObject({ status: 'CANCELLED', idempotent: true });
    expect(h.writes(mark)).toEqual([]);
    expect(h.db.approvers.find((row) => row.actor_key === 'a').decision_type).toBe('APPROVE');
  });

  it('규칙2 REJECTED 종료 + 내 APPROVE(이벤트 없음) 는 모순 — 내 클레임만 되돌리고 종료 상태를 idempotent 로', async () => {
    const h = makeHarness({
      ignoreParentGuard: true,
      hooks: {
        beforeClaim: async (actor, db) => {
          if (actor !== 'a') return;
          Object.assign(db.approvers.find((row) => row.actor_key === 'b'), { decision_type: 'REJECT', decided_at: ts(NOW) });
          Object.assign(db.request, { status: 'REJECTED', current_step_order: 2, rev: db.request.rev + 1 });
        },
      },
    });

    const state = await h.repo.approve(approveInput('a'));

    expect(state).toMatchObject({ status: 'REJECTED', idempotent: true, ownEvent: null });
    expect(state.decisions.get('a')).toEqual({ decisionType: 'PENDING', decidedAt: null });
    expect(h.db.approvers.find((row) => row.actor_key === 'a').decision_type).toBe('PENDING');
    expect(h.db.events).toEqual([]);
    expectConsistent(h);
  });

  it('규칙2 REJECTED 종료 + 내 APPROVE 인데 내 이벤트가 이미 있으면 반영 여부를 모르니 그대로 둔다(쓰기 0, idempotent)', async () => {
    const warn = jest.spyOn(console, 'warn').mockImplementation(() => {});
    const h = makeHarness({ decided: { a: 'APPROVE' } });
    h.db.events.push(eventRow('APPROVED', 'a'));
    Object.assign(h.db.request, { status: 'REJECTED', current_step_order: 2 });
    const mark = h.log.length;

    const state = await h.repo.approve(approveInput('a'));

    expect(state).toMatchObject({ status: 'REJECTED', idempotent: true });
    expect(state.ownEvent).toMatchObject({ eventType: 'APPROVED', actorKey: 'a' });
    expect(h.writes(mark)).toEqual([]);
    expect(h.db.approvers.find((row) => row.actor_key === 'a').decision_type).toBe('APPROVE');
    warn.mockRestore();
  });

  it('규칙3 클레임은 되돌렸는데 모순 이벤트가 남은 상태(되돌림 중단) — 재시도가 이벤트를 다시 거두고 ALREADY_DECIDED', async () => {
    const h = makeHarness({ steps: [{ approvers: ['a', 'b', 'c'], required: 1 }], decided: { a: 'APPROVE' } });
    Object.assign(h.db.request, { status: 'APPROVED', current_step_order: 2, rev: 3 });
    h.db.events.push(eventRow('APPROVED', 'a'), eventRow('REJECTED', 'c', { reason: '반려 사유' }));

    await expect(h.repo.reject(rejectInput('c'))).rejects.toMatchObject({ code: 'ALREADY_DECIDED' });

    expect(h.db.events.map((row) => row.actor_key)).toEqual(['a']);
    expect(h.writes().filter(({ q }) => q.startsWith('DELETE FROM approval_event'))).toHaveLength(1);
  });

  it('규칙3 APPROVE 쪽(REJECTED 종료에 남은 내 APPROVED 이벤트, 결정 행 PENDING)도 거두고 종료 상태 반환', async () => {
    const h = makeHarness({ decided: { b: 'REJECT' } });
    Object.assign(h.db.request, { status: 'REJECTED', current_step_order: 2, rev: 3 });
    h.db.events.push(eventRow('REJECTED', 'b'), eventRow('APPROVED', 'a'));

    const state = await h.repo.approve(approveInput('a'));

    expect(state).toMatchObject({ status: 'REJECTED', idempotent: true });
    expect(h.db.events.map((row) => row.actor_key)).toEqual(['b']);
  });

  it('규칙4 요청자·관리자 동시 회수(다른 id, 같은 목표 상태) — 진 쪽 이벤트도 지우지 않는다(이벤트 둘 — 한계)', async () => {
    const h = makeHarness({
      hooks: {
        beforeCas: async (status, db) => {
          if (status !== 'CANCELLED' || db.request.status !== 'PENDING') return;
          db.events.push(eventRow('CANCELLED', 'admin'));
          Object.assign(db.request, { status: 'CANCELLED', current_step_order: 2, rev: db.request.rev + 1 });
        },
      },
    });

    const result = await h.repo.cancel({ requestId: ID, actorKey: 'owner', now: NOW + 1000 });

    expect(result.status).toBe('CANCELLED');
    expect(h.writes().some(({ q }) => q.startsWith('DELETE'))).toBe(false);
    expect(h.db.events.map((row) => row.actor_key).sort()).toEqual(['admin', 'owner']);
  });

  it('규칙4 만료 사유 경합(다른 id 의 EXPIRED 가 성공)도 같은 목표 상태라 지우지 않는다', async () => {
    const h = makeHarness({
      expiresAt: NOW + 500,
      hooks: {
        beforeCas: async (status, db) => {
          if (status !== 'EXPIRED' || db.request.status !== 'PENDING') return;
          db.events.push(eventRow('EXPIRED', null, { discriminator: 'CONTENT_VERSION:2' }));
          Object.assign(db.request, { status: 'EXPIRED', rev: db.request.rev + 1 });
        },
      },
    });

    const result = await h.repo.expireByDeadline(ID, NOW + 1000);

    expect(result).toMatchObject({ closed: false, reason: 'not pending' });
    expect(h.db.events).toHaveLength(2);
  });

  it('규칙5 recovered 는 이번 호출의 이벤트 INSERT 가 새 행을 넣었을 때만 — rowsAffected 1 이면 recovered, 0 이면 idempotent', async () => {
    // 이벤트 INSERT 실패 → 재시도가 이벤트를 새로 넣는다(rowsAffected 1).
    const inserted = makeHarness({ failures: { event: 1 } });
    await expect(inserted.repo.approve(approveInput('a'))).rejects.toThrow();
    const recovered = await inserted.repo.approve(approveInput('a', NOW + 5000));
    expect(recovered).toMatchObject({ status: 'APPROVED', recovered: true });
    expect(recovered.idempotent).toBeUndefined();

    // 이벤트까지 쓰고 CAS 에서 끊김 → 재시도는 aggregate 를 마저 쓰지만 이벤트 INSERT 는 중복(rowsAffected 0).
    const duplicate = makeHarness({ failures: { cas: 1 } });
    await expect(duplicate.repo.approve(approveInput('a'))).rejects.toThrow();
    const replay = await duplicate.repo.approve(approveInput('a', NOW + 5000));
    expect(replay).toMatchObject({ status: 'APPROVED', idempotent: true });
    expect(replay.recovered).toBeUndefined();
    expect(duplicate.db.request.status).toBe('APPROVED');

    // 투영만 뒤처진 재시도 → idempotent.
    const projection = makeHarness({ failures: { projection: 1 } });
    await expect(projection.repo.approve(approveInput('a'))).rejects.toThrow();
    expect(await projection.repo.approve(approveInput('a', NOW + 5000))).toMatchObject({ idempotent: true });

    // 진짜 멱등 · 새 결정
    const fresh = makeHarness();
    const first = await fresh.repo.approve(approveInput('a'));
    expect(first.idempotent).toBeUndefined();
    expect(first.recovered).toBeUndefined();
    expect(await fresh.repo.approve(approveInput('a', NOW + 5000))).toMatchObject({ idempotent: true });
  });

  it('규칙5 같은 이벤트 INSERT 결과가 rowsAffected 0 이면 새 행이 아니다(appendOwnEvent)', async () => {
    const h = makeHarness();
    const ctx = { inserted: false };
    h.execute.mockResolvedValueOnce({ rowsAffected: 0 });
    await h.repo.appendOwnEvent(ID, { eventId: ID, eventType: 'APPROVED', actorKey: 'a', occurredAt: NOW }, ctx);
    expect(ctx.inserted).toBe(false);
    h.execute.mockResolvedValueOnce({ rowsAffected: 1 });
    await h.repo.appendOwnEvent(ID, { eventId: ID, eventType: 'APPROVED', actorKey: 'a', occurredAt: NOW }, ctx);
    expect(ctx.inserted).toBe(true);
  });

  it('규칙6 대리 결정이 끊긴 뒤 대리인 이름의 재시도는 수렴하지 않는다 — 진행 중이면 APPROVER_NOT_ELIGIBLE, 종료면 REQUEST_NOT_PENDING', async () => {
    const h = makeHarness({ failures: { event: 1 } });
    await expect(h.repo.approve({ ...approveInput('a'), delegateKey: 'd' })).rejects.toThrow();

    await expect(h.repo.approve(approveInput('d', NOW + 5000))).rejects.toMatchObject({ code: 'APPROVER_NOT_ELIGIBLE' });
    Object.assign(h.db.request, { status: 'APPROVED', current_step_order: 2, rev: h.db.request.rev + 1 });
    await expect(h.repo.approve(approveInput('d', NOW + 6000))).rejects.toMatchObject({ code: 'REQUEST_NOT_PENDING' });
    // 위임자 본인(a)의 재시도만 수렴한다.
    expect(await h.repo.approve(approveInput('a', NOW + 7000))).toMatchObject({ status: 'APPROVED', recovered: true });
  });

  it('규칙7 반환의 ownEvent 는 이번 결정의 이벤트 — 마지막 이벤트가 다른 사람 것이어도 내 것', async () => {
    const fresh = makeHarness();
    const first = await fresh.repo.approve(approveInput('a'));
    expect(first.ownEvent).toMatchObject({ eventType: 'APPROVED', actorKey: 'a' });

    // 동시 승인에서 진 쪽(상대 종료 CAS 에 반영) — 마지막 이벤트는 상대 것이지만 ownEvent 는 내 것.
    const bothClaimed = deferred();
    let claims = 0;
    const h = makeHarness({
      steps: [{ approvers: ['a', 'b'], required: 2 }],
      hooks: {
        afterClaim: async () => { claims += 1; if (claims === 2) bothClaimed.resolve(); await bothClaimed.promise; },
      },
    });
    const [a, b] = await Promise.all([h.repo.approve(approveInput('a')), h.repo.approve(approveInput('b'))]);
    expect(a.ownEvent.actorKey).toBe('a');
    expect(b.ownEvent.actorKey).toBe('b');
  });
});
