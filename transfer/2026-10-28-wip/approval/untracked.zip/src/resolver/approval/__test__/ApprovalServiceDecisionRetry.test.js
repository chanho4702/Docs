/**
 * 결정 재시도의 서비스 경계(Codex 검토 2026-10-28 P2-5·P2-7).
 * - 저장소가 `idempotent: true` 를 돌려주면 알림·다음 단계 알림·afterDecide·외부 알림(Jira 코멘트)을 다시 내지 않는다.
 * - 대리 결재의 부분 실패는 대리인 경유로 복구하지 않는다(검토 2차 — 위임자 본인 재시도만 수렴).
 * - 알림·코멘트 판정은 저장소가 준 ownEvent(이번 결정의 이벤트)로 한다(검토 2차 P2-8).
 */
import { ApprovalService } from '../ApprovalService';
import { createTargetRegistry } from '../target/TargetRegistry';
import { deterministicEventId } from '../../../domain/approval/eventId';

jest.mock('../../timesheet/PeriodReopenGuard', () => ({ assertRequestNotReopening: jest.fn() }));

const NOW = 1_700_000_000_000;
const REQ = '11111111-1111-4111-8111-111111111111';

const state = (overrides = {}) => ({
  requestId: REQ,
  targetKind: 'ISSUE_TRANSITION',
  targetKey: '100:5',
  issueId: '100',
  projectId: '10000',
  requesterKey: 'requester',
  status: 'PENDING',
  currentStepOrder: 1,
  contentVersion: 0,
  steps: [{ stepOrder: 1, approverKeys: ['a', 'b'], requiredApprovals: 1 }],
  decisions: new Map(),
  events: [],
  ...overrides,
});

const adapterOf = () => ({
  kind: 'ISSUE_TRANSITION',
  targetOf: () => ({ kind: 'ISSUE_TRANSITION', issueId: '100', toStatusId: '5' }),
  keyOf: () => '100:5',
  canView: jest.fn(async () => true),
  afterDecide: jest.fn(async () => ({ apply: { status: 'APPLIED' } })),
  notifyExternal: jest.fn(async () => {}),
});

const make = ({ loaded = state(), decided, activeAmong = jest.fn(async () => []) } = {}) => {
  const adapter = adapterOf();
  const repository = {
    load: jest.fn(async () => loaded),
    approve: jest.fn(async () => decided),
    reject: jest.fn(async () => decided),
    findCcKeys: jest.fn(async () => []),
  };
  const appNotifier = jest.fn(async () => ({}));
  const svc = new ApprovalService({
    repository,
    targets: createTargetRegistry({ ISSUE_TRANSITION: adapter }),
    policyLoader: jest.fn(async () => ({ rejectionReasonRequired: false })),
    registryLoader: async () => [],
    pinVerifier: jest.fn(async () => {}),
    pinStatusLoader: jest.fn(async () => ({ required: false, hasPin: true })),
    delegations: { activeAmong },
    appNotifier,
    clock: () => NOW,
  });
  return {
    svc, repository, adapter, appNotifier, activeAmong,
  };
};

const request = (payload, accountId = 'a') => ({ payload, principal: { accountId }, context: {} });

const approvedEvent = (actorKey) => ({
  eventId: deterministicEventId({ requestId: REQ, eventType: 'APPROVED', actorKey }),
  eventType: 'APPROVED',
  actorKey,
});

describe('P2-5 멱등 결정은 후속 처리를 다시 내지 않는다', () => {
  it.each([
    ['APPROVE', 'APPROVED'],
    ['REJECT', 'REJECTED'],
  ])('%s — idempotent 결과면 알림·afterDecide·notifyExternal 을 부르지 않고 응답 shape 은 그대로', async (decision, status) => {
    const events = [{ eventId: 'e1', eventType: status, actorKey: 'a' }];
    const {
      svc, adapter, appNotifier,
    } = make({ decided: state({ status, currentStepOrder: 2, events, idempotent: true }) });

    const result = await svc.decideApproval(request({ requestId: REQ, decision, reason: 'r' }));

    expect(result).toEqual({
      requestId: REQ, status, currentStepOrder: 2, apply: null,
    });
    expect(appNotifier).not.toHaveBeenCalled();
    expect(adapter.afterDecide).not.toHaveBeenCalled();
    expect(adapter.notifyExternal).not.toHaveBeenCalled();
  });

  it('새 결정(표식 없음)과 끊긴 결정을 마저 쓴 재시도(recovered)는 후속 처리를 한다', async () => {
    for (const extra of [{}, { recovered: true }]) {
      const {
        svc, adapter, appNotifier,
      } = make({ decided: state({ status: 'APPROVED', currentStepOrder: 2, events: [approvedEvent('a')], ...extra }) });

      const result = await svc.decideApproval(request({ requestId: REQ, decision: 'APPROVE' }));

      expect(result).toMatchObject({ status: 'APPROVED', apply: { status: 'APPLIED' } });
      expect(appNotifier).toHaveBeenCalled();
      expect(adapter.afterDecide).toHaveBeenCalledTimes(1);
      expect(adapter.notifyExternal).toHaveBeenCalledTimes(1);
    }
  });
});

describe('대리 결재 부분 실패는 대리인 경유로 수렴하지 않는다(검토 2차 — 한계)', () => {
  it('위임자 a 의 결정 행이 있고 이벤트가 없어도 대리인 d 의 재시도는 d 이름으로 간다 — 미결 결재자만 위임 후보', async () => {
    const activeAmong = jest.fn(async () => []);
    const loaded = state({ decisions: new Map([['a', { decisionType: 'APPROVE', decidedAt: NOW }], ['b', { decisionType: 'PENDING' }]]) });
    const { svc, repository } = make({ loaded, activeAmong, decided: state() });

    await svc.decideApproval(request({ requestId: REQ, decision: 'APPROVE' }, 'd'));

    expect(activeAmong.mock.calls).toEqual([[['b'], 'd', NOW]]);
    expect(repository.approve).toHaveBeenCalledWith(expect.objectContaining({ actorKey: 'd', delegateKey: null }));
  });

  it('종료된 요청은 위임 후보를 찾지 않는다(대리인 이름 그대로 — 저장소가 REQUEST_NOT_PENDING)', async () => {
    const activeAmong = jest.fn(async () => [{ delegatorKey: 'a' }]);
    const loaded = state({ status: 'APPROVED', currentStepOrder: 2, decisions: new Map([['a', { decisionType: 'APPROVE', decidedAt: NOW }]]) });
    const { svc, repository } = make({ loaded, activeAmong, decided: state() });
    repository.approve.mockRejectedValue(Object.assign(new Error('REQUEST_NOT_PENDING'), { code: 'REQUEST_NOT_PENDING' }));

    await expect(svc.decideApproval(request({ requestId: REQ, decision: 'APPROVE' }, 'd'))).rejects.toMatchObject({ code: 'REQUEST_NOT_PENDING' });

    expect(activeAmong).not.toHaveBeenCalled();
    expect(repository.approve).toHaveBeenCalledWith(expect.objectContaining({ actorKey: 'd' }));
  });

  it('위임자 본인의 미결 차례에는 기존처럼 대리 결재한다', async () => {
    const activeAmong = jest.fn(async () => [{ delegatorKey: 'b' }]);
    const loaded = state({ decisions: new Map([['a', { decisionType: 'PENDING' }], ['b', { decisionType: 'PENDING' }]]) });
    const { svc, repository } = make({ loaded, activeAmong, decided: state({ status: 'APPROVED', events: [approvedEvent('b')] }) });

    await svc.decideApproval(request({ requestId: REQ, decision: 'APPROVE' }, 'd'));

    expect(repository.approve).toHaveBeenCalledWith(expect.objectContaining({ actorKey: 'b', delegateKey: 'd' }));
  });
});

describe('P2-8 알림·코멘트는 이번 결정의 이벤트(ownEvent)로 판정한다', () => {
  it('마지막 이벤트가 다른 사람의 반려여도 내 승인 이벤트로 APPROVED 알림·외부 알림을 낸다', async () => {
    const mine = approvedEvent('a');
    const theirs = { eventId: 'x', eventType: 'REJECTED', actorKey: 'b' };
    const { svc, appNotifier, adapter } = make({
      decided: state({ status: 'REJECTED', currentStepOrder: 2, events: [mine, theirs], ownEvent: mine }),
    });

    await svc.decideApproval(request({ requestId: REQ, decision: 'APPROVE' }));

    expect(appNotifier).toHaveBeenCalledWith(expect.objectContaining({ kind: 'APPROVED', event: mine }));
    expect(adapter.notifyExternal).toHaveBeenCalledWith(expect.objectContaining({ kind: 'APPROVED', event: mine }));
  });

  it('ownEvent 가 null 이면(이벤트를 못 찾음) 알림을 내지 않는다 — 마지막 이벤트로 대신하지 않는다', async () => {
    const { svc, appNotifier, adapter } = make({
      decided: state({ status: 'APPROVED', currentStepOrder: 2, events: [approvedEvent('b')], ownEvent: null }),
    });

    await svc.decideApproval(request({ requestId: REQ, decision: 'APPROVE' }));

    expect(appNotifier).not.toHaveBeenCalled();
    expect(adapter.notifyExternal).not.toHaveBeenCalled();
  });
});
