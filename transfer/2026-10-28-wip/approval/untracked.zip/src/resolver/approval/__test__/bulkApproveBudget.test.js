import { ApprovalService } from '../ApprovalService';

/**
 * 2026-10-28 전수 점검 D02 — 50건 직렬 일괄 승인에 전체 마감이 없어 UI resolver 한도(25초)에 걸리면 일부는 저장되고 응답은 끊겼다.
 * 지금은 20초 전체 마감을 넘기면 남은 건을 손대지 않고 `remaining` 으로 돌려준다(화면이 "남은 N건" 으로 보여 준다).
 */
const ids = Array.from({ length: 5 }, (_, i) => `1111111${i}-1111-4111-8111-111111111111`);

const build = ({ perItemMs }) => {
  let now = 0;
  const service = new ApprovalService({ clock: () => now, pinVerifier: async () => {} });
  service.decideApproval = jest.fn(async ({ payload }) => { now += perItemMs; return { status: 'APPROVED', requestId: payload.requestId }; });
  return { service };
};

describe('bulkApprove — 전체 마감', () => {
  it('마감 안이면 전부 처리하고 remaining 은 빈 배열', async () => {
    const { service } = build({ perItemMs: 1_000 });
    const out = await service.bulkApprove({ principal: { accountId: 'me' }, payload: { requestIds: ids } });
    expect(out).toMatchObject({ approved: 5, failed: 0, remaining: [] });
    expect(service.decideApproval).toHaveBeenCalledTimes(5);
  });

  it('건당 9초면 2건 뒤 18초 + 가장 오래 걸린 9초 = 27초 > 20초 → 3건째는 시작하지 않는다(2건 처리·3건 remaining, 한도 안에서 끝남)', async () => {
    const { service } = build({ perItemMs: 9_000 });
    const out = await service.bulkApprove({ principal: { accountId: 'me' }, payload: { requestIds: ids } });
    expect(out.approved).toBe(2);
    expect(out.remaining).toEqual(ids.slice(2));
    expect(out.results.map((r) => r.requestId)).toEqual(ids.slice(0, 2));
    expect(service.decideApproval).toHaveBeenCalledTimes(2);
  });

  it('PIN 확인 시간도 마감에 든다', async () => {
    let now = 0;
    const service = new ApprovalService({ clock: () => now, pinVerifier: async () => { now += 15_000; } });
    service.decideApproval = jest.fn(async ({ payload }) => { now += 4_000; return { status: 'APPROVED', requestId: payload.requestId }; });
    const out = await service.bulkApprove({ principal: { accountId: 'me' }, payload: { requestIds: ids, pin: '1234' } });
    // 15(PIN)+4 = 19, 다음 건 예상 4 → 23 > 20 → 1건만
    expect(out.approved).toBe(1);
    expect(out.remaining).toEqual(ids.slice(1));
  });

  it('첫 건은 마감과 무관하게 항상 시도한다', async () => {
    const { service } = build({ perItemMs: 30_000 });
    const out = await service.bulkApprove({ principal: { accountId: 'me' }, payload: { requestIds: ids.slice(0, 2) } });
    expect(out.approved).toBe(1);
    expect(out.remaining).toEqual([ids[1]]);
  });
});
