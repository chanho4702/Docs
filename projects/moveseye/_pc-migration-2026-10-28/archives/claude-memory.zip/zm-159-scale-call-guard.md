---
name: zm-159-scale-call-guard
description: "09-21 ZM-159 ✅종료 — C1~C8·결함·범위설정·C5 전부 master ff(BE 1799fc4·FE 927f3fd, 미푸시). dev 런타임 확인 통과. 워크트리 제거·브랜치는 유지. 📍문서 지도 _workspace/features/infra/scale-call-guard/INDEX_zm-159-scale-call-guard.md · 남은 일 정본 features/infra/scale-call-guard/backlog_zm-159-후속.md"
metadata: 
  node_type: memory
  type: project
  originSessionId: 537eb029-8b26-4fc6-925c-18e829e04eb2
  modified: 2026-09-17T01:26:14.340Z
---

2026-09-17 사용자 지시: "레스트 클라이언트 호출 부분은 공통 로직으로 빼서 유틸에 넣고 쓰게, 롬복 활용, 해당 이슈들 코덱스 검토 받고 ZM-159로 작업 시작" + "검수 끝나면 바로 진행". Jira ZM-159 「대용량 호출 방어」는 사용자가 발급.

- 근거: [[scale-5000-hosts-audit]] · 설계 v1 `_workspace/features/infra/scale-call-guard/devdesign_zm-159-scale-call-guard.md`(§0이 결정) · 검수 `_archive/features/infra/scale-call-guard/review_zm-159_codex-r1.md`(설계, 필수 8) · `review_zm-159-c1c2.md`+`_codex.md`(구현, 반영 기록 하단) · `review_zm-159-c3.md`+`_codex.md`
- 워크트리 `C:/worktrees/zm-159-be`(브랜치 ZM-159, master 8df357d). **커밋 manifest**: `features/infra/scale-call-guard/review_zm-159-c1c2.md` 하단 "커밋 manifest"(C1 24·C2 14·C3 7) — 합 45 = 작업 트리 전체. 객체 결과(Event·Script)는 C2.
- 검증: C1만 → 엔진 149·앱 컴파일 / C1+C2 → 엔진 162·앱 컴파일·AuthorizationContractIT 11 / 현재(C3 포함) → 엔진 194·IT 11. 임시 검증 워크트리는 master에서 파일 복사로 만들고 삭제함.
- 구조: `client/ZabbixApiTemplate`(raw·call·list·object·count·firstId·exec) · `ZabbixParams`(허용 타입 외 거부, 깊은 복사) · `ZabbixClientAccessTest`(**바이트코드 상수 풀** 검사 — 소스 정규식은 URL·문자열에 속음) · C3 `ZabbixCallLimits`(엔진엔 Spring Boot 없음 → Environment+생성자 검증, @Autowired 필수) · `ZabbixQueryExecutor`(id·기간·커서, limit=maxRows+1, 초과 시 기간→id 반분, FILTER 중복 제거는 창 확정 시점) · `ZabbixClient` 응답 바이트 상한(exchange+LimitedInputStream, 64MiB).
- 🔴 교훈: 기계 변환 정규식이 ① 대입문 연속 줄을 exec로 ② `\s*$`가 뒤 빈 줄을 삼킴 ③ sed가 한글·이모지 패턴을 못 맞춰 변이가 "생존"으로 오판 → python으로 치환하고 cmp로 변경 확인. ArrayDeque는 null 원소 금지(NPE). 스텁된 목 재스텁은 doAnswer. 엔진 모듈 테스트엔 spring-test 없음(MockEnvironment 불가).
- C3 검수 반영: 전송을 Apache HttpClient `executeOpen` 직접 호출로 — 🔴 멈출 때는 **응답 닫기 전에 `post.cancel()`**(닫기가 남은 본문을 소진해 끝없는 응답에 멈춤), Jackson 자동 닫기 차단(CloseShield)+`drainToEnd`(뒤 공백 우회 차단). 보호 층은 비배열·비정수·키 누락을 ApiError로, 시간 예산은 호출 전·후·소비자 뒤, 행 예산은 분할 판단보다 먼저. 설정 키는 단수 `zabbix.call.policy.{method}.*`.
- C4(사용자 09-17 "host.get 이넘화+출처 링크, API 버전 바뀌어도 바꿔 끼우기 쉽게"): `client/ZabbixMethod`(rpcName·access·docUrl, 버전은 `DOCS_VERSION` 한 곳 + `DOCS_URL_FORMAT` 틀) · 조사표 `engine-zabbix/src/test/resources/zabbix/api-reference-7.0.json`(111개 원문 확인)·`_workspace/features/platform/zabbix-api-reference/zabbix-api-7.0-methods.md` · `ZabbixMethodTest`가 대조. 완료: 실행기 스펙 이넘+READ만, 템플릿 문자열 인자 제거, max-held-rows 1만(전역 예산보다 넓히지 않음), 응답 상한은 실측 전까지 64MiB 유지(C4 검수 R3). 사용자 방향: "한 번에 다 가져올 일 없음 — 과하게 하지 말 것".
- C6(사용자 "A로 하자"·"적당히 알아서"): `5226c38` 아이템·트리거 목록 무스코프 차단, `de64685` Dockerfile `BE_JAVA_OPTS`(기본 MaxRAMPercentage=75). 이어서 미커밋 22파일 — AWS 매처는 LAST_CHECK 대신 후보 호스트의 CPU util lastclock(500대씩) · `ZabbixTrendServiceImpl`은 scanWindows(예산 아이템×시간×2, 불완전=ApiError) · 리포트/그룹 추이는 호스트 묶음(cpu·mem 200/disk 50/traffic 10)+6인자 `queryTrendFamily(keep)` 사전 선별 · 인터페이스 상태 차트 >6h는 trend **max**(최악 상태) · 네트워크 차트 미지정 시 상위 10 iface·10개 묶음 · 자산 동기화 hostid 선조회→500개씩 상세. 검수 `features/infra/scale-call-guard/review_zm-159-c6.md`(+_codex) — R1 트렌드는 전역 예산 유지(요청별 확대 금지)·R2 `ZabbixItemServiceImpl`이 item.get ids를 max-ids(50)로 분할·R3 인터페이스 원시는 행 예산(8만/분수) 묶음, 20회 초과 규모는 trend만·R4 매처 색인 세대. 커밋 `8e289d9`, master ff. 응답 상한 16MiB는 대규모 힙 실측 전이라 보류.
- 🔴 C6 교훈: `MetricPort` default 메서드에 람다 금지(합성 private static을 `LicenseGuardedPortTest`가 리플렉션 호출해 깨짐) · lenient 스텁 재스텁은 `doThrow().when()` · `cat > 파일`을 heredoc 앞에 두면 stdin 대기로 멈춤 · `expectedRows` 곱셈 오버플로(multiplyExact로 포화).
- 결함 4건(09-17 "ㅇㅋㅇㅋ"): BE `8fa5ec2` / FE `aac67f4`(FE master가 앞서 있어 리베이스 후 ff). 검수 `features/infra/scale-call-guard/review_zm-159-defects.md`(+_codex, R1~R3 반영). T-A는 A-1만 — 미해소 좀비 삭제를 **정리 배치에서 보정 사이클 안으로** 옮김(인스턴스 간 상태 공유 불필요, 연속 완전 보정 3회·1시간 1회, 15분 공백이면 연속 초기화). X1은 섹션 풀/콜 풀 분리+Future 인터럽트. N2는 가까운 시각 결합(같은 초는 나중 값, 아래쪽 중앙값 간격의 절반).
- 🔴 결함 교훈: 변이 검사 "실패"가 컴파일 오류일 수 있음 — 결과 XML로 실패 사유 확인 · 교착 테스트는 `@Timeout(threadMode=SEPARATE_THREAD)`+기한 있는 get(안 그러면 워커가 영구 정지, 남은 GradleWorkerMain은 워크트리 경로 확인 후 종료) · python 문자열의 `\u0000`이 실제 NUL로 들어감 · codex exec는 git 저장소 안에서만(`C:/worktrees`는 거부) · `ApmCollectorLiveRuntimeTest`는 Windows 임시 파일 잠금으로 간헐 실패(단독 재실행 통과).
- C8(09-17 사용자 "ㅇㅇ 다른 세션이랑 안 겹치게, 코덱스 시켜가면서"): 설계 `features/infra/scale-call-guard/devdesign_zm-159-c8-group-alert-scan.md`(v1) → 코덱스 설계 검토 R1~R13 → 구현 → 구현 검수 R1~R6 → `aff4097`. `AlertPort.countHistory`/`scanHistory`+`AlertScanOutcome`(abstract, proto 동기화). 🔴 그룹 문제 상세 FE는 `statusCounts`만 씀 → 목록 폐기. 🔴 캐시 DTO는 `@Jacksonized` 필수(없으면 캐시 적중 시 500). 🔴 캐시 키와 집계 범위는 같은 경계로.
- 🔴 운영 교훈: `timeout N ./gradlew test`로 끊으면 클라이언트만 죽고 데몬이 테스트를 계속 돌리며 **빈 결과 XML**을 남긴다 — 전체 테스트는 시간 제한 없이 백그라운드로, 집계 전 `build/test-results/test` 비우기. 다른 워크트리(zm-157-be) 워커가 돌면 전체 테스트 보류(IT DB 공유).
- 09-18 추가: C7 잘림 표시(문제 목록 이력 2만 건 — BE `8bc031b`·FE `98fd2df`) · H5 네트워크 맵 N+1 제거(`ca76739` — problemAggByHost가 이미 있었고 지리 맵만 쓰고 있었다) · **알람 동기화 범위 설정**(`35e9879`·FE `927f3fd`, 설정 EVENT_SYNC/V63: 그룹·최소 심각도·억제 제외·꺼진 규칙 제외). 🔴 검수에서 `enabledRulesOnly`가 목록 조회에 적용되지 않던 결함 발견·수정. 범위 밖 사본 행은 되짚기 제외, 2일 뒤 정리로 사라짐.
- T-A A-2(1만 건 초과분): 설계 v1 + 코덱스 2회 검토 → **착수 보류, 별도 티켓**(재개 계약·DB run id 표시자·첫 회차 후보 폭증·증분 쓰기 폭증). 설계 `features/infra/scale-call-guard/devdesign_zm-159-ta2-problem-cursor.md` 상단에 사유 기록.
- 🔴 다중 세션 교훈(09-18): master가 자주 앞선다 → **커밋 전 리베이스 + ff 병합**이 기본. 마이그레이션 번호는 선점당할 수 있다(V62 충돌 → V63). 공유 IT DB는 다른 세션 미커밋 마이그레이션·연결 고갈로 깨질 수 있다(연결 정리 후 재실행).
- 범위 밖: 권한 캐시 키(HostService:1017·1121)는 ZM-157 계약서 하단에 이관 요청 기록.

**How to apply:** 커밋은 승인 후([[commit-requires-approval]], 이번 흐름은 "적당히 알아서"로 위임)·트레일러 금지([[no-coauthored-by-trailer]])·푸시 금지. 다음은 C7(불완전 표시)·C5(완전성 계약)·16MiB 실측·T-A A-2. BE 테스트는 워크트리에서, GradleWorkerMain 없을 때.
- **C5(09-19, 커밋 `1799fc4` master ff)** 원시 시계열 완전성. 방향이 검수로 한 번 뒤집혔다 — "잘림 감지 후 trend 대체"가 아니라 **`ZabbixQueryExecutor.scanWindows`로 쪼개 끝까지 읽기**(코덱스 R3). 신설: `SeriesResult`·`HistoryScanResult`·`MetricPort.querySeriesResult`(구현 정본, `querySeries`는 얇은 통로)·`ZabbixHistoryService.scanHistoryByItemids`·`HistoryGetParams.maxHeldRows`·설정 `zabbix.call.max-history-rows`(기본 10만).
  🔴 **핵심 교훈 4개(전부 코덱스가 차단으로 잡음)**: ① **1콜 행 상한 < 보유 상한**이어야 쪼개 완주가 가능하다(같으면 "한 조각이 넘쳤다 = 이미 상한 초과") → history.get을 10만→**1만**으로 낮추고 기동 시 검증. ② **정책 창과 행 상한은 짝** — `200개 × 3,000초 ÷ 1분 = 1만 행`. 어긋나면 매 창 헛읽기+분할(창 3,600→3,000초). ③ 실행기의 **확정 전 창 버퍼**도 예산에 넣어야 한다 — `maxWindowRows`를 `IntSupplier`(남은 자리)로 주고, 이번 콜 상한도 `min(정책, 남은 자리)`로 낮추고, 전달한 페이지는 즉시 `set(i,null)`. ④ **분할은 기존 소비자를 깨뜨린다** — `ItemsService`는 "응답이 정확히 10만이면 잘림"으로 판정했고 `HostService`는 DESC로 최신 구간을 지켰다 → 레거시 `getHistoryByItemids`·`getRange`는 **1콜 그대로 두고** 분할은 새 API에만. ItemsService는 완전성 판정으로 이전.
  인터페이스 상태 차트는 단방향 상태 기계(긴 창=요약→원시→빈 결과 / 짧은 창=원시→요약 1회→빈 결과), 잘린 원시는 앞 묶음까지 버린다. 🔴 `MAX_RAW_CALLS`는 포트 호출 수이지 RPC 수가 아니다(app은 엔진 정책을 못 본다 — 요청 단위 공통 예산은 후속).
  🔴 **배포 주의**: 외부 설정에 `zabbix.call.policy.history.get.max-rows=100000`을 고정한 환경은 `max-history-rows`와 함께 조정해야 기동한다(저장소 설정엔 없음).
  검수 5회 왕복(`features/infra/scale-call-guard/review_zm-159-c5.md` + `_codex`·`-v2`~`-v5_codex.md`), 최종 승인. 후속: 전달 페이지 해제를 고정하는 테스트·희소 200묶음 RPC 실측.
- **종료 정리(09-21)**: 📍 **문서 지도 `_workspace/features/infra/scale-call-guard/INDEX_zm-159-scale-call-guard.md`**(보고서·설계 6·검수 13회·다이어그램·근거를 한 장으로, 링크 43개 검증) · **남은 일 정본 `_workspace/features/infra/scale-call-guard/backlog_zm-159-후속.md`**(A-2 착수 조건·차트 문구·C5 후속 3건·16MiB·부하시험·잡무). 보고서 2종에 C5 절과 런타임 결과 반영.
  **dev 런타임 확인(:3000, 1799fc4)**: 기동 시 새 설정 검증 통과 · CPU 차트 3시간 180점/1일 **1,440점**(1분×분수 정확히 일치, 누락 0) · 아이템 이력 6시간 360점·3일 71점(요약 전환) · `history.get×4` 계측 · **절단·불완전 경고 0건**. 🔴 **인터페이스 상태 차트는 미확인** — dev 자빅스에 oper/admin 인터페이스 아이템이 0개다(포트 다수 장비 환경 필요).
  🔴 중간 오류 2건은 코드 무관: 잘못된 `types=util`(정답 UTILIZATION) 500 · 원격 자빅스 13초 무응답(`dmove.co.kr:443 failed to respond`)으로 3일 차트 1회 빈 결과.
  워크트리 2개 제거(FE는 `git worktree remove`가 "Invalid argument"로 실패 → PowerShell `Remove-Item -Recurse -Force` 후 `worktree prune`). 브랜치 `ZM-159`는 푸시 전이라 양쪽 유지.
- 09-21 사용자 확인: `zabbix.call.policy.history.get.max-rows` 설정이 외부(환경변수·Vault)에도 **없다** → C5 기동 검증으로 인한 배포 위험 없음(전부 기본값 1만 < 10만).
